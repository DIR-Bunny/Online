package com.capg.Application;

import java.awt.EventQueue;
import java.rmi.activation.ActivationGroupDesc;

import javax.swing.JFrame;

public class GDemo extends JFrame
{
	public GDemo() {
		initUI();
	}
	
	private void initUI()
	{
		add(new Board());
		setSize(330,330);
		setTitle("DONUT");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}

	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				GDemo app = new GDemo();
				app.setVisible(true);
				
			}
		});

	}

}
