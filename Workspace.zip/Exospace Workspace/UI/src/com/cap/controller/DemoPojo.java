package com.cap.controller;

public class DemoPojo 
{
	private String answers;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	public String getAnswers() {
		return answers;
	}

	public void setAnswers(String answers) {
		this.answers = answers;
	}
	
}
