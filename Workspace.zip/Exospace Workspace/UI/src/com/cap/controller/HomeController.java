package com.cap.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;

@Controller

public class HomeController 
{
	@Autowired
	private userDao dao;
	 @Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE) 
	//@Scheduled(fixedDelay = 1000)
	
	 @RequestMapping("/MyPage")
	public ModelAndView MyPage()
	{
		System.out.println("MyPage");
		return new ModelAndView("MyPage");
	}
	@RequestMapping("/Home")
	public ModelAndView Home()
	{
		System.out.println("asdasd");
		return new ModelAndView("as");
	}
	
	
	@RequestMapping("/abc")
	public ModelAndView abc()
	{
		return new ModelAndView("Demo");
	}
	@RequestMapping("/Editor")
	public ModelAndView Editor()
	{
		System.out.println("I am in editor");
		return new ModelAndView("Editor");
	}
	
	@RequestMapping(value="/abc1", method = RequestMethod.POST)
	public ModelAndView abc(@RequestParam(value="abc") List<String> abc,@RequestParam(value="answers") List<String> abc1)
	{
		System.out.println(abc+" "+abc1);
		System.err.println(abc.size()+"  "+abc1.size());
		for (String string : abc) {
			System.out.println("Ans "+string);
		}
		
		for (String string : abc1) 
		{
			System.err.println("Ans "+string);
		}
		
		System.out.println("asdasd");
		return new ModelAndView("as",new ModelMap().addAttribute("answers", new DemoPojo()));
	}
	
	
	@RequestMapping("/Demo")
	public ModelAndView Demo()
	{
		User user = dao.findByUserName("v");
		System.out.println(user.getPassword());
		return new ModelAndView("as");
	}
	@RequestMapping("/CD")
	public ModelAndView CD()
	{
		System.out.println("CD");
		return new ModelAndView("CD");
	}
	
	@RequestMapping("/Clock")
	public ModelAndView Clock()
	{
		System.out.println("Clock");
		return new ModelAndView("Clock");
	}
	
	@RequestMapping("/NewStore")
	public ModelAndView NewStore(@RequestParam(value = "error", required = false) String error,HttpSession session)
	{
		ModelAndView model = new ModelAndView();
		System.out.println("NewStore");
		if (error != null) 
		{
			model.addObject("error", error);
		}
		model.setViewName("NewStore");
		return model;
	}
	
	@RequestMapping(value="/CreateStore")
	public ModelAndView CreateStore(Extphysicalstores obj,HttpSession session)
	{
		ModelAndView model = new ModelAndView();
		System.out.println("i am in CreateNewStore  "+ obj);
		if(obj!=null)
		{
			String storeNumber = obj.getSTORE_NUMBER();
			boolean status = CheckStoreNumberExist(storeNumber,session);
			if(status)
			{
				//NewStore("Store Number is already exist",session);
				model.addObject("error", "Store Number is already exist");
				model.addObject("obj", obj);
				model.setViewName("NewStore");
			}
			else
			{
				model.setViewName("CheckDescriptive");
			}
		}
		return model;
	}
	
	/*@RequestMapping(value="/CreateStore")
	public ModelAndView CreateStore(@RequestBody MultiValueMap<String,String> formData,HttpSession session)
	{
		
		System.out.println("i am in CreateNewStore");
		return new ModelAndView("CheckDescriptive");
	}*/
	
	/*@RequestMapping("/Login")
	public ModelAndView Login()
	{
		System.out.println("Login");
		return new ModelAndView("Login");
	}*/
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = "error", required = false) String error, @RequestParam(value = "logout", required = false) String logout, HttpServletRequest request) 
	{
		ModelAndView model = new ModelAndView();
		if (error != null) 
		{
			model.addObject("error", getErrorMessage(request, "SPRING_SECURITY_LAST_EXCEPTION"));
		}

		if (logout != null)
		{
			model.addObject("msg", "You've been logged out successfully.");
		}
		model.setViewName("login");
		
		System.out.println("login page");
		return model;

	}
	
	
	private String getErrorMessage(HttpServletRequest request, String key) {

		Exception exception = (Exception) request.getSession().getAttribute(key);

		String error = "";
		if (exception instanceof BadCredentialsException) {
			error = "Invalid username and password!";
		} else if (exception instanceof LockedException) {
			error = exception.getMessage();
		} else {
			error = "Invalid username and password!";
		}

		return error;
	}

	// for 403 access denied page
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied() {

		ModelAndView model = new ModelAndView();

		// check if user is login
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			System.out.println(userDetail);

			model.addObject("username", userDetail.getUsername());

		}

		model.setViewName("403");
		return model;

	}
	
	 private String getPrincipal()
	 {
	        String userName = null;
	        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	 
	        if (principal instanceof UserDetails) {
	            userName = ((UserDetails)principal).getUsername();
	        } else {
	            userName = principal.toString();
	        }
	        return userName;
	  }

	@RequestMapping("/QP")
	public ModelAndView QP()
	{
		System.out.println("QP");
		return new ModelAndView("QP");
	}
	
	@RequestMapping("/Assessment")
	public ModelAndView Assessment()
	{
		System.out.println("Assessment");
		return new ModelAndView("Assessment");
	}
	
	@RequestMapping("/page")
	public ModelAndView page(HttpSession session)
	{
		List<String> list = new ArrayList<String>();
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		list.add("e");
		list.add("f");
		System.out.println("page");
		session.setAttribute("list", list);
		
		return new ModelAndView("page");
	}
	/*@RequestMapping("/getData")
	public ModelAndView getData(HttpSession session)
	{
		List<String> list = new ArrayList<String>();
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		list.add("e");
		list.add("f");
		System.out.println("page");
		session.setAttribute("list", list);
		
		return new ModelAndView("page");
	}*/

	
	
	
	@RequestMapping("/AdminDashboard")
	public ModelAndView Admin()
	{
		List<String> engagementList = new ArrayList<>();
		engagementList.add("IKEA");
		engagementList.add("Capgemini");
		engagementList.add("A");
		engagementList.add("B");
		System.out.println("Admin");
		return new ModelAndView("AD",new ModelMap().addAttribute("Elist", engagementList));
	}
	
	@RequestMapping("/AddQue")
	public ModelAndView AddQue()
	{
		List<String> LevelList = new ArrayList<>();
		LevelList.add("Beginer");
		LevelList.add("Intermediate");
		LevelList.add("Expert");
		
		List<String> TypeList = new ArrayList<>();
		TypeList.add("MCQ");
		TypeList.add("DESCRIPTIVE");
		TypeList.add("MULTIPLES");
		ModelMap map = new ModelMap();
		map.addAttribute("LevelList", LevelList);
		map.addAttribute("TypeList", TypeList);
		
		return new ModelAndView("AddQuestions",map);
	}
	
	@RequestMapping("/takeTest")
	public ModelAndView takeTest()
	{
		return new ModelAndView("takeTest");
	}
	
	@RequestMapping("/CheckDescriptive")
	public ModelAndView CheckDescriptive()
	{
		return new ModelAndView("CheckDescriptive");
	}
	@RequestMapping("/angular")
	public ModelAndView angular()
	{
		return new ModelAndView("angular");
	}
	@RequestMapping("/Backbone")
	public ModelAndView Backbone()
	{
		return new ModelAndView("Backbone");
	}
	
	
	
	
	///////////////////AJAX calls//////////////////////////////////
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getAllNamesAndCountry", headers="Accept=*/*",  produces="application/json",method=RequestMethod.GET)
	@ResponseBody
	public  void getAllNamesAndCountry(HttpSession session,
            HttpServletResponse response )
	{	
		String json = new Gson().toJson("{name:'a',country:'c'}");
		response.setContentType("application/json");
        try {
			response.getWriter().write(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getData", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  int DeliverOrder(@RequestParam(value="CHARS") int index,HttpSession session )
	{	
		return index;
	}
	
	
	
	@RequestMapping(value = "/getCluster", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getClusterNames(@RequestParam(value="CHARS") String name,HttpSession session )
	{
		List<String> ClusterList = new ArrayList<>();
		ClusterList.add("a");
		ClusterList.add("b");
		ClusterList.add("c");
		ClusterList.add("d");
		return ClusterList;	
		
	}
	
	
	@RequestMapping(value = "/getProjects", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getProject(@RequestParam(value="CHARS") String name,HttpSession session )
	{
		List<String> ProjectList = new ArrayList<>();
		ProjectList.add("p");
		ProjectList.add("pa");
		ProjectList.add("pb");
		ProjectList.add("pc");
		return ProjectList;	
		
	}
	
	
	@RequestMapping(value = "/getQP", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getQP(@RequestParam(value="CHARS") String name,HttpSession session )
	{
		List<String> QPList = new ArrayList<>();
		QPList.add("QP1");
		QPList.add("QP2");
		QPList.add("QP3");
		QPList.add("QP4");
		return QPList;	
		
	}
	
	
	@RequestMapping(value = "/getAllDescriptive", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<Descriptive> getAllDescriptive(HttpSession session )
	{
		List<Descriptive> DescriptiveAnsList = new ArrayList<Descriptive>();
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP2", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP3", "UN"));
		return DescriptiveAnsList;	
		
	}
	
	@RequestMapping(value = "/getAllDescriptiveByQpId", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<DescritpiveAnswer> getAllDescriptiveByQpId(@RequestParam(value="projectName") String projectName,@RequestParam(value="QPtitle") String QPtitle,@RequestParam(value="userName") String userName,HttpSession session )
	{
		System.out.println(projectName+QPtitle+userName);
//////////////get all questions from user ans with decriptive ans
		List<DescritpiveAnswer> DescriptiveAnsList = new ArrayList<DescritpiveAnswer>();
		DescriptiveAnsList.add(new DescritpiveAnswer("q1", "Ans1", "UN", 3));
		DescriptiveAnsList.add(new DescritpiveAnswer("q2", "Ans2", "UN", 4));
		DescriptiveAnsList.add(new DescritpiveAnswer("q3", "Ans3", "UN", 5));
		DescriptiveAnsList.add(new DescritpiveAnswer("q4", "Ans4", "UN", 6));
		
		return DescriptiveAnsList;
		
	}
	
	
	@RequestMapping(value = "/getAllDescriptiveQpByProject", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<Descriptive> getAllDescriptiveQpByProject(@RequestParam(value="projectName") String projectName,HttpSession session )
	{
//////////////get all questions from user ans with decriptive ans
		List<Descriptive> DescriptiveAnsList = new ArrayList<Descriptive>();
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP2", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP3", "UN"));
		
		return DescriptiveAnsList;	
	}
	
	
	
	@RequestMapping(value = "/getAllCountryCode", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getAllCountryCode(HttpSession session )
	{
//////////////get all questions from user ans with decriptive ans
		List<String> CountryCodeList = new ArrayList<String>();
		
		CountryCodeList.add("US");
		CountryCodeList.add("IND");
		CountryCodeList.add("PAK");
		CountryCodeList.add("NK");
		CountryCodeList.add("Uk");
		
		return CountryCodeList;	
	}
	
	@RequestMapping(value = "/getAllStoreType", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getAllStoreType(HttpSession session )
	{
//////////////get all questions from user ans with decriptive ans
		List<String> CountryCodeList = new ArrayList<String>();
		
		CountryCodeList.add("A");
		CountryCodeList.add("B");
		CountryCodeList.add("C");
		CountryCodeList.add("D");
		CountryCodeList.add("E");
		
		return CountryCodeList;	
	}
	
	
	@RequestMapping(value = "/CheckStoreNumberExist", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  boolean CheckStoreNumberExist(@RequestParam(value="StoreNumber") String StoreNumber,HttpSession session )
	{
//////////////get all questions from user ans with decriptive ans
		List<String> CountryCodeList = new ArrayList<String>();
		
		CountryCodeList.add("ABC");
		CountryCodeList.add("Basd");
		CountryCodeList.add("Casd");
		CountryCodeList.add("D");
		CountryCodeList.add("E");
		
		
		
		
		
		
		return (CountryCodeList.contains(StoreNumber))? true : false ;
		
		///////////////////////////////////////

		
		
		
		
		
		
		
	}
	

}
