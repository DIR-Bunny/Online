package com.cap.controller;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App
{
    @SuppressWarnings("resource")
	public static void main( String[] args ) throws Exception
    {
    	new ClassPathXmlApplicationContext("quartz-context.xml");
    }
}