package com.cap.controller;

public class Descriptive 
{
	private String projectName;
	private String qpTitle;
	private String userName;
	public Descriptive() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Descriptive(String projectName, String qpTitle, String userName) {
		super();
		this.projectName = projectName;
		this.qpTitle = qpTitle;
		this.userName = userName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getQpTitle() {
		return qpTitle;
	}
	public void setQpTitle(String qpTitle) {
		this.qpTitle = qpTitle;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "Descriptive [projectName=" + projectName + ", qpTitle=" + qpTitle + ", userName=" + userName + "]";
	}
	
}
