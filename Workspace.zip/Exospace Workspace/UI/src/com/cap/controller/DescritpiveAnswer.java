package com.cap.controller;

public class DescritpiveAnswer 
{
	private String question;
	private String userAns;
	private String userName;
	private int MaxMarks;
	public DescritpiveAnswer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DescritpiveAnswer(String question, String userAns, String userName, int maxMarks) {
		super();
		this.question = question;
		this.userAns = userAns;
		this.userName = userName;
		MaxMarks = maxMarks;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getUserAns() {
		return userAns;
	}
	public void setUserAns(String userAns) {
		this.userAns = userAns;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getMaxMarks() {
		return MaxMarks;
	}
	public void setMaxMarks(int maxMarks) {
		MaxMarks = maxMarks;
	}
	@Override
	public String toString() {
		return "DescritpiveAnswer [question=" + question + ", userAns=" + userAns + ", userName=" + userName
				+ ", MaxMarks=" + MaxMarks + "]";
	}
	
	
}
