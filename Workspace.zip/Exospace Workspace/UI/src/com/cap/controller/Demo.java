package com.cap.controller;

import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;

@Controller
public class Demo 
{

	@Scheduled(cron="10 * * * * ?")
	public void scheduledTask()
	{
		System.err.println("I am running "+new Date());
		
	}
}
