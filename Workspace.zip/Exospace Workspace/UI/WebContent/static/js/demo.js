/**
 * 
 */


$(document).ready(function() 
	{
		alert("asdasdasd");
	});