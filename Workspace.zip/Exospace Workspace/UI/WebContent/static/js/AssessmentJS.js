/**
 * 
 */

$(document).ready(function() 
	{
		$(".close").click(function() 
		{
			$("#myAlert").alert();
		});
	});