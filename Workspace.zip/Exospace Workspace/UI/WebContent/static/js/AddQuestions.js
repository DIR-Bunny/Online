/**
 * 
 */

$(document).ready(function() 
{
	
	///////////// Add new option field method called on click
	$('.btn-option-plus').click(function() 
	{
		var status=0,size=0;
		
		//// check for all input fields 
		$('input[name="OptionText"]').each(function() 
		{
			/*if ( $( this ).is( "#stop" ) ) */
			if($( this ).attr("disabled"))     ////////// input fields disabled do nothing
			{
			}
			else if($(this).val() == "")               ////////// input fields not disabled and not having any value
			{
				size++;
				$('#OptionAlert').removeClass('collapse');   //////show error
				return;
			}
			else
			{
				status++;
				size++;
			}
			
		});
		
		if(status == size && size !=0)    //////// if all correct add new option fields 
		{
			var divStart = '<div class="input-group">';
			var inputTag	=  '<input class="form-control" type="text"  name="OptionText" placeholder="Enter Option">';
			var spanStart = '<span class="input-group-btn">';
			var MinusButton = '<button type="button" class="btn btn-danger btn-option-minus">'
					          +'<span class="glyphicon glyphicon-minus"></span>'
					          +'</button>';
			var spanEnd = '</span>';
			
			////// dynamically get the id selected 
			var selected = $('#typeId').find("option:selected").val();
			selected = "#"+selected+"optoinsDiv";
			
			///// append dynamically created div 
			$(selected).append(divStart+inputTag+spanStart+MinusButton+spanEnd);
		}	
		
		
		
		
		
	});
	
	/////// to remove option field on click of minus button
	$(document).on('click','.btn-option-minus',function() 
	{
		//// remove closest div with the class name input-group
	     $(this).closest("div.input-group").remove();
	});
	
	
////// on click of the Correct Answer--->> fill correct ans select from inputs
	$('.CorrectAns').on('show.bs.select', function()
	{
		var selected = $('#typeId').find("option:selected").val();
		selected = "#"+selected+"CorrectOption";
		 $(selected).text('');
		 
		 $('input[name="OptionText"]').each(function() 
			{
			 	if($( this ).attr("disabled"))
				{
				}
			 	else if($(this).val() == "")
				{
			 		$('#OptionAlert').removeClass('collapse');
					return;
				}
			 	else
		 		{
			 		var Option = $(this).val();
					 console.log(Option);
					 $(selected).append("<option value='"+Option+"'>"+Option+"</option>");
		 		}
			});

		$(selected).selectpicker('refresh');
	});
	
	
////// Based on typeId show Div
$('#typeId').on('change', function()
{	
	var Levelselected = $('#LevelId').find("option:selected").val();
	if(Levelselected == "")
	{
		//////clear the type selector 
		$('#typeId option').prop("selected",false);
		$('#typeId').selectpicker('refresh');
		
		//// show error 
		$('#LevelSelectAlert').removeClass('collapse');
		
		
	}
	else
	{
		//////get selected type id
		var selected = $(this).find("option:selected").val();
	    $('.'+selected).removeClass('collapse');
	    
	    ///// remove disabled input from that div
	    var name = "div."+selected;
	     $( name ).find( "input" ).removeAttr( "disabled" );
	
	}
});


///////Reset dives on click of typeId Selector
$('#typeId').on('show.bs.select', function()
{
	//// reset all divs to their default postion
	$('.MCQ').addClass('collapse');
	 $( '.MCQ' ).find( "input" ).attr( "disabled","disabled" );
	$('.DESCRIPTIVE').addClass('collapse');
	$( '.DESCRIPTIVE' ).find( "input" ).attr( "disabled","disabled" );
	$('.MULTIPLES').addClass('collapse');
	$( '.MULTIPLES' ).find( "input" ).attr( "disabled","disabled" );
});
 
////////////All alert close functions
$('.close').click(function() 
{
	var AlertId = $(this).closest('div').attr('id');
	 $("#"+AlertId).addClass('collapse');
	//$('#DropDownAlert').addClass('collapse');
});
	
});