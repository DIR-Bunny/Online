/**
 * 
 */
$("document").ready(function()
{	

//////showDescriptive panel show all data
	$('#showDescriptive').click(function(e)
	{
		var ProjectName = [];
		$('#UserAnsContaintDiv').addClass('collapse');
		//$('#CheckTable').addClass('collapse');
		
		var tr = "<tr>";
		
		var trEnd = "</tr>";
		$.getJSON("/UI/getAllDescriptive",
				function(Data) 
				{
					$('#QuestionName').text('');
					$('#ProjectName').text('');
					var Row =  $('#DescriptiveTable').text('');
					
					var projectNameList = [];
					
					for ( var index in Data) 
					{
						projectNameList.push(Data[index].projectName);
					}
					
					for(var index = 0; index < Data.length; index++)
					{
						var temp = 0;
						for (var i = index; i < Data.length; i++) 
						{
							var j = i+1;
							if(j<Data.length)
							{
								if((Data[i].projectName == Data[j].projectName) )
								{
									temp++;
								}
							}
							
						}
						if(temp == 0)
						{
							$('#ProjectName').append("<option value='"+Data[index].projectName+"'>"+Data[index].projectName+"</option>");
						}
					}
					
					for(var index in Data)
					{
						var data = "<td>"+Data[index].projectName+"</td><td>"+Data[index].qpTitle+"</td><td>"+Data[index].userName+"</td><td><button class='btn btn-default viewButton' id='viewButton'><i class='fa fa-eye' aria-hidden='true'></i></button></td>";
						
						Row.append(tr+data+trEnd);
						$('#MainContaintTable').removeClass('collapse');
					}
					$('#ProjectName').selectpicker('refresh');
					
					
				}
			);
		$('#AllSelectors').removeClass('collapse');
	});
	
	
///////////////////onclick of eye button dynamically created
	$( document ).on( "click", "button.viewButton", function() 
	{
		var SelectedData = "";
	  
	  $(this).closest('tr').find('td').each(function() 
	  {
		  var temp=$(this).text();
		  
		  SelectedData += temp + ",";
	  });
	  
	  var Data = SelectedData.split(",");
	  var projectName = Data[0];
	  var QPTitle  = Data[1];
	  var userName = Data[2];
	  
	  
	  $('#MainContaintTable').addClass('collapse');
	  
	  $.getJSON("/UI/getAllDescriptiveByQpId",
			  {projectName :projectName,QPtitle: QPTitle, userName : userName },
				function(Data) 
				{
					var divStart = '<div class="input-group">';
					
					
//// try to put dynamically max marks					
					
					var divEnd = '</div>';
				  
					var updateMarksButton = "<button class='btn btn-primary UpdateMarks'> Update Marks&nbsp;<i class='fa fa-check-square-o' aria-hidden='true'></i></button>" ;
					
				  $('#CheckTable').text('');
				  
				  for ( var index in Data) 
				  {
					  var minusButton = '<span class="input-group-btn">'+
										  '<button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="'+ Data[index].question+'">'+
										  '<span class="glyphicon glyphicon-minus"></span></button></span>';
					  
					  var MarksInput =  '<input	 type="text" name="'+ Data[index].question+'" class="input-number" value="0" min="0" max="'+ Data[index].maxMarks+'">'

					  var plusButton = '<span class="input-group-btn">'+
										  '<button type="button" class="btn btn-default btn-number" data-type="plus" data-field="'+ Data[index].question+'">'+
										  '<span class="glyphicon glyphicon-plus"></span></button></span>';


					  var Marks = divStart + minusButton + MarksInput + plusButton + divEnd;
					  
					  
					  
					  $('#CheckTable').append("<tr><td>" + Data[index].question+ "</td><td>" +  Data[index].userName + "</td><td>" +  Data[index].userAns + "</td><td>"+ Marks +"</td><td>"+ updateMarksButton + "</td></tr>");
				  }
				  $('#UserAnsContaintDiv').removeClass('collapse');
				}
			);
	});
	
	
//////on + or - button click
	$( document ).on( "click", "button.btn-number", function(e) 
	{
		$(this).closest('tr').find('td').each(function() 
				  {
					 // var temp=$(this).text();
			
					if($(this).text() == ' Update Marks&nbsp;')
						{
							console.log("inside");
							console.log($(this).text())
						}
					else
						{
							console.log($(this).text())
						}
					
				  });
		console.log($(this).next().next().html);
		e.preventDefault();
	    
	    fieldName = $(this).attr('data-field');
	    type      = $(this).attr('data-type');
	    
	    ///// get perticuler input tag by tree structure
	    
	    var input = $("input[name='"+fieldName+"']");
	    var currentVal = parseInt(input.val());
	    if (!isNaN(currentVal)) 
	    {
	        if(type == 'minus') 
	        {
	            
	            if(currentVal > input.attr('min')) 
	            {
	                input.val(currentVal - 1).change();
	            } 
	            if(parseInt(input.val()) == input.attr('min')) 
	            {
	                $(this).attr('disabled', true);
	            }

	        } 
	        else if(type == 'plus') 
	        {
	            if(currentVal < input.attr('max'))
	            {
	                input.val(currentVal + 1).change();
	            }
	            if(parseInt(input.val()) == input.attr('max'))
	            {
	                $(this).attr('disabled', true);
	            }

	        }
	    }
	    else 
	    {
	        input.val(0);
	    }
	});
	
	
////when admin try to input wrong input from keyboard and fails return origninal value
	$( document ).on( "focusin", ".input-number", function()
		{
		   $(this).data('oldValue', $(this).val());
		});
	
	
	
	//// when admin try to input wrong input from keyboard
	$( document ).on( "change", ".input-number", function()
	{ 
	    minValue =  parseInt($(this).attr('min'));
	    
	    maxValue =  parseInt($(this).attr('max'));
	    valueCurrent = parseInt($(this).val());
	    
	    name = $(this).attr('name');
	    if(valueCurrent >= minValue)
	    {
	        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
	    } 
	    else 
	    {
	        alert('Sorry, the minimum value was reached');
	        $(this).val($(this).data('oldValue'));
	        return false;
	    }
	    if(valueCurrent <= maxValue) 
	    {
	        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
	    } 
	    else 
	    {
	        alert('Sorry, the maximum value was reached');
	        $(this).val($(this).data('oldValue'));
	        return false;
	    }
	    
	    
	});

	
//////Based on QuestionName show Div
$('#QuestionName').on('change', function()
{	
	$('#UserAnsContaintDiv').addClass('collapse');
		var selected = $('#QuestionName').val();
		var tr = "<tr>";
		var trEnd = "</tr>";
		$.getJSON("/UI/getAllDescriptive",
				function(Data) 
				{
					$('#QuestionName').text('');
					var Row =  $('#DescriptiveTable').text('');
					for(var index in Data)
					{

						$('#QuestionName').append("<option value='"+Data[index].qpTitle+"'>"+Data[index].qpTitle+"</option>");
						if(selected == Data[index].qpTitle)
						{
							var data = "<td>"+Data[index].projectName+"</td><td>"+Data[index].qpTitle+"</td><td>"+Data[index].userName+"</td><td><button class='btn btn-default viewButton' id='viewButton'><i class='fa fa-eye' aria-hidden='true'></i></button></td>";
							
							Row.append(tr+data+trEnd);
							$('#MainContaintTable').removeClass('collapse');
						}
						
					} 
					$('#QuestionName').selectpicker('refresh');
					
					
				}
			);
});


//////Based on ProjectName show Div
$('#ProjectName').on('change', function()
{	
	$('#UserAnsContaintDiv').addClass('collapse');
		var selected = $('#ProjectName').val();
		var tr = "<tr>";
		var trEnd = "</tr>";
		$.getJSON("/UI/getAllDescriptiveQpByProject",
				{projectName : selected},
				function(Data) 
				{
					$('#QuestionName').text('');
					var Row =  $('#DescriptiveTable').text('');
					for(var index in Data)
					{

						$('#QuestionName').append("<option value='"+Data[index].qpTitle+"'>"+Data[index].qpTitle+"</option>");
						var data = "<td>"+Data[index].projectName+"</td><td>"+Data[index].qpTitle+"</td><td>"+Data[index].userName+"</td><td><button class='btn btn-default viewButton' id='viewButton'><i class='fa fa-eye' aria-hidden='true'></i></button></td>";
							
						Row.append(tr+data+trEnd);
						$('#MainContaintTable').removeClass('collapse');
						
					} 
					$('#QuestionName').selectpicker('refresh');
					
					
				}
			);
});
	

////////////////////on click dynamically created updateMarks Button
$( document ).on( "click", "button.UpdateMarks", function() 
{	
	var SelectedData = "";
	  
	  $(this).closest('tr').find('td').each(function() 
	  {
		  var temp=$(this).text();
		  
		  SelectedData += temp + ",";
	  });
	  
	  
	  $(this).closest('tr').find('input').each(function() 
	  {
		  var temp=$(this).val();
		  
	  });
	  
	  var Data = SelectedData.split(",");
	  var projectName = Data[0];
	  var QPTitle  = Data[1];
	  var userName = Data[2];
	  
	  
	  $.getJSON("/UI/getAllDescriptiveQpByProject",
				{projectName : SelectedData},
				function(Data) 
				{
					for(var index in Data)
					{
						
					} 
					
				}
			);
});

/////close all alerts
	$('.close').click(function() 
	{
		var AlertId = $(this).closest('div').attr('id');
		 $("#"+AlertId).addClass('collapse');
		//$('#DropDownAlert').addClass('collapse');
	});
					

});




