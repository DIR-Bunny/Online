/**
 * 
 */

$("document").ready(function()
{

$( '#formId' ).find( 'input' ).click(function() 
{

	 var status = 0;
	 var size = 0;
	 $('input').each(function() 
	{
		 if($(this).prop("type") == "radio")
		 {
			 if($(this). prop("checked") == true)
			 {
				 //alert("123");
				 status++;
			 }
			 
		 }
		 if($(this).prop("type") == "checkbox")
		 {
			 if($(this). prop("checked") == true)
			 {
				 //alert("123");
				 status++;
			 }
		 }
		 if($(this).prop("type") == "text")
		 {
			 console.log("Text Type");
			 if($(this).val().length > 0)
			 {
				 status++;
			 }
		 
		 }
		 size++;
	});
	 
	 console.log("Size "+ size);
	 console.log("Checked  "+ status);
	 var percentage = parseInt((status/size)*100);

	 $('.progress-bar').css('width', percentage+'%');
	 $('.progress-bar').text(percentage+'%'); 

});
	
	
	
 
});