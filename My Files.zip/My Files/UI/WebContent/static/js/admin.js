/**
 * 
 */

function checkEngagement()
{
	var EngagementName = $('#EngagementName').val();
	$.getJSON("/UI/getCluster",
			{CHARS : EngagementName},
			function(Data) 
			{
				$('#cluster').text('');
				
				for(var index in Data)
				{
					$('#cluster').append("<option value='"+Data[index]+"'>"+Data[index]+"</option>");
				} 
				$('#cluster').selectpicker('refresh');
			}
		);	
}

function checkCluster(ClusterName)
{
	var ClusterName = $('#cluster').val();
	$.getJSON("/UI/getProjects",
			{CHARS : ClusterName},
			function(Data) 
			{
				$('#project').text('');
				for(var index in Data)
				{
					$('#project').append("<option value='"+Data[index]+"'>"+Data[index]+"</option>");
				} 
				$('#project').selectpicker('refresh');
			}
		);	
}

function checkProject()
{
	var ProjectName = $('#project').val();
	$.getJSON("/UI/getQP",
			{CHARS : ProjectName},
			function(Data) 
			{
				$('#QPdiv').text('');
				
				$('#QPdiv').append('<table class="table table-hover table-condensed"><tr><th style="width:auto;">QP Id</th><th style="width:auto;">QP Title</th><th style="width:auto;">Delete QP</th></th></tr><tbody id="AllData1">');
				$('#AllData1').text('');
				for(var index in Data)
				{
					$('#AllData1').append('<tr><td>'+Data[index]+'</td><td>'+Data[index]+'</td><td><button onclick="DeleteQP('+Data[index]+')" class="btn btn-danger btn-md" type="button"><i class="fa fa-trash-o"></i></button></td></tr>');
					
				} 
				
				$('#QPdiv').append('</tbody></table>');
			}
		);	
}



$("document").ready(function()
{	
	////// on + or - button click
	$('.btn-number').click(function(e)
	{
		e.preventDefault();
	    
	    fieldName = $(this).attr('data-field');
	    type      = $(this).attr('data-type');
	    
	    ///// get perticuler input tag by tree structure
	    
	    var input = $("input[name='"+fieldName+"']");
	    var currentVal = parseInt(input.val());
	    if (!isNaN(currentVal)) 
	    {
	        if(type == 'minus') 
	        {
	            
	            if(currentVal > input.attr('min')) 
	            {
	                input.val(currentVal - 1).change();
	            } 
	            if(parseInt(input.val()) == input.attr('min')) 
	            {
	                $(this).attr('disabled', true);
	            }

	        } 
	        else if(type == 'plus') 
	        {

	            if(currentVal < input.attr('max'))
	            {
	                input.val(currentVal + 1).change();
	            }
	            if(parseInt(input.val()) == input.attr('max'))
	            {
	                $(this).attr('disabled', true);
	            }

	        }
	    }
	    else 
	    {
	        input.val(0);
	    }
	});
	
	
////when admin try to input wrong input from keyboard and fails return origninal value
	$('.input-number').focusin(function()
		{
		   $(this).data('oldValue', $(this).val());
		});
	
	
	
	//// when admin try to input wrong input from keyboard
	$('.input-number').change(function() 
	{
	    
	    minValue =  parseInt($(this).attr('min'));
	    maxValue =  parseInt($(this).attr('max'));
	    valueCurrent = parseInt($(this).val());
	    
	    name = $(this).attr('name');
	    if(valueCurrent >= minValue)
	    {
	        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
	    } 
	    else 
	    {
	        alert('Sorry, the minimum value was reached');
	        $(this).val($(this).data('oldValue'));
	        return false;
	    }
	    if(valueCurrent <= maxValue) 
	    {
	        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
	    } 
	    else 
	    {
	        alert('Sorry, the maximum value was reached');
	        $(this).val($(this).data('oldValue'));
	        return false;
	    }
	    
	    
	});
	

//////// on QuestionsManually click
	$('#QuestionsManually').click(function() 
	{
		$.getJSON("/UI/getAllQuestions",
				{CHARS : ProjectName},
				function(Data) 
				{
					$('#QPdiv').text('');
					
					$('#QPdiv').append('<table class="table table-hover table-condensed"><tr><th style="width: 10%;">Select</th><th style="width: 20%;">Question Level</th><th style="width: 40%;">Question</th><th style="width: 20%;">Options</th><th style="width: 10%;">Correct Answer</th></tr><tbody id="AllData1">');
					$('#AllData1').text('');
					for(var index in Data)
					{
						$('#AllData1').append('<tr><td><input class=form-control type="checkbox" name="Question" value=""></td><td></td><td></td><td></td><td></td>');
						
					} 
					
					$('#QPdiv').append('</tbody></table>');
				}
			);	
	})
	
	
/////////validation for add question paper
	$('#AddQP').click(function() 
	{
	
		/*$("#DropDownAlert").hide();
		$("#CheckBoxAlert").hide()*/;
		var EngagementName = $('#EngagementName').val();
		var ClusterName = $('#cluster').val();
		var ProjectName = $('#project').val();
		var QuestionPaperTitle = $('#QuestionPaperTitle').val();
		
		if (EngagementName== "" || ClusterName=="" || ProjectName=="") 
		{
			//alert("All Fields are mandetory! Please select from DropDowns");
			//$("#DropDownAlert").show();
			$('#DropDownAlert').removeClass('collapse');
			window.scrollTo(0,0);
			return false;
		}
		else 
		{
			var status = 0;
			
			$('input[name="Question"]').each(function() 
			{
				 if($(this). prop("checked") == true)
				 {
					 status++;
				 }
			});
			 
			/*var group =document.getElementById("AddQuestionForm").elements["Question"]; //document.AddQuestion.OptionText;
			alert(group);
			for (var i=0; i<group.length; i++) 
			{
				if (group[i].checked)
				{
					alert("checked");
				}
			}*/
			if (QuestionPaperTitle == "") 
			{
				$('#QuestionPaperName').removeClass('collapse');
				window.scrollTo(0,0);
				return false;
			}
			if (status < 10)
			{
				/////Retain all selected values from select 
				$('#EngagementName').selectpicker('val', EngagementName);
				$('#cluster').selectpicker('val', ClusterName);
				$('#project').selectpicker('val', ProjectName);
				//alert("No Checkbox is checked for Questions At least 10 Must be checked");
				//$("#CheckBoxAlert").show();
				$('#CheckBoxAlert').removeClass('collapse');
				window.scrollTo(0,0);
				return false;
			}
			
		}
		return true;
	});
	
	
	
	$('#getRandomly').click(function() 
	{
		//$("#DropDownAlertModal").hide();
		var QuestionLevel = $('#QuestionLevel').val();
		if (QuestionLevel == "") 
		{
			//$("#DropDownAlertModal").show();
			$('#DropDownAlertModal').removeClass('collapse');
			window.scrollTo(0,0);
			return false;
		}
		else
		{
			///////perform ajax to show selected questions randomly and then dismiss modal
			
		}
		 return true;
	    
	});

	
///////// on click get randomly validation
	$('#selectRandomly').click(function() 
	{
		/*$("#DropDownAlert").hide();
		$("#CheckBoxAlert").hide();*/
		var EngagementName = $('#EngagementName').val();
		var ClusterName = $('#cluster').val();
		var ProjectName = $('#project').val();
		 
		
		if (EngagementName== null || ClusterName==null || ProjectName==null) 
		{
			//alert("All Fields are mandetory! Please select from DropDowns");
			//$("#DropDownAlert").show();
			$('#DropDownAlert').removeClass('collapse');
			window.scrollTo(0,0);
			return false;
		}   
	});
	
	
	
	
////////////All alert close functions
	$('.close').click(function() 
	{
		var AlertId = $(this).closest('div').attr('id');
		 $("#"+AlertId).addClass('collapse');
		//$('#DropDownAlert').addClass('collapse');
	});
	
	
});




