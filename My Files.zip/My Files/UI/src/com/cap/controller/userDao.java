package com.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class userDao 
{
	@Autowired
    private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public User findByUserName(String username) {

		Session s =  sessionFactory.getCurrentSession();
		List<User> users = new ArrayList<User>();

		String hql = "from User where user_id = :uname";
		users= (List<User>) s.createQuery(hql).setParameter("uname", username).list();
		
		if (users.size() > 0) 
		{
			System.out.println(users.size()+"  "+users.get(0).getPassword());
			return users.get(0);
		} else 
		{
			return null;
		}

	}
}
