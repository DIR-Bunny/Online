package com.cap.controller;

public class QP 
{
	private String engagementName;
	private String clusterName;
	private String projectName;
	
	
	
	public QP(String engagementName, String clusterName, String projectName) {
		super();
		this.engagementName = engagementName;
		this.clusterName = clusterName;
		this.projectName = projectName;
	}
	public QP() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEngagementName() {
		return engagementName;
	}
	public void setEngagementName(String engagementName) {
		this.engagementName = engagementName;
	}
	public String getClusterName() {
		return clusterName;
	}
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	@Override
	public String toString() {
		return "QP [engagementName=" + engagementName + ", clusterName=" + clusterName + ", projectName=" + projectName
				+ "]";
	}

	
	
	
}
