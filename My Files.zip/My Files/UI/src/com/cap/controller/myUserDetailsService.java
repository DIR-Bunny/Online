package com.cap.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service("myUserDetailsService")
public class myUserDetailsService implements UserDetailsService
{
	@Autowired
    private userDao dao;
     
	public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException 
	{

		System.out.println("inside");
		System.out.println("Logged in "+" "+username);
		com.cap.controller.User user = dao.findByUserName(username);
		
		for (UserRole role : user.getUserRoles()) {
			System.out.println("user role "+role.get_role());
		}
		List<GrantedAuthority> authorities = buildUserAuthority(user.getUserRoles());
		
		
		return (UserDetails) buildUserForAuthentication(user, authorities);

	}

	private org.springframework.security.core.userdetails.User  buildUserForAuthentication(com.cap.controller.User user,
			List<GrantedAuthority> authorities) {
			return new org.springframework.security.core.userdetails.User(user.getUsername(),
					user.getPassword(), user.isEnabled(),
                    true, true, true, authorities);
		}

	private List<GrantedAuthority> buildUserAuthority(Set<UserRole> userRoles) {

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

		// Build user's authorities
		for (UserRole userRoles1 : userRoles) 
		{
			setAuths.add(new SimpleGrantedAuthority(userRoles1.get_role()));
		}

		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);

		return Result;
	}


}
