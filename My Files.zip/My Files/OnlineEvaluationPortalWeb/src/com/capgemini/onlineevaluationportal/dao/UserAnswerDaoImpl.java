package com.capgemini.onlineevaluationportal.dao;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.mapping.Property;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.entity.UserAnswer;

@Repository
public class UserAnswerDaoImpl implements UserAnswerDao{
	private static Logger logger = Logger.getLogger(UserAnswerDaoImpl.class);

	@Autowired
	public SessionFactory sessionFactory;
	
	@Override
	public boolean storeUserAnswers(List<UserAnswer> answers){
		logger.debug("Entering storeUserAnswers(answers)");
		
		int id, count=0;
		for(UserAnswer ans : answers){
			id = (int) sessionFactory.getCurrentSession().save(ans);
			if(id > 0){
				count++;
			}
		}
		if(count == answers.size()){
			logger.debug("Exiting storeUserAnswers(answers)");
			return true;
		}else{
			logger.debug("Exiting storeUserAnswers(answers)");
			return false;
		}	
	}
	
	@Override
	public void setUserAnswerResponse(List<UserAnswer> userAnswerList)
	{
		logger.debug("Entering setUserAnswerResponse(userAnswerList)");
		//Session s  = sessionFactory.getCurrentSession();
		//Transaction tx = s.beginTransaction();
		if(userAnswerList != null)
		{
			for (UserAnswer userAnswer : userAnswerList)
			{
				sessionFactory.getCurrentSession().merge(userAnswer);
			}
		}	logger.debug("Exiting setUserAnswerResponse(userAnswerList)");
		//tx.commit();

	}

	@SuppressWarnings("unchecked")
	@Override
	public void setMarkScoredByUser(User user,int questionPaperId)
	{
		logger.debug("Entering setMarkScoredByUser(user,questionPaperId)");
		//// get the list of question Id from correct ans 
		////String sql = "select user_answer.question_id from user_answer join question_answer on question_answer.correct_answer = user_answer.user_answer";
		/*String sql = "from user_answer join question_answer with question_answer.correct_answer = user_answer.user_answer";
		Query query = sessionFactory.getCurrentSession().createQuery(sql);
		
		List<UserAnswer> userAnswer = query.list();*/
		
		/*Session s = sessionFactory.getCurrentSession();
		Transaction tx = s.beginTransaction();
		String sql = "CALL UpdateMarksByUserId(:userId,:questionPaperId)";
		Query query = s.createQuery(sql);
		query.setString("userId", user.getUserId());
		query.setInteger("questionPaperId", questionPaperId);
		int flag = query.executeUpdate();
		tx.commit();*/
		
		
		//Session s = sessionFactory.getCurrentSession();
		//Transaction tx = s.beginTransaction();
		
		/*String sql = "UPDATE UserAnswer ua INNER JOIN QuestionAnswer qa "+  
						"INNER JOIN Question q "+ 
						"SET ua.markScored = Question.mark "+
						"WHERE ua.user.userId  = :userId and ua.questionPaper.questionpaperId = :questionPaperId";*/
		
		/*String sql = "UPDATE user_answer INNER JOIN question_answer  on user_answer.user_answer = question_answer.correct_answer "+ 
						"INNER JOIN question on question_answer.question_id = question.question_id " +
						"SET user_answer.mark_scored = question.mark "+
						"WHERE user_answer.userId = :userId and user_answer.questionpaper_id = :questionPaperId";

		Query q = sessionFactory.getCurrentSession().createSQLQuery(sql);*/
		Query q = sessionFactory.getCurrentSession().getNamedQuery("HQL_UPDATE_MARKS_BY_USER_ID");
		q.setString("userId", user.getUserId());
		q.setInteger("questionPaperId", questionPaperId);
		
		int flag = q.executeUpdate();
		//System.out.println("Marks updated status " + flag);	
		logger.debug("Exiting setMarkScoredByUser(user,questionPaperId)");
	}

	@Override
	public List<QuestionAnswer> getCorrectAnswers(List<Question> QuestionIdList)
	{
		logger.debug("Entering getCorrectAnswers(QuestionIdList)");
		logger.debug("exiting getCorrectAnswers(QuestionIdList)");
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public double calculateTotalScoreByUserId(UserAnswer userAnswer) 
	{
		logger.debug("Entering calculateTotalScoreByUserId(userAnswer)");
		Query q = null;
		int qpId = userAnswer.getQuestionPaper().getQuestionpaperId();
		String userId = userAnswer.getUserId();
		
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(UserAnswer.class);
		
		cr.setProjection(Projections.sum("markScored"));
		cr.add(Restrictions.eq("userId", userId));
		cr.add(Restrictions.eq("questionPaper", new QuestionPaper(qpId)));
		
		Long studentScore = (Long) cr.uniqueResult();
		
		q = sessionFactory.getCurrentSession().getNamedQuery("HQL_GET_MARKS_OG_QP_BY_QPID");
		q.setInteger("QpaperId", userAnswer.getQuestionPaper().getQuestionpaperId());
		BigDecimal marks = (BigDecimal) q.uniqueResult();
		
		double totalMarks = marks.doubleValue();
		logger.debug("exiting calculateTotalScoreByUserId(userAnswer)");
		return ((studentScore/totalMarks)*100);
	}

	
	

	
}
