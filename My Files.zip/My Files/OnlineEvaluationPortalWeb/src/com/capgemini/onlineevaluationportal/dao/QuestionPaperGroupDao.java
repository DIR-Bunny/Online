package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionPaperGroup;

public interface QuestionPaperGroupDao {

	public Integer createQuestionPaperGroup(QuestionPaperGroup qpGroup);
	
	public Integer removeQuestionPaperGroup(QuestionPaperGroup qpGroup);
	
	public void addQPtoQPGroup(int qpId, int qpGroupId);
	
	public List<QuestionPaper> getQuestionPapers(int groupId);
	
	public QuestionPaperGroup getQuestionPaperGroup(int groupId);
}
