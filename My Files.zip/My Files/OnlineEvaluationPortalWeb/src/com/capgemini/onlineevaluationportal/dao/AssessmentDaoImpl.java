package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.capgemini.onlineevaluationportal.entity.Assessment;
import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.entity.User;


@Repository
public class AssessmentDaoImpl implements AssessmentDao
{
	private static Logger logger = Logger.getLogger(AssessmentDaoImpl.class);
	
	@Autowired
	public SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Assessment> showAllAttemptedTestByUserId(User user)
	{	
		
		logger.debug("Entering showAllAttemptedTestByUserId(user)");
		
		ExamSchedule examSchedule = GetExamScheduleRecord(user);
		String sql = "select * from assessment where user_id= :user_id and questionpaper_id= :questionpaper_id";
		Query query = sessionFactory.getCurrentSession().createQuery(sql);
		
		query.setString("user_id", examSchedule.getUser().getUserId());
		query.setInteger("questionpaper_id", examSchedule.getQuestionPaper().getQuestionpaperId());
		logger.debug("Exiting showAllAttemptedTestByUserId(user)");
		return query.list();
	}

	@SuppressWarnings("unused")
	@Override
	public void setTotalScoreByUserId(User user)
	{	
		logger.debug("Entering setTotalScoreByUserId(user)");
		String sql = "";
		Query query = null;
		
		
		ExamSchedule examSchedule = GetExamScheduleRecord(user);
		
		/*if(examSchedule.getNoOfAttempts() < 3)
		{*/
			sql = "insert into assessment(questionpaper_id,user_id,score) values (:questionpaper_id , :user_id, (select sum(user_answer.mark_scored) from user_answer where user_answer.questionpaper_id = :questionpaper_id1))";
			
			query = sessionFactory.getCurrentSession().createQuery(sql);
			query.setInteger("questionpaper_id", examSchedule.getQuestionPaper().getQuestionpaperId());
			query.setString("user_id", examSchedule.getUser().getUserId());
			query.setInteger("questionpaper_id1", examSchedule.getQuestionPaper().getQuestionpaperId());
			int flag = query.executeUpdate();
		/*}*/
		logger.debug("Exiting setTotalScoreByUserId(user)");
	}
	
	
	//////////////get examschedule obj from userId 
	public ExamSchedule GetExamScheduleRecord(User user)
	{
		logger.debug("Entering GetExamScheduleRecord(user)");
		String sql = "select * from exam_schedule where user_id = :user_id";
		
		Query query = sessionFactory.getCurrentSession().createQuery(sql);
		
		query.setString("user_id", user.getUserId());
		logger.debug("Exiting GetExamScheduleRecord(user)");
		
		return (ExamSchedule) query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public double getUserScore(String userid, int qpid) {
		logger.debug("Entering getUserScore(userid,qpid)");
		double score=0;
		String hql="select a from Assessment a";
		List<Assessment> assessments = sessionFactory.getCurrentSession().createQuery(hql).list();
		for(Assessment assess : assessments){
			if(assess.getUser().getUserId()==userid && assess.getQuestionPaper().getQuestionpaperId()==qpid){
				score=assess.getScore();
			}
		}
		logger.debug("Exiting getUserScore(userid,qpid)");
		return score;
	}

	@Override
	public Integer processAssessment(Assessment assessment) {
		logger.debug("Entering processAssessment(assessment)");
		logger.debug("Exiting processAssessment(assessment)");
		
		return (Integer) sessionFactory.getCurrentSession().save(assessment);
	}

}
