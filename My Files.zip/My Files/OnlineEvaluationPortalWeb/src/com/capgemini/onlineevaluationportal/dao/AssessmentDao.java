package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Assessment;
import com.capgemini.onlineevaluationportal.entity.User;

public interface AssessmentDao
{
	/*show all attempted test results to the user
	 * by userId*/
	public List<Assessment> showAllAttemptedTestByUserId(User user);
	
	/*calculate all question paper marks
	 * by userId and based on exam schedule attempted test*/
	public void setTotalScoreByUserId(User user);
	
	public double getUserScore(String userid, int qpid);

	public Integer processAssessment(Assessment assessment);
}
