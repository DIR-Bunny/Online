package com.capgemini.onlineevaluationportal.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;

@Transactional
@Repository("UserDaoImpl")
public class UserDaoImpl implements UserDao {
	private static Logger logger = Logger.getLogger(UserDaoImpl.class);
	
	@Autowired
	public SessionFactory session;

	public User authenticateUser(User user){
		logger.debug("Entering authenticateUser(user)");
		
		String hql="select u from User u where u.username= :uname and u.password= :pwd";
		User userobj = (User) session.getCurrentSession().createQuery(hql).setParameter("uname", user.getUsername()).setParameter("pwd", user.getPassword()).uniqueResult();
		
		logger.debug("exiting authenticateUser(user)");
		return userobj;
	}

	@Override
	public User getUserDetailsById(String id) {
		logger.debug("Entering getUserDetailsById(id)");
		logger.debug("exiting getUserDetailsById(id)");
		return (User) session.getCurrentSession().get(User.class, id);
		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public User findByUserName(String username) {
		logger.debug("Entering findByUserName(username)");

		List<User> users = new ArrayList<User>();

		System.out.println("Query : "+session.getCurrentSession().getNamedQuery("GET_USER_BY_USERNAME"));
		users= (List<User>) session.getCurrentSession().getNamedQuery("GET_USER_BY_USERNAME").setParameter("uname", username).list();
		
		if (users.size() > 0) 
		{
			System.out.println(users.size()+"  "+users.get(0).getPassword());
			logger.debug("Exiting findByUserName(username)");
			return users.get(0);
		} else 
		{
			logger.debug("Exiting findByUserName(username)");
			return null;
		}

	}

	@Override
	public UserPojo getUserDetailsByUsername(String username) 
	{
		logger.debug("Entering getUserDetailsByUsername(username)");
		String hql = "from User where username = :uname";
		User user= (User) session.getCurrentSession().createQuery(hql).setParameter("uname", username).uniqueResult();
		logger.debug("exiting getUserDetailsByUsername(username)");
		return new UserPojo(user.getUserId(), user.getUsername(), user.getPassword(), user.getPassword(), user.getDesignation());
	}

	
}
