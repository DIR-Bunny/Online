package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.entity.UserAnswer;

public interface UserAnswerDao {
	
	public boolean storeUserAnswers(List<UserAnswer> answers);
	
	/*set user response 
	 * and Question Id and question paper Id from the userAnswerList*/
	public void setUserAnswerResponse(List<UserAnswer> userAnswerList);  ////done 
	
	/*set score for only without descriptive question 
	 *by userId and questionId list
	 *According to type id fetch correct ans from correct ans Table
	 *If descriptive question then let the ans judge by admin
	 *call SP UpdateMarksByUserId(userId,questionpaperId)*/
	public void setMarkScoredByUser(User user,int QuestionPaperId); ///////done
	
	/*Provide list of correct ans
	 * from question id list*/
	public List<QuestionAnswer> getCorrectAnswers(List<Question> QuestionIdList);
	
	/*calculate total score after admin judge descriptive questions*/
	public double calculateTotalScoreByUserId(UserAnswer userAnswer);  
	
}
