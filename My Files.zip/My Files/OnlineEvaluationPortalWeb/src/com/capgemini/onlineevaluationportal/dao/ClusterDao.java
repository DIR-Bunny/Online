package com.capgemini.onlineevaluationportal.dao;

import com.capgemini.onlineevaluationportal.entity.Cluster;

public interface ClusterDao {
	
	public Integer addCluster(Cluster cluster);
}
