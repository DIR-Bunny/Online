package com.capgemini.onlineevaluationportal.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;


@Repository
public class OptionDaoImpl implements OptionDao {

	private static Logger logger = Logger.getLogger(OptionDaoImpl.class);
	@Autowired
	public SessionFactory session;
	
	
	
	@Override
	public int addOption(QuestionOption option) {
		logger.debug("Entering addOption(option)");
		logger.debug("Exiting addOption(option)");
		return (Integer) session.getCurrentSession().save(option);
	}

	@Override
	public void deleteOption(Integer id) {
		logger.debug("Entering deleteOption(id)");
		QuestionOption questionOption=(QuestionOption) session.getCurrentSession().get(QuestionOption.class, id);
		session.getCurrentSession().delete(questionOption);
		logger.debug("Exiting deleteOption(id)");
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<QuestionOption> getAllOptions() {
		logger.debug("Entering getAllOptions()");
		Session session1= session.getCurrentSession();
		String hql="from QuestionOption";
		Query query=session1.createQuery(hql);
		List<QuestionOption> list=(List<QuestionOption>) query.list();
		logger.debug("Exiting getAllOptions()");
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<QuestionOption> getQptionByQsId(Integer id) {
		logger.debug("Entering getQptionByQsId(id)");
		List<QuestionOption> optionList = new ArrayList<QuestionOption>();
		String hql="select ques from Question ques where ques.questionId = :id";
		Question question = (Question) session.getCurrentSession().createQuery(hql).setParameter("id", id) .uniqueResult();
		optionList.addAll(question.getQuestionOptions());
		logger.debug("Exiting getQptionByQsId(id)");
		return optionList;
	}

	@Override
	public void addOptionToQusetion(QuestionOption option) 
	{
		logger.debug("Entering addOptionToQusetion(option)");
		Date d=new Date();
		Question question=new Question();
		question.setQuestionId(117);
		question.setQuestionDescription("why Java ?");
	
	QuestionOption option1=new QuestionOption("saurabh", d, "java.lang", "ikea", d);
	QuestionOption option2=new QuestionOption("saurabh", d, "java.util", "ikea", d);
	QuestionOption option3=new QuestionOption("saurabh", d, "java.net", "ikea", d);
	QuestionOption option4=new QuestionOption("saurabh", d, "java.awt", "ikea", d);
	
	//session.getCurrentSession().save(option1);
		
	ArrayList<QuestionOption> options=new ArrayList<QuestionOption>();
		options.add(option1);
		options.add(option2);
		options.add(option3);
		options.add(option4);
		
	question.setQuestionOptions(options);
	
	session.getCurrentSession().save(question);
	logger.debug("Exiting addOptionToQusetion(option)");
		
	}

	@Override
	public QuestionOption getOptionDetails(Integer optionId) {
				
		return (QuestionOption) session.getCurrentSession().get(QuestionOption.class, optionId);
	}

	
	
}
