package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.pojo.ExamSchedulePojo;

public interface ExamScheduleDao
{		
	
	/*Admin creates ExamShedule for user*/
	public int createExamShedule(ExamSchedule shedule);   ////done
	
	/*Admin creates ExamShedule for users*/
	public void createExamSheduleBatch(List<ExamSchedule> sheduleList);
	
	
	/*get all exams assigned to particular user by userId*/
	public ExamSchedule getExamSheduleByUserId(int userId);  /// done
	
	
	/*get only number of attempts remaining by userId*/
	public int checkNoOfAttemptsRemaining(int userIuserIdd);
	
	
	/*
	 * set taken date
	 * set status
	 * set no of attempts*/ 
	public void setAttempted(ExamSchedule shedule); 
	
	public List<ExamSchedule> getUserExamSchedule(String userid);
	
	public boolean updateExamSchedule(ExamSchedule exam);
	
	
	public List<ExamSchedule> getUserExamScheduleBySearch(String serachParam);
	
	public boolean updateOverDueExams();
}
