package com.capgemini.onlineevaluationportal.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.xb.xsdschema.RestrictionDocument.Restriction;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;
import com.capgemini.onlineevaluationportal.pojo.CustomGenericException;
import com.capgemini.onlineevaluationportal.pojo.UploadQuestionPojo;

@Repository
@Transactional
public class UploadDaoImpl implements UploadDao
{
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Workbook getWorkbook(InputStream inputStream, String excelFileName) throws CustomGenericException
	{
		 Workbook workbook = null;
		 
		    try {
				if (excelFileName.endsWith("xlsx")) 
				{
				    workbook = new XSSFWorkbook(inputStream);
				} 
				else if (excelFileName.endsWith("xls")) 
				{
				    workbook = new HSSFWorkbook(inputStream);
				} 
				else 
				{
					System.out.println("not an excel file");
					throw new CustomGenericException("0000","The specified file is not Excel file");
				}
			} 
		    catch (IOException e) 
		    {
		    	 throw new CustomGenericException("0000","The specified file is not Excel file");
			}
		 
		    return workbook;
	}

	@SuppressWarnings("deprecation")
	@Override
	public Object getCellValue(Cell cell)
	{
		CellType c =   cell.getCellTypeEnum();
		//System.out.println(c.getCode());
	    switch (cell.getCellType()) 
	    {
	    case Cell.CELL_TYPE_STRING:
	        return cell.getStringCellValue();
	 
	    case Cell.CELL_TYPE_BOOLEAN:
	        return cell.getBooleanCellValue();
	 
	    case Cell.CELL_TYPE_NUMERIC:
	        return cell.getNumericCellValue();
	    }
	 
	    return null;
	}

	/*@Override
	public void SaveUsers(List<User> userList)
	{
		System.out.println("size of userlist "+userList.size());
		Session session = sessionFactory.getCurrentSession();
		for (User user : userList)
		{
			System.out.println(user.getUserId()+user.getUsername()+user.getEmailid()+user.getPassword());
			String s = (String) session.save(user);
			System.out.println("saving staus "+s);
		}
	}
*/
	@Override
	public void SaveQuestions(List<UploadQuestionPojo> QuestionList) 
	{
		System.out.println("size of QuestionList "+QuestionList.size());
		Session session = sessionFactory.getCurrentSession();
		for (UploadQuestionPojo obj : QuestionList)
		{
			
			QuestionType type = obj.getType();
			Criteria cr = session.createCriteria(QuestionType.class);
			type = (QuestionType) cr.add(Restrictions.eq("typeName", type.getTypeName())).uniqueResult();
			
			Questionlevel level = obj.getLevel();
			Criteria cr1 = session.createCriteria(Questionlevel.class);
			level = (Questionlevel) cr1.add(Restrictions.eq("questionLevel", level.getQuestionLevel())).uniqueResult();
			
			obj.getQuestion().setQuestionType(type);
			obj.getQuestion().setQuestionlevel(level);
		
			
			
			
			Question q =  obj.getQuestion();
			//q.setQuestionAnswers(obj.getCorrectAns());
			System.out.println("Inside save DAO "+q);
			int s = (Integer) session.save(q);
			
			System.err.println("saving status Question "+s);
			for (QuestionAnswer correctAns : obj.getCorrectAns()) 
			{
				correctAns.setQuestion(q);
				System.err.println("I am inserted "+(int) session.save(correctAns));
				session.flush();
				session.evict(correctAns);
			}
			
		}
		
	}

	

}
