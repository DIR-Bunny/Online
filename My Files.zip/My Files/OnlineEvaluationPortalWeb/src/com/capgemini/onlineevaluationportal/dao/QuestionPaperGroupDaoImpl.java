package com.capgemini.onlineevaluationportal.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionPaperGroup;

@Repository
public class QuestionPaperGroupDaoImpl implements QuestionPaperGroupDao {

	@Autowired 
	public SessionFactory session; 
	
	private Logger logger = Logger.getLogger(QuestionPaperGroupDaoImpl.class);
	
	@Override
	public Integer createQuestionPaperGroup(QuestionPaperGroup qpGroup) {
		logger.debug("Entering createQuestionPaperGroup(QuestionPaperGroup qpGroup)");
				
		logger.debug("Exiting createQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		return (Integer) session.getCurrentSession().save(qpGroup); 
	}

	@Override
	public Integer removeQuestionPaperGroup(QuestionPaperGroup qpGroup) {
		logger.debug("Entering removeQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		session.getCurrentSession().delete(qpGroup);
		logger.debug("Exiting removeQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		return 0;
	}

	@Override
	public void addQPtoQPGroup(int qpId, int qpGroupId) {
		logger.debug("Entering addQPtoQPGroup(int qpId, int qpGroupId) ");
		
		QuestionPaper questionPaper =  (QuestionPaper) session.getCurrentSession().get(QuestionPaper.class, qpId);	
		
		QuestionPaperGroup questionPaperGroup = (QuestionPaperGroup) session.getCurrentSession().get(QuestionPaperGroup.class, qpGroupId);
				
		questionPaperGroup.addQuestionPaper(questionPaper);
		session.getCurrentSession().save(questionPaperGroup);
		
		logger.debug("Exiting addQPtoQPGroup(int qpId, int qpGroupId) ");
	}

	@Override
	public List<QuestionPaper> getQuestionPapers(int groupId) {
		
		QuestionPaperGroup qpGroup = (QuestionPaperGroup)session.getCurrentSession().get(QuestionPaperGroup.class, groupId);
		List<QuestionPaper> questionPapers = new ArrayList<QuestionPaper>();
		questionPapers.addAll(qpGroup.getQuestionPapers());
		return questionPapers;
	}

	@Override
	public QuestionPaperGroup getQuestionPaperGroup(int groupId) {
		
		return (QuestionPaperGroup)session.getCurrentSession().get(QuestionPaperGroup.class, groupId);
	}
	
	
}
