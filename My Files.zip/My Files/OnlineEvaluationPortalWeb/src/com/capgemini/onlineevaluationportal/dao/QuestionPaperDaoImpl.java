package com.capgemini.onlineevaluationportal.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.Project;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;

@Repository
public class QuestionPaperDaoImpl implements QuestionPaperDao {
	private static Logger logger = Logger.getLogger(QuestionPaperDaoImpl.class);
	
	@Autowired
	private SessionFactory session;
	
	@Override
	public void addQuestionToQuestionPaper(Integer qpId,Integer qId) {
		logger.debug("Entering addQuestionToQuestionPaper(qpId,qId)");
		/*Date d=new Date();
		Project p=new Project();
			p.setProjectId(2);
		QuestionType type  =  new QuestionType();
			type.setTypeId(11); //11
		Questionlevel level = new Questionlevel();
			level.setQuestionLevelId(4); //4
		question=new Question("SSM", d, 3, "what is spr-mvc ?", "SSM", d,type,level);	
		System.out.println(question);	
		QuestionPaper paper=new QuestionPaper("SSM", d, "USA", "SSM", d, p);
		System.out.println(paper);
		paper.addQuestion(question);
		session.getCurrentSession().save(paper);*/
		
		
		Question question=(Question) session.getCurrentSession().get(Question.class, qId);
		QuestionPaper qpaper = (QuestionPaper) session.getCurrentSession().get(QuestionPaper.class, qpId);
		qpaper.addQuestion(question);
		session.getCurrentSession().save(qpaper);
		logger.debug("Exiting addQuestionToQuestionPaper(qpId,qId)");
	}

	@Override
	public Integer createQuestionpaper(QuestionPaper questionPaper) {
		logger.debug("Entering createQuestionpaper(questionPaper)");
		logger.debug("Exiting createQuestionpaper(questionPaper)");
		return (Integer) session.getCurrentSession().save(questionPaper);
	}
	
	@Override
	public String getQuestionPaperTitle(int qpid) {
		logger.debug("Entering getQuestionPaperTitle(qpid)");
		String hql="select qp.questionpaperTitle from QuestionPaper qp where qp.questionpaperId = :qpid"; 
		logger.debug("Exiting getQuestionPaperTitle(qpid)");
		return (String) session.getCurrentSession().createQuery(hql).setParameter("qpid", qpid).uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Integer> getQuestionIdList(int qpId) {
		logger.debug("Entering getQuestionIdList(qpid)");
		
		String questionCountQuery="select count(question_id) from question_qpaper_map where questionpaper_id = :qpId";
		Object questionCount = (Object) session.getCurrentSession().createSQLQuery(questionCountQuery).setParameter("qpId", qpId).uniqueResult();
		
		String questionIdQuery = "select question_id from question_qpaper_map where questionpaper_id = :qpId";
		ArrayList<Integer> questionIdList = (ArrayList<Integer>) session.getCurrentSession().createSQLQuery(questionIdQuery).setParameter("qpId", qpId).list();
		//System.out.println(questionIdList);
		logger.debug("Exiting getQuestionIdList(qpid)");
		return questionIdList;
	}

	@Override
	public List<Question> getAllQuestions(int qpaperId) {
		logger.debug("Entering getAllQuestions(qpaperId)");
		List<Question> questions=new ArrayList<Question>();
		String hql="select qp from QuestionPaper qp where qp.questionpaperId = :qpId";
		QuestionPaper qp = (QuestionPaper) session.getCurrentSession().createQuery(hql).setParameter("qpId", qpaperId).uniqueResult();
		questions.addAll(qp.getQuestions());
		logger.debug("Exiting getAllQuestions(qpaperId)");
		return questions;
	}

	/*@SuppressWarnings("unchecked")
	@Override
	public List<Question> getQuestionsFromQuestionPaper(int qpId) {
		
		String hql="select qp from QuestionPaper qp where questionpaperId = :qpId";
		QuestionPaper qp = (QuestionPaper) session.getCurrentSession().createQuery(hql).setParameter("qpId", qpId).uniqueResult();
		List<Question> questions=new ArrayList<Question>();
		questions.addAll(qp.getQuestions());
		//System.out.println("Questions : "+questions);
		return questions;
	}*/
	
}
