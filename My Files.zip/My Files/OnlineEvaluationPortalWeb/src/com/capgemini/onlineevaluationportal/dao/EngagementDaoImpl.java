package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capgemini.onlineevaluationportal.entity.Engagement;


@Repository
public class EngagementDaoImpl implements EngagementDao{

	private static Logger logger = Logger.getLogger(EngagementDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public int addEngagement(Engagement engagement) {
		logger.debug("Entering addEngagement(engagement)");
		int id=(Integer) sessionFactory.getCurrentSession().save(engagement);
		logger.debug("Exiting addEngagement(engagement)");
		return id;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Engagement> getAllEngagements() {
		logger.debug("Entering getAllEngagements()");
		String hql = "select e from Engagement e";
		logger.debug("Exiting getAllEngagements()");
		return sessionFactory.getCurrentSession().createQuery(hql).list();
	}

}
