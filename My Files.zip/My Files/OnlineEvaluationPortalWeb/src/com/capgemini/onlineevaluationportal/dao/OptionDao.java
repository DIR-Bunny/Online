package com.capgemini.onlineevaluationportal.dao;

import java.util.List;


import com.capgemini.onlineevaluationportal.entity.QuestionOption;

public interface OptionDao {

	public int addOption(QuestionOption option);
	public void deleteOption(Integer id);
	public List<QuestionOption> getAllOptions();
	public List<QuestionOption> getQptionByQsId(Integer id);
	public void addOptionToQusetion(QuestionOption option);

	public QuestionOption getOptionDetails(Integer optionId);
}
