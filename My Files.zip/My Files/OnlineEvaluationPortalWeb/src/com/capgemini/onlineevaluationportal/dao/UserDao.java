package com.capgemini.onlineevaluationportal.dao;

import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;

public interface UserDao {

	public User authenticateUser(User user);
	
	public User getUserDetailsById(String id);
	
	public User findByUserName(String username);
	
	public UserPojo getUserDetailsByUsername(String username);
}
