package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Question;

public interface QuestionDao {

	public Integer addQuestion(Question question);
	
	public Integer deleteQuestion(int quesId);
	
	public List<Question> getQuestionsFromQuestionPaper(int qpId);
	
	public Question getNextQuestion(int questionPaperId, int previousQId);
	
	public Question getQuestionById(int questionId);
	
}
