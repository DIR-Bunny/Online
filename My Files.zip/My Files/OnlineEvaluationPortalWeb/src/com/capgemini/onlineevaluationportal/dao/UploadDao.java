package com.capgemini.onlineevaluationportal.dao;

import java.io.InputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import com.capgemini.onlineevaluationportal.pojo.UploadQuestionPojo;

public interface UploadDao
{
	public Workbook getWorkbook(InputStream inputStream, String excelFileName) throws Exception ;
	
	public Object getCellValue(Cell cell);
	
	//public void SaveUsers(List<User> userList);
	public void SaveQuestions(List<UploadQuestionPojo> QuestionList);
	
}
