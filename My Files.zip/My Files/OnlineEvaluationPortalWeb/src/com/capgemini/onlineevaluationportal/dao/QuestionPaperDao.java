package com.capgemini.onlineevaluationportal.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;


public interface QuestionPaperDao {
	
	public void addQuestionToQuestionPaper(Integer qpId,Integer qId);	
	
	public Integer createQuestionpaper(QuestionPaper questionPaper);
	
	public String getQuestionPaperTitle(int qpid);
	
	/*public List<Question> getQuestionsFromQuestionPaper(int qpId);*/
	
	public ArrayList<Integer> getQuestionIdList(int qpId);
	
	public List<Question> getAllQuestions( int qpaperId);
}
