package com.capgemini.onlineevaluationportal.dao;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;
import com.capgemini.onlineevaluationportal.service.LoginService;

@Repository
public class ExamScheduleDaoImpl implements ExamScheduleDao
{
	private static Logger logger = Logger.getLogger(ExamScheduleDaoImpl.class);

	@Autowired
	public LoginService loginService;
	
	@Autowired
	public SessionFactory session;
	
	@Override
	public int createExamShedule(ExamSchedule schedule)
	{
		logger.debug("Entering createExamShedule(schedule)");
		logger.debug("Exiting createExamShedule(schedule)");
		
		return (Integer) session.getCurrentSession().save(schedule);
	}

	@Override
	public void createExamSheduleBatch(List<ExamSchedule> sheduleList)
	{
		logger.debug("Entering createExamSheduleBatch(schedule)");
		logger.debug("Exiting createExamSheduleBatch(schedule)");
		// TODO Auto-generated method stub
		
	}

	@Override
	public ExamSchedule getExamSheduleByUserId(int userId)
	{
		logger.debug("Entering ExamSchedule(userId)");
		logger.debug("Exiting ExamSchedule(userId)");
		return (ExamSchedule) session.getCurrentSession().get(ExamSchedule.class, userId);
	}

	@Override
	public int checkNoOfAttemptsRemaining(int userId)
	{
		logger.debug("Entering checkNoOfAttemptsRemaining(userId)");
		Criteria cr = session.getCurrentSession().createCriteria(ExamSchedule.class);
		Criteria cr2 = cr.createCriteria("user");
		cr2.add(Restrictions.eq("userId", userId));
		logger.debug("Exiting checkNoOfAttemptsRemaining(userId)");
		return (int) cr.uniqueResult();		
	}

	@Override
	public void setAttempted(ExamSchedule shedule)
	{
		logger.debug("Entering setAttempted(shedule)");
		/*Criteria cr = sessionFactory.getCurrentSession().createCriteria(ExamSchedule.class);
		
		// Add criteria for question paper Id
		Criteria cr1 = cr.createCriteria("questionPaper");
		cr1.add(Restrictions.eq("questionpaperId", shedule.getQuestionPaper().getQuestionpaperId()));
		
		
		/// Add criteria for userId
		Criteria cr2 = cr.createCriteria("user");
		cr2.add(Restrictions.eq("userId", shedule.getUser().getUserId()));
		
		cr.un*/
		logger.debug("Exiting setAttempted(shedule)");
		
		session.getCurrentSession().merge(shedule);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ExamSchedule> getUserExamSchedule(String userid)
	{
		logger.debug("Entering getUserExamSchedule(userid)");
		
		List<ExamSchedule> userExams=new ArrayList<ExamSchedule>();
		String hql="select e from ExamSchedule e";
		List<ExamSchedule> eList= session.getCurrentSession().createQuery(hql).list();
		for(ExamSchedule exam : eList){
			if(exam.getUser().getUserId().equals(userid)){
				userExams.add(exam);
			}
		}
		System.out.println("list :"+userExams);
		logger.debug("Exiting getUserExamSchedule(userid)");
		return userExams;
	}

	@Override
	public boolean updateExamSchedule(ExamSchedule exam) {
		logger.debug("Entering updateExamSchedule(exam)");
		String sql = "select testschedule_id from exam_schedule as e where e.user_id = :userId and e.questionpaper_id = :qpId";
		int id = (int)session.getCurrentSession().createSQLQuery(sql).setParameter("userId", exam.getUser().getUserId()).setParameter("qpId", exam.getQuestionPaper().getQuestionpaperId()).uniqueResult();
		
		ExamSchedule examEntity = (ExamSchedule) session.getCurrentSession().get(ExamSchedule.class, id);
		examEntity.setStatus(exam.getStatus());
		examEntity.setTakenDate(exam.getTakenDate());
	//	System.out.println(examEntity.toString());
		logger.debug("Exiting updateExamSchedule(exam)");
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ExamSchedule> getUserExamScheduleBySearch(String serachParam) 
	{
		UserPojo user = getPrincipal();
		User u = new User(user.getUserId());
		Criteria cr = session.getCurrentSession().createCriteria(ExamSchedule.class);
		cr.add(Restrictions.eq("user", u));
		serachParam = "%"+serachParam+"%";
		Criteria cr1 = cr.createCriteria("questionPaper");
		cr1.add(Restrictions.like("questionpaperTitle",serachParam));
		//System.out.println("QUestion Papers  "+cr1.list().size());
		
		//System.err.println("ExamSchedule Dao "+cr.list());
		return cr.list();
	}
	
	private UserPojo getPrincipal()
	 {
		logger.debug("Entering getPrincipal()");
	 	UserPojo user = null;
	     String userName = null;
	     Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	     
		       if (principal instanceof UserDetails) 
		        {
		            userName = ((UserDetails)principal).getUsername();
		            System.out.println("Loged in user "+userName);
		            user =  loginService.getUserDetailsByUsername(userName);
		        } else 
		        {
		            userName = principal.toString();
		            user =  loginService.getUserDetailsByUsername(userName);
		        }
		       logger.debug("Exiting getPrincipal()");
		        return user;
	  }

	@SuppressWarnings("unchecked")
	@Override
	public boolean updateOverDueExams() {
		
		logger.debug("Entering updateOverDueExams Dao");
		
		String hql = "select e from ExamSchedule e";
		List<ExamSchedule> exams = session.getCurrentSession().createQuery(hql).list();
		for(ExamSchedule e : exams){
			LocalDate today = LocalDate.now();
			LocalDate dueDate =e.getDueDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			int comparison = today.compareTo(dueDate);
			if( (comparison > 0) && (e.getStatus().equalsIgnoreCase("pending"))){
				e.setStatus("Over Due");
			}
		}
		logger.debug("Exiting updateOverDueExams Dao");
		return false;
	}
	
	
	
	
}
