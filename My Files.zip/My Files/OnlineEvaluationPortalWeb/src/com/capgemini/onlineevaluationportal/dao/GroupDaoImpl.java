package com.capgemini.onlineevaluationportal.dao;

import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.Group;
import com.capgemini.onlineevaluationportal.entity.User;

@Repository
public class GroupDaoImpl implements GroupDao {

	private static Logger logger = Logger.getLogger(GroupDaoImpl.class);
	@Autowired
	private SessionFactory factory;
	
	@Override
	public Integer creategroup(Group group) {
		logger.debug("Entering creategroup(group)");
		Date d=new Date();
		group=new Group("grp01", "SSM", d, ".Net group", "SSM", d);
		factory.getCurrentSession().save(group);
		logger.debug("Exiting creategroup(group)");
		return 0;
	}

	@Override  //removeGroup
	public String deletegroup(String groupId) {
		
		logger.debug("Entering deletegroup(groupId)");
		groupId="grp01";
		Group group=(Group) factory.getCurrentSession().get(Group.class, groupId);
		if(group == null){
			System.out.println("Group not exist");
			logger.debug("Exiting deletegroup(groupId)");
			return null;
		}
		String id= group.getGroupId(); 
		factory.getCurrentSession().delete(group);
		System.out.println("Question deleted with id :"+id);
		logger.debug("Exiting deletegroup(groupId)");
		return id;
	}

	@Override
	public Integer addUserToGroup(Group group, User user) {
		logger.debug("Entering addUserToGroup(group,user)");
		Date d=new Date();
		group=new Group("grp_IN", "SSM", d, "GRP India", "SSM", d);
		factory.getCurrentSession().save(group);
		user=new User("IN_99415", "SSM", d, "Soft Engg", "ssm@capg.com", "ssm", "SSM", d, "smullani"); 
		user.addGroup(group);
		factory.getCurrentSession().save(user);
		
		/*group=(Group) factory.getCurrentSession().get(Group.class, "grp_IN");
			//group.setGroupId("grp_IN");
			System.out.println(group);
		user=(User) factory.getCurrentSession().get(User.class, "IN_99415");
			//user.setUserId("IN_99414");
			System.out.println(user);
		user.addGroup(group);	
		factory.getCurrentSession().save(user);	*/
		logger.debug("Exiting addUserToGroup(group,user)");
		return 0;
	}

}
