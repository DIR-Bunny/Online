package com.capgemini.onlineevaluationportal.dao;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.pojo.UploadQuestionPojo;

public class ExcelBuilder extends AbstractExcelView
{

	@Override
	protected void buildExcelDocument(Map<String, Object> model ,HSSFWorkbook workbook, HttpServletRequest req, HttpServletResponse res) throws Exception
	{
        
		UploadQuestionPojo obj = (UploadQuestionPojo) model.get("uploadPojo");
		System.out.println("Inside excel builder "+obj);
        // create a new Excel sheet
        HSSFSheet sheet = workbook.createSheet("Upload Questions");
        sheet.setDefaultColumnWidth(30);
         
        // create style for header cells
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontName("Arial");
        style.setFillForegroundColor(HSSFColor.GREEN.index);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        style.setFont(font);
         
        // create header row
        HSSFRow header = sheet.createRow(0);
        
        header.createCell(0).setCellValue("Q type");
        header.getCell(0).setCellStyle(style);
         
        header.createCell(1).setCellValue("Level");
        header.getCell(1).setCellStyle(style);
         
        header.createCell(2).setCellValue("Q text	");
        header.getCell(2).setCellStyle(style);
         
        header.createCell(3).setCellValue("Option/ Answer 1");
        header.getCell(3).setCellStyle(style);
         
        header.createCell(4).setCellValue("Option/ Answer 2");
        header.getCell(4).setCellStyle(style);
         
        header.createCell(5).setCellValue("Option/ Answer 3");
        header.getCell(5).setCellStyle(style);
        
        header.createCell(6).setCellValue("Option/ Answer 4");
        header.getCell(6).setCellStyle(style);
        
        header.createCell(7).setCellValue("Option/ Answer 5");
        header.getCell(7).setCellStyle(style);
        
        header.createCell(8).setCellValue("Option/ Answer 6");
        header.getCell(8).setCellStyle(style);
        	

        
        header.createCell(9).setCellValue("Correct Answer 1");
        header.getCell(9).setCellStyle(style);
        
        header.createCell(10).setCellValue("Correct Answer 2");
        header.getCell(10).setCellStyle(style);
        
        header.createCell(11).setCellValue("Correct Answer 3");
        header.getCell(11).setCellStyle(style);
        
        header.createCell(12).setCellValue("Correct Answer 4");
        header.getCell(12).setCellStyle(style);
        
        header.createCell(13).setCellValue("Correct Answer 5");
        header.getCell(13).setCellStyle(style);
        
        header.createCell(14).setCellValue("Marks");
        header.getCell(14).setCellStyle(style);
        // create data rows
        int rowCount = 1;
        
        HSSFRow aRow = sheet.createRow(rowCount++);
        aRow.createCell(0).setCellValue(obj.getType().getTypeName());
        aRow.createCell(1).setCellValue(obj.getLevel().getQuestionLevel());
        aRow.createCell(2).setCellValue(obj.getQuestion().getQuestionDescription());
        
        for ( QuestionOption opt  :obj.getOptionsList()) 
        {
			System.out.println(opt);
		}
        
        aRow.createCell(3).setCellValue(obj.getOptionsList().get(0).getOptionText());
        aRow.createCell(4).setCellValue(obj.getOptionsList().get(1).getOptionText());
        aRow.createCell(5).setCellValue(obj.getOptionsList().get(2).getOptionText());
        aRow.createCell(6).setCellValue(obj.getOptionsList().get(3).getOptionText());
        aRow.createCell(7).setCellValue(obj.getOptionsList().get(4).getOptionText());
        aRow.createCell(8).setCellValue(obj.getOptionsList().get(5).getOptionText());
        aRow.createCell(9).setCellValue(obj.getCorrectAns().get(0).getCorrectAnswer());
        aRow.createCell(10).setCellValue(obj.getCorrectAns().get(1).getCorrectAnswer());
        aRow.createCell(11).setCellValue(obj.getCorrectAns().get(2).getCorrectAnswer());
        aRow.createCell(12).setCellValue(obj.getCorrectAns().get(3).getCorrectAnswer());
        aRow.createCell(13).setCellValue(obj.getCorrectAns().get(4).getCorrectAnswer());
        aRow.createCell(14).setCellValue(obj.getQuestion().getMark());
        
		
	}

}
