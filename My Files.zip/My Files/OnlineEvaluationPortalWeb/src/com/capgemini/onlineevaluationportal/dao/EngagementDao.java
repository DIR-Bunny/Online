package com.capgemini.onlineevaluationportal.dao;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Engagement;

public interface EngagementDao {

	public int addEngagement(Engagement engagement);
	
	public List<Engagement> getAllEngagements();
	
}			
