package com.capgemini.onlineevaluationportal.dao;

import com.capgemini.onlineevaluationportal.entity.Project;

public interface ProjectDao {

	public Integer addProject(Project project);
}
