package com.capgemini.onlineevaluationportal.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.controller.EngagementController;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;

@Repository
public class QuestionDaoImpl implements QuestionDao {

	private static Logger logger = Logger.getLogger(QuestionDaoImpl.class);
	@Autowired
	public SessionFactory session; 
	
	@Override
	public Integer addQuestion(Question question) 
	{
		logger.debug("Entering addQuestion(question)");
		Date d=new Date();
		question.setCreatedTime(d);
		/*QuestionType qt=new QuestionType("SSM", d, "Descriptive", "SSM", d);
		int tId =  (Integer) factory.getCurrentSession().save(qt);
		System.out.println("type id"+ qt.getTypeId()+" "+tId);*/
		//qt.setTypeId(tId);
		/*Questionlevel ql=new Questionlevel("Expert");
		int LId =  (Integer) factory.getCurrentSession().save(ql);
		System.out.println("level id"+ql.getQuestionLevelId()+" "+LId);*/
		
		/*QuestionType type  =  new QuestionType();
		type.setTypeId(13); //11 mcq//12 des//13
		
		Questionlevel level = new Questionlevel();
		level.setQuestionLevelId(4); //4
		
		question=new Question("SSM",d , 2, "why Java ?", "SSM", d,type,level);*/
		int id=(Integer) session.getCurrentSession().save(question);
		System.out.println("question id :"+id);
		logger.debug("Exiting addQuestion(question)");
		return 0;
	}

	@Override
	public Integer deleteQuestion(int quesId) {
		logger.debug("Entering deleteQuestion(quesId)");
		
		Question question=(Question) session.getCurrentSession().get(Question.class, quesId);
		if(question == null){
			System.out.println("Question not exist");
			return 0;
		}
		int id=question.getQuestionId(); 
		session.getCurrentSession().delete(question);
		System.out.println("Question deleted with id :"+id);
		logger.debug("Exiting deleteQuestion(quesId)");
		return id;
	}
	
	@Override
	public List<Question> getQuestionsFromQuestionPaper(int qpId) {
		
		
		logger.debug("Entering getQuestionsFromQuestionPaper(qpId)");
		String hql="select qp from QuestionPaper qp where questionpaperId = :qpId";
		QuestionPaper qp = (QuestionPaper) session.getCurrentSession().createQuery(hql).setParameter("qpId", qpId).uniqueResult();
		List<Question> questions=new ArrayList<Question>();
		questions.addAll(qp.getQuestions());
		//System.out.println("Questions : "+questions);
		logger.debug("Exiting getQuestionsFromQuestionPaper(qpId)");
		return questions;
	}

	@Override
	public Question getNextQuestion(int questionPaperId, int previousQId) {
		logger.debug("Entering getNextQuestion(questionPaperId,previousQId)");
		String sqlQuery="SELECT Q.question_id "
						+"FROM question as Q, question_qpaper_map as M "
						+"where M.questionpaper_id= :qpid and M.question_id=Q.question_id and Q.question_id> :qid " 
						+"limit 1";
		
		Integer qid = (Integer) session.getCurrentSession().createSQLQuery(sqlQuery).setParameter("qpid", questionPaperId).setParameter("qid", previousQId).uniqueResult();
		Question question = (Question) session.getCurrentSession().get(Question.class, qid);
		logger.debug("Exiting getNextQuestion(questionPaperId,previousQId)");
		return question;
	}

	@Override
	public Question getQuestionById(int questionId) {
		logger.debug("Entering getQuestionById(questionId)");
		logger.debug("Exiting getQuestionById(questionId)");
		return (Question)session.getCurrentSession().get(Question.class, questionId); 
	}
}
