package com.capgemini.onlineevaluationportal.dao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.entity.Cluster;

@Repository
public class ClusterDaoImpl implements ClusterDao {

	private static Logger logger = Logger.getLogger(ClusterDaoImpl.class);
	
	@Autowired
	public SessionFactory session;
	
	@Override
	public Integer addCluster(Cluster cluster) {
		logger.debug("Entering addCluster(cluster)");
		logger.debug("Exiting addCluster(cluster)");
		
		return (Integer) session.getCurrentSession().save(cluster);
	}

}
