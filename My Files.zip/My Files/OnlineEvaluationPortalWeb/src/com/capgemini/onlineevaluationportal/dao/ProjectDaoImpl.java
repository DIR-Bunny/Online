package com.capgemini.onlineevaluationportal.dao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.onlineevaluationportal.controller.EngagementController;
import com.capgemini.onlineevaluationportal.entity.Project;

@Repository
public class ProjectDaoImpl implements ProjectDao {
	private static Logger logger = Logger.getLogger(ProjectDaoImpl.class);

	@Autowired
	public SessionFactory session;
	
	@Override
	public Integer addProject(Project project) {
		logger.debug("Entering addProject(project)");
		logger.debug("Exiting addProject(project)");
		
		return (Integer)session.getCurrentSession().save(project);
	}

}
