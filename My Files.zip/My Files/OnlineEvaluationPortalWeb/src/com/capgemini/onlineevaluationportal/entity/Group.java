package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the group database table.
 * 
 */
@Entity
@Table(name="usergroup")
@NamedQuery(name="Group.findAll", query="SELECT g FROM Group g")
public class Group implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="group_id")
	private String groupId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Column(name="group_name")
	private String groupName;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	//bi-directional many-to-many association to User
	/*@ManyToMany(mappedBy="groups")
	private List<User> users=new ArrayList<User>();*/
//----------------------------------------------------
	public Group() {
	}
	
	public Group(String groupId, String createdBy, Date createdTime,
		String groupName, String updatedBy, Date updatedTime) {
	super();
	this.groupId = groupId;
	this.createdBy = createdBy;
	this.createdTime = createdTime;
	this.groupName = groupName;
	this.updatedBy = updatedBy;
	this.updatedTime = updatedTime;
	}

	public String getGroupId() {
		return this.groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	/*public List<User> getUsers() {
		return this.users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}*/

	@Override
	public String toString() {
		return "Group [groupId=" + groupId + ", groupName=" + groupName+ "]";
	}
}