package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;


/**
 * The persistent class for the question_option database table.
 * 
 */
@Entity
@Table(name="question_option")
@NamedQuery(name="QuestionOption.findAll", query="SELECT q FROM QuestionOption q")
public class QuestionOption implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="option_id")
	private int optionId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Lob
	@Column(name="option_text")
	private String optionText;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	//bi-directional many-to-many association to Question
	//@LazyCollection(LazyCollectionOption.FALSE)
	@JsonIgnore
	@ManyToMany(mappedBy="questionOptions", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Question> questions;

	public QuestionOption(int optionId, String createdBy, Date createdTime, String optionText, String updatedBy,
			Date updatedTime, List<Question> questions) {
		super();
		this.optionId = optionId;
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.optionText = optionText;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.questions = questions;
	}

	public QuestionOption(String createdBy, Date createdTime, String optionText, String updatedBy, Date updatedTime) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.optionText = optionText;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
	}



	public QuestionOption() {
	}
	
	public int getOptionId() {
		return this.optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getOptionText() {
		return this.optionText;
	}

	public void setOptionText(String optionText) {
		this.optionText = optionText;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public List<Question> getQuestions() {
		return this.questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "QuestionOption [optionId=" + optionId + " optionText=" + optionText + "]";
	}
	
}