package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.util.List;


/**
 * The persistent class for the questionlevel database table.
 * 
 */
@Entity
@NamedQuery(name="Questionlevel.findAll", query="SELECT q FROM Questionlevel q")
public class Questionlevel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private int questionLevelId;

	private String questionLevel;

	//bi-directional many-to-one association to Question
	@OneToMany(mappedBy="questionlevel",cascade = CascadeType.ALL)
	private List<Question> questions;

	public Questionlevel() {
	}

	public Questionlevel(String questionLevel) {
		super();
		this.questionLevel = questionLevel;
	}

	public int getQuestionLevelId() {
		return this.questionLevelId;
	}

	public void setQuestionLevelId(int questionLevelId) {
		this.questionLevelId = questionLevelId;
	}

	public String getQuestionLevel() {
		return this.questionLevel;
	}

	public void setQuestionLevel(String questionLevel) {
		this.questionLevel = questionLevel;
	}

	public List<Question> getQuestions() {
		return this.questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public Question addQuestion(Question question) {
		getQuestions().add(question);
		question.setQuestionlevel(this);

		return question;
	}

	public Question removeQuestion(Question question) {
		getQuestions().remove(question);
		question.setQuestionlevel(null);

		return question;
	}

	@Override
	public String toString() {
		return "Questionlevel [questionLevelId=" + questionLevelId + ", questionLevel=" + questionLevel + "]";
	}

	
}