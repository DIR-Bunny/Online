package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the engagement database table.
 * 
 */
@Entity
@NamedQuery(name="Engagement.findAll", query="SELECT e FROM Engagement e")
public class Engagement implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="engagement_id")
	private int engagementId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Column(name="engagement_name")
	private String engagementName;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	//bi-directional many-to-one association to Cluster
	@OneToMany(mappedBy="engagement")
	private List<Cluster> clusters;

	public Engagement() {
	}

	public Engagement(String createdBy, Date createdTime,
			String engagementName, String updatedBy, Date updatedTime) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.engagementName = engagementName;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
	}

	public int getEngagementId() {
		return this.engagementId;
	}

	public void setEngagementId(int engagementId) {
		this.engagementId = engagementId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getEngagementName() {
		return this.engagementName;
	}

	public void setEngagementName(String engagementName) {
		this.engagementName = engagementName;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public List<Cluster> getClusters() {
		return this.clusters;
	}

	public void setClusters(List<Cluster> clusters) {
		this.clusters = clusters;
	}

	public Cluster addCluster(Cluster cluster) {
		getClusters().add(cluster);
		cluster.setEngagement(this);

		return cluster;
	}

	public Cluster removeCluster(Cluster cluster) {
		getClusters().remove(cluster);
		cluster.setEngagement(null);

		return cluster;
	}

}