package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the user_answer database table.
 * 
 */
@Entity
@Table(name="user_answer")
@NamedQuery(name="UserAnswer.findAll", query="SELECT u FROM UserAnswer u")
public class UserAnswer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="useranswer_id")
	private int useranswerId;

	@Column(name="userId")
	private String userId;
	
	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Column(name="mark_scored")
	private int markScored;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	@Column(name="user_answer")
	private String userAnswer;

	//bi-directional many-to-one association to Question
	@ManyToOne
	@JoinColumn(name="question_id")
	private Question question;

	//bi-directional many-to-one association to QuestionPaper
	@ManyToOne
	@JoinColumn(name="questionpaper_id")
	private QuestionPaper questionPaper;

	public UserAnswer() {
	}
		
	public UserAnswer(String userId, String userAnswer, Question question, QuestionPaper questionPaper) {
		super();
		this.userId = userId;
		this.userAnswer = userAnswer;
		this.question = question;
		this.questionPaper = questionPaper;
	}

	public UserAnswer(String userId, String createdBy, Date createdTime, int markScored,
			String updatedBy, Date updatedTime, String userAnswer) {
		super();
		this.userId = userId;
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.markScored = markScored;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.userAnswer = userAnswer;
	}


	public int getUseranswerId() {
		return this.useranswerId;
	}

	public void setUseranswerId(int useranswerId) {
		this.useranswerId = useranswerId;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public int getMarkScored() {
		return this.markScored;
	}

	public void setMarkScored(int markScored) {
		this.markScored = markScored;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getUserAnswer() {
		return this.userAnswer;
	}

	public void setUserAnswer(String userAnswer) {
		this.userAnswer = userAnswer;
	}

	public Question getQuestion() {
		return this.question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public QuestionPaper getQuestionPaper() {
		return this.questionPaper;
	}

	public void setQuestionPaper(QuestionPaper questionPaper) {
		this.questionPaper = questionPaper;
	}

	@Override
	public String toString() {
		return "UserAnswer [useranswerId=" + useranswerId + ", userId="+userId+", markScored=" + markScored + ", userAnswer=" + userAnswer	+ "]";
	}

	
}