package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the question_paper_group database table.
 * 
 */
@Entity
@Table(name="question_paper_group")
@NamedQuery(name="QuestionPaperGroup.findAll", query="SELECT q FROM QuestionPaperGroup q")
public class QuestionPaperGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private int gid;

	@Lob
	@Column(name="group_title")
	private String groupTitle;

	@Column(name="no_of_attempts")
	private int noOfAttempts;
	
		@ManyToMany(cascade=CascadeType.ALL)
		@JoinTable(
			name="qp_qpgroup_map"
			, joinColumns={
				@JoinColumn(name="gid")
				}
			, inverseJoinColumns={
				@JoinColumn(name="questionpaper_id")
				}
			)
		private List<QuestionPaper> questionPapers=new ArrayList<QuestionPaper>();

	public QuestionPaperGroup() {
	}
	
	public QuestionPaperGroup(String groupTitle, int noOfAttempts) {
		super();
		this.groupTitle = groupTitle;
		this.noOfAttempts = noOfAttempts;
	}
	
	public QuestionPaperGroup(String groupTitle, int noOfAttempts, List<QuestionPaper> questionPapers) {
		super();
		this.groupTitle = groupTitle;
		this.noOfAttempts = noOfAttempts;
		this.questionPapers = questionPapers;
	}

	public int getGid() {
		return this.gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}
	
	public String getGroupTitle() {
		return this.groupTitle;
	}

	public void setGroupTitle(String groupTitle) {
		this.groupTitle = groupTitle;
	}

	public int getNoOfAttempts() {
		return this.noOfAttempts;
	}

	public void setNoOfAttempts(int noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	
	public List<QuestionPaper> getQuestionPapers() {
		return questionPapers;
	}

	public void setQuestionPapers(List<QuestionPaper> questionPapers) {
		this.questionPapers = questionPapers;
	}

	//extra method
	public void addQuestionPaper(QuestionPaper questionPaper){
		this.questionPapers.add(questionPaper);
	}

	@Override
	public String toString() {
		return "QuestionPaperGroup [gid=" + gid + ", groupTitle=" + groupTitle + ", noOfAttempts=" + noOfAttempts
				+ ", questionPapers=" + questionPapers + "]";
	}
}