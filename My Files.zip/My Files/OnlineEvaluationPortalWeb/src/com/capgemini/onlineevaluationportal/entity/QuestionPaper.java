package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * The persistent class for the question_paper database table.
 * 
 */
@Entity
@Table(name="question_paper")
/*@NamedQuery(name="QuestionPaper.findAll", query="SELECT q FROM QuestionPaper q")*/
public class QuestionPaper implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="questionpaper_id")
	private int questionpaperId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Lob
	@Column(name="questionpaper_title")
	private String questionpaperTitle;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;
	
	@Column(name="questionpaper_description")
	private String questionpaperDescription;
	
	//@LazyCollection(LazyCollectionOption.FALSE)

	//bi-directional many-to-one association to Assessment
	@OneToMany(mappedBy="questionPaper")
	private List<Assessment> assessments;

	//bi-directional many-to-one association to ExamSchedule
	@OneToMany(mappedBy="questionPaper")
	private List<ExamSchedule> examSchedules;

	//bi-directional many-to-one association to Project
	@ManyToOne
	@JoinColumn(name="project_id")
	private Project project;

	//bi-directional many-to-many association to Question
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(
		name="question_qpaper_map"
		, joinColumns={
			@JoinColumn(name="questionpaper_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="question_id")
			}
		)
	private List<Question> questions=new ArrayList<Question>();
	
	/*//bi-directional many-to-many association to Question
		@ManyToMany(cascade=CascadeType.ALL)
		@JoinTable(
			name="question_qpaper_map"
			, joinColumns={
				@JoinColumn(name="questionpaper_id")
				}
			, inverseJoinColumns={
				@JoinColumn(name="question_id")
				}
			)
		private Set<Question> questions=new HashSet<Question>();*/

	//bi-directional many-to-one association to UserAnswer
	@OneToMany(mappedBy="questionPaper")
	private List<UserAnswer> userAnswers;

	//------------------------------------------------------------------------
	public QuestionPaper() {
	}
	
	public QuestionPaper(String createdBy, Date createdTime, String questionpaperTitle, String updatedBy, Date updatedTime,
		Project project) {
	super();
	this.createdBy = createdBy;
	this.createdTime = createdTime;
	this.questionpaperTitle = questionpaperTitle;
	this.updatedBy = updatedBy;
	this.updatedTime = updatedTime;
	this.project = project;
	}
	
	public QuestionPaper(String createdBy, Date createdTime, String questionpaperTitle, String updatedBy,Date updatedTime, 
			String questionpaperDescription, Project project) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.questionpaperTitle = questionpaperTitle;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.questionpaperDescription = questionpaperDescription;
		this.project = project;
	}

	public QuestionPaper(Integer questionpaperId) {
		// TODO Auto-generated constructor stub
		this.questionpaperId = questionpaperId;
	}

	public int getQuestionpaperId() {
		return this.questionpaperId;
	}

	public void setQuestionpaperId(int questionpaperId) {
		this.questionpaperId = questionpaperId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getQuestionpaperTitle() {
		return this.questionpaperTitle;
	}

	public void setQuestionpaperTitle(String questionpaperTitle) {
		this.questionpaperTitle = questionpaperTitle;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public List<Assessment> getAssessments() {
		return this.assessments;
	}

	public void setAssessments(List<Assessment> assessments) {
		this.assessments = assessments;
	}

	public Assessment addAssessment(Assessment assessment) {
		getAssessments().add(assessment);
		assessment.setQuestionPaper(this);

		return assessment;
	}

	public Assessment removeAssessment(Assessment assessment) {
		getAssessments().remove(assessment);
		assessment.setQuestionPaper(null);

		return assessment;
	}

	public List<ExamSchedule> getExamSchedules() {
		return this.examSchedules;
	}

	public void setExamSchedules(List<ExamSchedule> examSchedules) {
		this.examSchedules = examSchedules;
	}

	public ExamSchedule addExamSchedule(ExamSchedule examSchedule) {
		getExamSchedules().add(examSchedule);
		examSchedule.setQuestionPaper(this);

		return examSchedule;
	}

	public ExamSchedule removeExamSchedule(ExamSchedule examSchedule) {
		getExamSchedules().remove(examSchedule);
		examSchedule.setQuestionPaper(null);

		return examSchedule;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public List<Question> getQuestions() {
		return this.questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	//extra method
	public void addQuestion(Question question){
		this.questions.add(question);
	}
	
	public List<UserAnswer> getUserAnswers() {
		return this.userAnswers;
	}

	public void setUserAnswers(List<UserAnswer> userAnswers) {
		this.userAnswers = userAnswers;
	}

	public UserAnswer addUserAnswer(UserAnswer userAnswer) {
		getUserAnswers().add(userAnswer);
		userAnswer.setQuestionPaper(this);

		return userAnswer;
	}

	public UserAnswer removeUserAnswer(UserAnswer userAnswer) {
		getUserAnswers().remove(userAnswer);
		userAnswer.setQuestionPaper(null);

		return userAnswer;
	}
	
	public String getQuestionpaperDescription() {
		return questionpaperDescription;
	}

	public void setQuestionpaperDescription(String questionpaperDescription) {
		this.questionpaperDescription = questionpaperDescription;
	}

	@Override
	public String toString() {
		return "QuestionPaper [questionpaperId=" + questionpaperId + ", questionpaperTitle=" + questionpaperTitle + ", questionpaperDescription=" + questionpaperDescription
				+ "]";
	}

}