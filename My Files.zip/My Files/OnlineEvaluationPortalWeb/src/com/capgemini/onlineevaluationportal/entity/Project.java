package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the project database table.
 * 
 */
@Entity
@NamedQuery(name="Project.findAll", query="SELECT p FROM Project p")
public class Project implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="project_id")
	private int projectId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Column(name="project_name")
	private String projectName;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	//bi-directional many-to-one association to Cluster
	@ManyToOne
	@JoinColumn(name="cluster_id")
	private Cluster cluster;

	//bi-directional many-to-one association to QuestionPaper
	@OneToMany(mappedBy="project")
	private List<QuestionPaper> questionPapers;

	public Project() {
	}

	public Project(String createdBy, Date createdTime, String projectName, String updatedBy, Date updatedTime) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.projectName = projectName;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
	}

	public int getProjectId() {
		return this.projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Cluster getCluster() {
		return this.cluster;
	}

	public void setCluster(Cluster cluster) {
		this.cluster = cluster;
	}

	public List<QuestionPaper> getQuestionPapers() {
		return this.questionPapers;
	}

	public void setQuestionPapers(List<QuestionPaper> questionPapers) {
		this.questionPapers = questionPapers;
	}

	public QuestionPaper addQuestionPaper(QuestionPaper questionPaper) {
		getQuestionPapers().add(questionPaper);
		questionPaper.setProject(this);

		return questionPaper;
	}

	public QuestionPaper removeQuestionPaper(QuestionPaper questionPaper) {
		getQuestionPapers().remove(questionPaper);
		questionPaper.setProject(null);

		return questionPaper;
	}

}