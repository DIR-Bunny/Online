package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;

import javax.persistence.*;

import com.capgemini.onlineevaluationportal.entity.QuestionOption;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the question database table.
 * 
 */
@Entity
@NamedQuery(name="Question.findAll", query="SELECT q FROM Question q")
public class Question implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="question_id")
	private int questionId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	private int mark;

	@Lob
	@Column(name="question_description")
	private String questionDescription;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	//bi-directional many-to-one association to QuestionType
	@ManyToOne
	@JoinColumn(name="type_id")
	private QuestionType questionType;

	//bi-directional many-to-one association to Questionlevel
	@ManyToOne
	@JoinColumn(name="question_level_id")
	private Questionlevel questionlevel;

	//bi-directional many-to-one association to QuestionAnswer
	@OneToMany(cascade = CascadeType.ALL,mappedBy="question")
	private List<QuestionAnswer> questionAnswers;

	//bi-directional many-to-many association to QuestionOption
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(
		name="question_option_map"
		, joinColumns={
			@JoinColumn(name="question_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="option_id")
			}
		)
	private List<QuestionOption> questionOptions;

	//bi-directional many-to-many association to QuestionPaper
	@ManyToMany(mappedBy="questions")
	private List<QuestionPaper> questionPapers=new ArrayList<QuestionPaper>();

	//bi-directional many-to-one association to UserAnswer
	@OneToMany(mappedBy="question")
	private List<UserAnswer> userAnswers;
//------------------------------------------------------------------------
	public Question() {
	}
	
	
	public Question(int questionId, int mark, String questionDescription, QuestionType questionType,
		Questionlevel questionlevel) {
	super();
	this.questionId = questionId;
	this.mark = mark;
	this.questionDescription = questionDescription;
	this.questionType = questionType;
	this.questionlevel = questionlevel;
}


	public Question(String createdBy, Date createdTime, int mark,
		String questionDescription, String updatedBy, Date updatedTime,
		QuestionType questionType, Questionlevel questionlevel) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.mark = mark;
		this.questionDescription = questionDescription;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.questionType = questionType;
		this.questionlevel = questionlevel;
	}

	public Question(int questionId) {
		super();
		this.questionId = questionId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Question other = (Question) obj;
		if (questionId != other.questionId)
			return false;
		return true;
	}

	public int getQuestionId() {
		return this.questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public int getMark() {
		return this.mark;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	public String getQuestionDescription() {
		return this.questionDescription;
	}

	public void setQuestionDescription(String questionDescription) {
		this.questionDescription = questionDescription;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public QuestionType getQuestionType() {
		return this.questionType;
	}

	public void setQuestionType(QuestionType questionType) {
		this.questionType = questionType;
	}

	public Questionlevel getQuestionlevel() {
		return this.questionlevel;
	}

	public void setQuestionlevel(Questionlevel questionlevel) {
		this.questionlevel = questionlevel;
	}

	public List<QuestionAnswer> getQuestionAnswers() {
		return this.questionAnswers;
	}

	public void setQuestionAnswers(List<QuestionAnswer> questionAnswers) {
		this.questionAnswers = questionAnswers;
	}

	public QuestionAnswer addQuestionAnswer(QuestionAnswer questionAnswer) {
		getQuestionAnswers().add(questionAnswer);
		questionAnswer.setQuestion(this);

		return questionAnswer;
	}

	public QuestionAnswer removeQuestionAnswer(QuestionAnswer questionAnswer) {
		getQuestionAnswers().remove(questionAnswer);
		questionAnswer.setQuestion(null);

		return questionAnswer;
	}

	public List<QuestionOption> getQuestionOptions() {
		return this.questionOptions;
	}

	public void setQuestionOptions(List<QuestionOption> questionOptions) {
		this.questionOptions = questionOptions;
	}

	/*public List<QuestionPaper> getQuestionPapers() {
		return this.questionPapers;
	}

	public void setQuestionPapers(List<QuestionPaper> questionPapers) {
		this.questionPapers = questionPapers;
	}*/

	public List<UserAnswer> getUserAnswers() {
		return this.userAnswers;
	}

	public void setUserAnswers(List<UserAnswer> userAnswers) {
		this.userAnswers = userAnswers;
	}

	public UserAnswer addUserAnswer(UserAnswer userAnswer) {
		getUserAnswers().add(userAnswer);
		userAnswer.setQuestion(this);

		return userAnswer;
	}

	public UserAnswer removeUserAnswer(UserAnswer userAnswer) {
		getUserAnswers().remove(userAnswer);
		userAnswer.setQuestion(null);

		return userAnswer;
	}

	
	public void addOption(QuestionOption option){
		this.questionOptions.add(option);
	}


	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", createdBy=" + createdBy + ", createdTime=" + createdTime
				+ ", mark=" + mark + ", questionDescription=" + questionDescription + ", updatedBy=" + updatedBy
				+ ", updatedTime=" + updatedTime + ", questionType=" + questionType + ", questionlevel=" + questionlevel
				+ ", questionAnswers=" + questionAnswers + ", questionOptions=" + questionOptions + ", questionPapers="
				+ questionPapers + ", userAnswers=" + userAnswers + "]";
	}
	
	
	


	/*@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", mark=" + mark + ", questionDescription=" + questionDescription
				+ ", questionType=" + questionType + ", questionlevel=" + questionlevel + ", questionAnswers="
				+ questionAnswers + ", questionOptions=" + questionOptions + ", userAnswers=" + userAnswers + "]";
	}*/
	
	
	
}