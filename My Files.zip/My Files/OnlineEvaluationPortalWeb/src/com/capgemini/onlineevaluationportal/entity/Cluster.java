package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the cluster database table.
 * 
 */
@Entity
@NamedQuery(name="Cluster.findAll", query="SELECT c FROM Cluster c")
public class Cluster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="cluster_id")
	private int clusterId;

	@Column(name="cluster_name")
	private String clusterName;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	//bi-directional many-to-one association to Engagement
	@ManyToOne
	@JoinColumn(name="engagement_id")
	private Engagement engagement;

	//bi-directional many-to-one association to Project
	@OneToMany(mappedBy="cluster")
	private List<Project> projects;

	public Cluster() {
	}

	public Cluster(String clusterName, String createdBy, Date createdTime, String updatedBy, Date updatedTime) {
		super();
		this.clusterName = clusterName;
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
	}


	public int getClusterId() {
		return this.clusterId;
	}

	public void setClusterId(int clusterId) {
		this.clusterId = clusterId;
	}

	public String getClusterName() {
		return this.clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Engagement getEngagement() {
		return this.engagement;
	}

	public void setEngagement(Engagement engagement) {
		this.engagement = engagement;
	}

	public List<Project> getProjects() {
		return this.projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public Project addProject(Project project) {
		getProjects().add(project);
		project.setCluster(this);

		return project;
	}

	public Project removeProject(Project project) {
		getProjects().remove(project);
		project.setCluster(null);

		return project;
	}

}