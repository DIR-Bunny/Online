package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@Table(name="user")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private String userId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	private String designation;

	private String emailid;

	private String password;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;

	private String username;

	//bi-directional many-to-one association to Assessment
	@OneToMany(mappedBy="user")
	private List<Assessment> assessments;

	//bi-directional many-to-one association to ExamSchedule
	@OneToMany(mappedBy="user")
	private List<ExamSchedule> examSchedules;


	@Column(name="enabled")
	private boolean enabled;
	
	//bi-directional many-to-one association to UserRole
		@OneToMany(mappedBy="user", fetch=FetchType.EAGER)
		private Set<UserRole> userRoles;
	

	//bi-directional many-to-many association to Group
	@ManyToMany
	@JoinTable(
		name="user_group_map"
		, joinColumns={
			@JoinColumn(name="user_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="group_id")
			}
		)
	private List<Group> groups=new ArrayList<Group>();

	public User() {
	}
		
	public User(String userId) {
		super();
		this.userId = userId;
	}

	public User(String username,String password) {
		super();
		this.password = password;
		this.username = username;
	}

	public User(String userId, String createdBy, Date createdTime,
			String designation, String emailid, String password,
			String updatedBy, Date updatedTime, String username) {
		super();
		this.userId = userId;
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.designation = designation;
		this.emailid = emailid;
		this.password = password;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.username = username;
	}


	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getDesignation() {
		return this.designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTime() {
		return this.updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<Assessment> getAssessments() {
		return this.assessments;
	}

	public void setAssessments(List<Assessment> assessments) {
		this.assessments = assessments;
	}

	public Assessment addAssessment(Assessment assessment) {
		getAssessments().add(assessment);
		assessment.setUser(this);

		return assessment;
	}

	public Assessment removeAssessment(Assessment assessment) {
		getAssessments().remove(assessment);
		assessment.setUser(null);

		return assessment;
	}

	public List<ExamSchedule> getExamSchedules() {
		return this.examSchedules;
	}

	public void setExamSchedules(List<ExamSchedule> examSchedules) {
		this.examSchedules = examSchedules;
	}

	public ExamSchedule addExamSchedule(ExamSchedule examSchedule) {
		getExamSchedules().add(examSchedule);
		examSchedule.setUser(this);

		return examSchedule;
	}

	public ExamSchedule removeExamSchedule(ExamSchedule examSchedule) {
		getExamSchedules().remove(examSchedule);
		examSchedule.setUser(null);

		return examSchedule;
	}

	public List<Group> getGroups() {
		
		return this.groups;
	}

	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}

	public void addGroup(Group group){
		this.groups.add(group);
		System.out.println(group);
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	
	
	public Set<UserRole> getUserRoles() {
			return userRoles;
		}

		public void setUserRoles(Set<UserRole> userRoles) {
			this.userRoles = userRoles;
		}
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", designation="
				+ designation + ", emailid=" + emailid + ", password="
				+ password + ",username=" + username +  "]";
	}
}