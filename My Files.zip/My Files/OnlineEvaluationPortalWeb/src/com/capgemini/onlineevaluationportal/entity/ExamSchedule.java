package com.capgemini.onlineevaluationportal.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the exam_schedule database table.
 * 
 */
@Entity
@Table(name="exam_schedule")
@NamedQuery(name="ExamSchedule.findAll", query="SELECT e FROM ExamSchedule e")
public class ExamSchedule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="testschedule_id")
	private int testscheduleId;

	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time")
	private Date createdTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="due_date")
	private Date dueDate;

	private String status;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="taken_date")
	private Date takenDate;

	@Column(name="updated_by")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_time")
	private Date updatedTime;
	
	@Column(name="passing_percentage")
	public int passingPercentage;
	
	@Column(name="duration_min")
	public int durationMin;
	
	@Column(name="gid")
	public int gid;
	
	//bi-directional many-to-one association to QuestionPaper
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="questionpaper_id")
	private QuestionPaper questionPaper;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;

	public ExamSchedule() {
	}
	
	public ExamSchedule(String status, Date takenDate, QuestionPaper questionPaper, User user) {
		super();
		this.status = status;
		this.takenDate = takenDate;
		this.questionPaper = questionPaper;
		this.user = user;
	}

	//exam status- 0/1- not completed/ completed
	public ExamSchedule(String createdBy, Date createdTime, Date dueDate, String status, Date takenDate,
			String updatedBy, Date updatedTime) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.dueDate = dueDate;
		this.status = status;
		this.takenDate = takenDate;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
	}
	
	public ExamSchedule(String createdBy, Date createdTime, Date dueDate,  String status, Date takenDate,
			String updatedBy, Date updatedTime, int passingPercentage, int durationMin) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.dueDate = dueDate;		
		this.status = status;
		this.takenDate = takenDate;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.passingPercentage = passingPercentage;
		this.durationMin = durationMin;
	}
	public ExamSchedule(String createdBy, Date createdTime, Date dueDate,  String status, Date takenDate,
			String updatedBy, Date updatedTime, int passingPercentage, int durationMin, int gid) {
		super();
		this.createdBy = createdBy;
		this.createdTime = createdTime;
		this.dueDate = dueDate;		
		this.status = status;
		this.takenDate = takenDate;
		this.updatedBy = updatedBy;
		this.updatedTime = updatedTime;
		this.passingPercentage = passingPercentage;
		this.durationMin = durationMin;
		this.gid = gid;
	}
	public int getTestscheduleId() {
		return this.testscheduleId;
	}

	public void setTestscheduleId(int testscheduleId) {
		this.testscheduleId = testscheduleId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTime() {
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getDueDate() {
		return this.dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getTakenDate() {
		return this.takenDate;
	}

	public void setTakenDate(Date takenDate) {
		this.takenDate = takenDate;
	}
	
	public int getPassingPercentage() {
		return passingPercentage;
	}

	public void setPassingPercentage(int passingPercentage) {
		this.passingPercentage = passingPercentage;
	}

	public int getDurationMin() {
		return durationMin;
	}

	public void setDurationMin(int durationMin) {
		this.durationMin = durationMin;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public Date getUpdatedTime() {
		return this.updatedTime;
	}
	
	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public QuestionPaper getQuestionPaper() {
		return this.questionPaper;
	}

	public void setQuestionPaper(QuestionPaper questionPaper) {
		this.questionPaper = questionPaper;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	@Override
	public String toString() {
		return "ExamSchedule [testscheduleId=" + testscheduleId + ", dueDate=" + dueDate + ", status=" + status + ", takenDate=" + takenDate
				+ ", passingPercentage="+ passingPercentage + ", durationMin=" + durationMin + ", gid=" + gid + "]";
	}

	
}