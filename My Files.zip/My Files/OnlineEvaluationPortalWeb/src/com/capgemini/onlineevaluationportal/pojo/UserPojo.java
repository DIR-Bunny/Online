package com.capgemini.onlineevaluationportal.pojo;

public class UserPojo {

	public String userId;
	public String username,password, emailid, designation;
	
	public UserPojo() {
		
	}
	
	public UserPojo(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	
	
	public UserPojo(String userId, String username, String password, String emailid, String designation) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.emailid = emailid;
		this.designation = designation;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "UserPojo [userId=" + userId + ", username=" + username + ", password=" + password + ", emailid="
				+ emailid + ", designation=" + designation + "]";
	}

	
}
