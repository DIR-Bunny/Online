package com.capgemini.onlineevaluationportal.pojo;

public class QuestionAnswerPojo {

}
