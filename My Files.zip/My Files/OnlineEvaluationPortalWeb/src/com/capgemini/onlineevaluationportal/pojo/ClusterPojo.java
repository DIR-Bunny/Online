package com.capgemini.onlineevaluationportal.pojo;

public class ClusterPojo {
	
	int clusterId;
	String clusterName;
	int engagementId;
	
	public ClusterPojo() {
		// TODO Auto-generated constructor stub
	}

	public ClusterPojo(String clusterName, int engagementId) {
		super();
		this.clusterName = clusterName;
		this.engagementId = engagementId;
	}
	
	
	public int getClusterId() {
		return clusterId;
	}

	public void setClusterId(int clusterId) {
		this.clusterId = clusterId;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	public int getEngagementId() {
		return engagementId;
	}

	public void setEngagementId(int engagementId) {
		this.engagementId = engagementId;
	}

	@Override
	public String toString() {
		return "ClusterPojo [clusterId=" + clusterId + ", clusterName=" + clusterName + ", engagementId=" + engagementId
				+ "]";
	}
}
