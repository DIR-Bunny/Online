package com.capgemini.onlineevaluationportal.pojo;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;

public class UploadQuestionPojo 
{
	private Question question;
	private QuestionType type;
	private Questionlevel level;
	private List<QuestionOption> optionsList;
	private List<QuestionAnswer> correctAns;
	public UploadQuestionPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UploadQuestionPojo(Question question, QuestionType type, Questionlevel level,
			List<QuestionOption> optionsList, List<QuestionAnswer> correctAns) {
		super();
		this.question = question;
		this.type = type;
		this.level = level;
		this.optionsList = optionsList;
		this.correctAns = correctAns;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public QuestionType getType() {
		return type;
	}
	public void setType(QuestionType type) {
		this.type = type;
	}
	public Questionlevel getLevel() {
		return level;
	}
	public void setLevel(Questionlevel level) {
		this.level = level;
	}
	public List<QuestionOption> getOptionsList() {
		return optionsList;
	}
	public void setOptionsList(List<QuestionOption> optionsList) {
		this.optionsList = optionsList;
	}
	public List<QuestionAnswer> getCorrectAns() {
		return correctAns;
	}
	public void setCorrectAns(List<QuestionAnswer> correctAns) {
		this.correctAns = correctAns;
	}
	@Override
	public String toString() {
		return "UploadQuestionPojo [question=" + question + ", type=" + type + ", level=" + level + ", optionsList="
				+ optionsList + ", correctAns=" + correctAns + "]";
	}
	
	
	
}
