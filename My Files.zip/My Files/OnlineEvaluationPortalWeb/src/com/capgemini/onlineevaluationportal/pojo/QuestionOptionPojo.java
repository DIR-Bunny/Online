package com.capgemini.onlineevaluationportal.pojo;

public class QuestionOptionPojo {
	
	private int optionId;
	private String optionText;

	public QuestionOptionPojo() {
		// TODO Auto-generated constructor stub
	}

	public QuestionOptionPojo(int optionId, String optionText) {
		super();
		this.optionId = optionId;
		this.optionText = optionText;
	}

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public String getOptionText() {
		return optionText;
	}

	public void setOptionText(String optionText) {
		this.optionText = optionText;
	}

	@Override
	public String toString() {
		return "QuestionOptionPojo [optionId=" + optionId + ", optionText=" + optionText + "]";
	}
}
