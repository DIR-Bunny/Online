package com.capgemini.onlineevaluationportal.pojo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.UserAnswer;

public class QuestionDetails /*implements Serializable */ {
	
	//private static final long serialVersionUID = 1L;
	
	private int questionpaperId;
	private String questionPaperTitle;
	private int questionId;
	private String questionDescription;
	private int mark;
	
	private List<QuestionOption> optionList;
	
	private List<QuestionAnswer> qanswerList = new ArrayList<QuestionAnswer>();
		
	private String[] answers;
	
	private int typeId;
	private String typeName;
	
	private int questionLevelId;
	private String questionLevel;

	public QuestionDetails() {
		
	}
		
	public QuestionDetails(int questionId) {
		super();
		this.questionId = questionId;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuestionDetails other = (QuestionDetails) obj;
		if (questionId != other.questionId)
			return false;
		return true;
	}

	public QuestionDetails(int questionpaperId, String questionPaperTitle, int questionId, String questionDescription, int mark,
			List<QuestionOption> optionList, List<QuestionAnswer> qanswerList, int typeId, String typeName,
			int questionLevelId, String questionLevel) {
		super();
		this.questionpaperId = questionpaperId;
		this.questionPaperTitle = questionPaperTitle;
		this.questionId = questionId;
		this.questionDescription = questionDescription;
		this.mark = mark;
		this.optionList = optionList;
		this.qanswerList = qanswerList;
		this.typeId = typeId;
		this.typeName = typeName;
		this.questionLevelId = questionLevelId;
		this.questionLevel = questionLevel;
	}

	public int getQuestionpaperId() {
		return questionpaperId;
	}

	public void setQuestionpaperId(int questionpaperId) {
		this.questionpaperId = questionpaperId;
	}

	public String getQuestionPaperTitle() {
		return questionPaperTitle;
	}

	public void setQuestionPaperTitle(String questionPaperTitle) {
		this.questionPaperTitle = questionPaperTitle;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestionDescription() {
		return questionDescription;
	}

	public void setQuestionDescription(String questionDescription) {
		this.questionDescription = questionDescription;
	}

	public int getMark() {
		return mark;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	public List<QuestionOption> getOptionList() {
		return optionList;
	}

	public void setOptionList(List<QuestionOption> optionList) {
		this.optionList = optionList;
	}
		
	public List<QuestionAnswer> getQanswerList() {
		return qanswerList;
	}

	public void setQanswerList(List<QuestionAnswer> qanswerList) {
		this.qanswerList = qanswerList;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public int getQuestionLevelId() {
		return questionLevelId;
	}

	public void setQuestionLevelId(int questionLevelId) {
		this.questionLevelId = questionLevelId;
	}

	public String getQuestionLevel() {
		return questionLevel;
	}

	public void setQuestionLevel(String questionLevel) {
		this.questionLevel = questionLevel;
	}
	
	public String[] getAnswers() {
		return answers;
	}

	public void setAnswers(String[] answers) {
		this.answers = answers;
	}

	@Override
	public String toString() {
		return "QuestionDetails [questionpaperId=" + questionpaperId + ", questionPaperTitle=" + questionPaperTitle
				+ ", questionId=" + questionId + ", questionDescription=" + questionDescription + ", mark=" + mark
				+ ", optionList=" + optionList + ", qanswerList=" + qanswerList + ", answers="
				+ Arrays.toString(answers) + ", typeId=" + typeId + ", typeName=" + typeName + ", questionLevelId="
				+ questionLevelId + ", questionLevel=" + questionLevel + "]";
	}


	
}
