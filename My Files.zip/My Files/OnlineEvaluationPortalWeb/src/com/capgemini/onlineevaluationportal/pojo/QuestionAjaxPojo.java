package com.capgemini.onlineevaluationportal.pojo;

public class QuestionAjaxPojo 
{
	private int questionNumber;
	private int totalQuestionsCount;
	private int attemptedQuestionCount;
	private QuestionDetails currentQuestion;
	public QuestionAjaxPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public QuestionAjaxPojo(int questionNumber, int totalQuestionsCount, int attemptedQuestionCount,
			QuestionDetails currentQuestion) {
		super();
		this.questionNumber = questionNumber;
		this.totalQuestionsCount = totalQuestionsCount;
		this.attemptedQuestionCount = attemptedQuestionCount;
		this.currentQuestion = currentQuestion;
	}
	public int getQuestionNumber() {
		return questionNumber;
	}
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}
	public int getTotalQuestionsCount() {
		return totalQuestionsCount;
	}
	public void setTotalQuestionsCount(int totalQuestionsCount) {
		this.totalQuestionsCount = totalQuestionsCount;
	}
	public int getAttemptedQuestionCount() {
		return attemptedQuestionCount;
	}
	public void setAttemptedQuestionCount(int attemptedQuestionCount) {
		this.attemptedQuestionCount = attemptedQuestionCount;
	}
	public QuestionDetails getCurrentQuestion() {
		return currentQuestion;
	}
	public void setCurrentQuestion(QuestionDetails currentQuestion) {
		this.currentQuestion = currentQuestion;
	}
	@Override
	public String toString() {
		return "QuestionAjaxPojo [questionNumber=" + questionNumber + ", totalQuestionsCount=" + totalQuestionsCount
				+ ", attemptedQuestionCount=" + attemptedQuestionCount + ", currentQuestion=" + currentQuestion + "]";
	}
}
