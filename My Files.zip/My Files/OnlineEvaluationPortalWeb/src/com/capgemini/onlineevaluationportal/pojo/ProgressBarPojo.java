package com.capgemini.onlineevaluationportal.pojo;

public class ProgressBarPojo 
{
	private int totalQuestions;
	private int attemptedQues;
	public ProgressBarPojo()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public ProgressBarPojo(int totalQuestions, int attemptedQues) {
		super();
		this.totalQuestions = totalQuestions;
		this.attemptedQues = attemptedQues;
	}
	public int getTotalQuestions() {
		return totalQuestions;
	}
	public void setTotalQuestions(int totalQuestions) {
		this.totalQuestions = totalQuestions;
	}
	public int getAttemptedQues() {
		return attemptedQues;
	}
	public void setAttemptedQues(int attemptedQues) {
		this.attemptedQues = attemptedQues;
	}
	@Override
	public String toString() {
		return "ProgressBarPojo [totalQuestions=" + totalQuestions + ", attemptedQues=" + attemptedQues + "]";
	}
	
}
