package com.capgemini.onlineevaluationportal.pojo;

public class UserAnswerPojo {

	public String userId;
	public Integer questionId;
	public String answer;
	public Integer questionPaperId;
	
	public UserAnswerPojo() {
				
	}
	
	public UserAnswerPojo(Integer questionId) {
		super();
		this.questionId = questionId;
	}
		
	public UserAnswerPojo(String userId, Integer questionId, String answer, Integer questionPaperId) {
		super();
		this.userId = userId;
		this.questionId = questionId;
		this.answer = answer;
		this.questionPaperId = questionPaperId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Integer getQuestionPaperId() {
		return questionPaperId;
	}

	public void setQuestionPaperId(Integer questionPaperId) {
		this.questionPaperId = questionPaperId;
	}

	@Override
	public String toString() {
		return "UserAnswerPojo [userId=" + userId + ", questionId=" + questionId + ", answer=" + answer
				+ ", questionPaperId=" + questionPaperId + "]";
	}
}
