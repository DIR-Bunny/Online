package com.capgemini.onlineevaluationportal.pojo;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.QuestionPaper;

public class ExamSchedulePojo {
	
	public int examScheduleId;
	public int questionPaperId;
	public String questionPaperTitle;
	public String examStatus;
	public String targetDate, completedDate;
	public double score;
	
	public int passing_percentage, duration_time;
	public String questionPaperDescription;
	
	public int qpGroupId;
	public String qpGroupTitle;
	public List<QuestionPaper> qpapers;
	
	public ExamSchedulePojo() {
		
	}
	
	public ExamSchedulePojo(int examScheduleId, int questionPaperId, String questionPaperTitle, String examStatus,
			String targetDate, String completedDate, double score, int passing_percentage, int duration_time,
			String questionPaperDescription, int qpGroupId, String qpGroupTitle) {
		super();
		this.examScheduleId = examScheduleId;
		this.questionPaperId = questionPaperId;
		this.questionPaperTitle = questionPaperTitle;
		this.examStatus = examStatus;
		this.targetDate = targetDate;
		this.completedDate = completedDate;
		this.score = score;
		this.passing_percentage = passing_percentage;
		this.duration_time = duration_time;
		this.questionPaperDescription = questionPaperDescription;
		this.qpGroupId = qpGroupId;
		this.qpGroupTitle = qpGroupTitle;
	}

	public ExamSchedulePojo(int examScheduleId, int questionPaperId, String questionPaperTitle, String examStatus,
			String targetDate, String completedDate, double score, int passing_percentage, 
			int duration_time, String questionPaperDescription) {
		super();
		this.examScheduleId = examScheduleId;
		this.questionPaperId = questionPaperId;
		this.questionPaperTitle = questionPaperTitle;
		this.examStatus = examStatus;
		this.targetDate = targetDate;
		this.completedDate = completedDate;
		this.score = score;
		this.passing_percentage = passing_percentage;
		this.duration_time = duration_time;
		this.questionPaperDescription = questionPaperDescription;
	}
	
	public ExamSchedulePojo(int examScheduleId, int questionPaperId, String questionPaperTitle, String examStatus,
			String targetDate, String completedDate, double score, int passing_percentage, 
			int duration_time) {
		super();
		this.examScheduleId = examScheduleId;
		this.questionPaperId = questionPaperId;
		this.questionPaperTitle = questionPaperTitle;
		this.examStatus = examStatus;
		this.targetDate = targetDate;
		this.completedDate = completedDate;
		this.score = score;
		this.passing_percentage = passing_percentage;
		this.duration_time = duration_time;
	}

	public ExamSchedulePojo(int examScheduleId, int questionPaperId, String questionPaperTitle, String examStatus,
			String targetDate, String completedDate, double score) {
		super();
		this.examScheduleId = examScheduleId;
		this.questionPaperId = questionPaperId;
		this.questionPaperTitle = questionPaperTitle;
		this.examStatus = examStatus;
		this.targetDate = targetDate;
		this.completedDate = completedDate;
		this.score = score;
	}

	public ExamSchedulePojo(int questionPaperId, String questionPaperTitle,	String examStatus, String targetDate, String completedDate,
			double score) {
		super();
		this.questionPaperId = questionPaperId;
		this.questionPaperTitle = questionPaperTitle;
		this.examStatus = examStatus;
		this.targetDate = targetDate;
		this.completedDate = completedDate;
		this.score = score;
	}
	
	public int getExamScheduleId() {
		return examScheduleId;
	}

	public void setExamScheduleId(int examScheduleId) {
		this.examScheduleId = examScheduleId;
	}

	public int getQuestionPaperId() {
		return questionPaperId;
	}

	public void setQuestionPaperId(int questionPaperId) {
		this.questionPaperId = questionPaperId;
	}

	public String getQuestionPaperTitle() {
		return questionPaperTitle;
	}

	public void setQuestionPaperTitle(String questionPaperTitle) {
		this.questionPaperTitle = questionPaperTitle;
	}

	public String getExamStatus() {
		return examStatus;
	}

	public void setExamStatus(String examStatus) {
		this.examStatus = examStatus;
	}

	public String getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}

	public String getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(String completedDate) {
		this.completedDate = completedDate;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}
	
	public int getPassing_percentage() {
		return passing_percentage;
	}

	public void setPassing_percentage(int passing_percentage) {
		this.passing_percentage = passing_percentage;
	}

	public int getDuration_time() {
		return duration_time;
	}

	public void setDuration_time(int duration_time) {
		this.duration_time = duration_time;
	}

	public String getQuestionPaperDescription() {
		return questionPaperDescription;
	}

	public void setQuestionPaperDescription(String questionPaperDescription) {
		this.questionPaperDescription = questionPaperDescription;
	}
	
	public int getQpGroupId() {
		return qpGroupId;
	}

	public void setQpGroupId(int qpGroupId) {
		this.qpGroupId = qpGroupId;
	}
	
	

	public String getQpGroupTitle() {
		return qpGroupTitle;
	}

	public void setQpGroupTitle(String qpGroupTitle) {
		this.qpGroupTitle = qpGroupTitle;
	}
	
	public List<QuestionPaper> getQpapers() {
		return qpapers;
	}

	public void setQpapers(List<QuestionPaper> qpapers) {
		this.qpapers = qpapers;
	}

	@Override
	public String toString() {
		return "ExamSchedulePojo [examScheduleId=" + examScheduleId + ", questionPaperId=" + questionPaperId
				+ ", questionPaperTitle=" + questionPaperTitle + ", examStatus=" + examStatus + ", targetDate="
				+ targetDate + ", completedDate=" + completedDate + ", score=" + score + ", passing_percentage="
				+ passing_percentage + ", duration_time=" + duration_time + ", questionPaperDescription="
				+ questionPaperDescription + ", qpGroupId=" + qpGroupId + ", qpGroupTitle=" + qpGroupTitle + "]";
	}
}
