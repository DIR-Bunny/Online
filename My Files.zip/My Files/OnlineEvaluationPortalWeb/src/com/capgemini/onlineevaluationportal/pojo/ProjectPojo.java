package com.capgemini.onlineevaluationportal.pojo;

public class ProjectPojo {

	int projectId;
	String projectName;
	int clusterId;
	
	public ProjectPojo() {
		// TODO Auto-generated constructor stub
	}

	public ProjectPojo(String projectName, int clusterId) {
		super();
		this.projectName = projectName;
		this.clusterId = clusterId;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getClusterId() {
		return clusterId;
	}

	public void setClusterId(int clusterId) {
		this.clusterId = clusterId;
	}

	@Override
	public String toString() {
		return "ProjectPojo [projectId=" + projectId + ", projectName=" + projectName + ", clusterId=" + clusterId
				+ "]";
	}

}
