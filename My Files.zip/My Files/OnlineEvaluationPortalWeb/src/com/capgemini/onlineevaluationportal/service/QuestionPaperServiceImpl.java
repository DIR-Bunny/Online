package com.capgemini.onlineevaluationportal.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.OptionDao;
import com.capgemini.onlineevaluationportal.dao.QuestionPaperDao;
import com.capgemini.onlineevaluationportal.dao.QuestionPaperGroupDao;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.QuestionPaperGroup;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;
import com.capgemini.onlineevaluationportal.pojo.QuestionOptionPojo;

@Service
@Transactional
public class QuestionPaperServiceImpl implements QuestionPaperService {

	private static Logger logger = Logger.getLogger(QuestionPaperServiceImpl.class);

	@Autowired
	private QuestionPaperDao quespaperDao;	
	@Autowired
	public OptionDao optionDao;
	@Autowired
	public QuestionPaperGroupDao qpGroupDao;
	
	@Override
	public Integer addQuestionToQuestionPaper(Integer qpId, Integer qId) {
		
		logger.debug("Entering addQuestionToQuestionPaper(qpId,qId)");
		quespaperDao.addQuestionToQuestionPaper(qpId, qId);
		logger.debug("Exiting addQuestionToQuestionPaper(qpId,qId)");
		
		return 0;
	}

	@Override
	public ArrayList<Integer> loadQuestionPaper(int qpId) {
		
		logger.debug("Entering loadQuestionPaper(qpId)");
		
		logger.debug("Exiting loadQuestionPaper(qpId)");
		return quespaperDao.getQuestionIdList(qpId);
	}
	
	@Override
	public HashMap<Integer,Integer> loadPaper(int qpId) {
		logger.debug("Entering loadPaper(qpId)");
		ArrayList<Integer> idList = quespaperDao.getQuestionIdList(qpId);
		HashMap<Integer,Integer> idMap = new HashMap<Integer,Integer>();
		for(int index=0; index < idList.size(); index++){
				idMap.put(index+1,idList.get(index));
			}
		logger.debug("Exiting loadPaper(qpId)");
		return idMap;
		
	}

	@Override
	public String getQuestionPaperTitle(int qpid) {
		logger.debug("Entering getQuestionPaperTitle(qpId)");
		logger.debug("Exiting getQuestionPaperTitle(qpId)");
	
		return quespaperDao.getQuestionPaperTitle(qpid);
	}

	@Override
	public List<QuestionDetails> getAllQuestions(int qpaperId) {
		logger.debug("Entering getAllQuestions(qpaperId)");
		List<QuestionOptionPojo> optionsPojo = new ArrayList<QuestionOptionPojo>();
		ArrayList<QuestionOption> options = new ArrayList<QuestionOption>();
		List<QuestionAnswer> qanswers = new ArrayList<QuestionAnswer>();
		QuestionDetails pojo=null;
		List<QuestionDetails> qdetailsList = new ArrayList<QuestionDetails>();
		List<Question> questionList = quespaperDao.getAllQuestions(qpaperId);
		String qpaperTitle = quespaperDao.getQuestionPaperTitle(qpaperId);
				
		for(Question question : questionList){
			
			options=(ArrayList<QuestionOption>) optionDao.getQptionByQsId(question.getQuestionId());
			pojo = new QuestionDetails(qpaperId, qpaperTitle, question.getQuestionId(), question.getQuestionDescription(), question.getMark(), 
					options, qanswers,  question.getQuestionType().getTypeId(), question.getQuestionType().getTypeName(), 
					question.getQuestionlevel().getQuestionLevelId(), question.getQuestionlevel().getQuestionLevel());
			//System.out.println("pojo in qp serv :"+pojo);
			
			qdetailsList.add(pojo);
		}
		logger.debug("Exiting getAllQuestions(qpaperId)");
		return qdetailsList;
	}

	@Override
	public Integer createQuestionPaperGroup(QuestionPaperGroup qpGroup) {
		logger.debug("Entering createQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		
		logger.debug("Exiting createQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		return qpGroupDao.createQuestionPaperGroup(qpGroup);
	}

	@Override
	public Integer removeQuestionPaperGroup(QuestionPaperGroup qpGroup) {
		logger.debug("Entering removeQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		
		logger.debug("Exiting removeQuestionPaperGroup(QuestionPaperGroup qpGroup)");
		return qpGroupDao.removeQuestionPaperGroup(qpGroup);
	}

	@Override
	public void addQPtoQPGroup(int qpId, int qpGroupId) {
		logger.debug("Entering addQPtoQPGroup(int qpId, int qpGroupId)");
		qpGroupDao.addQPtoQPGroup(qpId, qpGroupId);
		logger.debug("Exiting addQPtoQPGroup(int qpId, int qpGroupId)");
	}

	
}
