package com.capgemini.onlineevaluationportal.service;

import com.capgemini.onlineevaluationportal.pojo.ProjectPojo;

public interface ProjectService {
	
	public Integer addProject(ProjectPojo project);

}
