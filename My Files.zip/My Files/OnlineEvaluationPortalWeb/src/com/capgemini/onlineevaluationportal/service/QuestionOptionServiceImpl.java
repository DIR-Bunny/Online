package com.capgemini.onlineevaluationportal.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;





import com.capgemini.onlineevaluationportal.dao.OptionDao;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;


@Service
@Transactional
public class QuestionOptionServiceImpl implements QuestionOptionService {
	
	private static Logger logger = Logger.getLogger(QuestionOptionServiceImpl.class);

	@Autowired
	private OptionDao daoInterface;

	@Override
	public int addOption(QuestionOption questionOption) {
		logger.debug("Entering addOption(questionOption)");
		daoInterface.addOption(questionOption);
		logger.debug("Exiting addOption(questionOption)");
		return 0;
	}

	@Override
	public void deleteOption(Integer id) {
		logger.debug("Entering deleteOption(id)");
		daoInterface.deleteOption(id);
		logger.debug("Exiting deleteOption(id)");
		
	}

	@Override
	public List<QuestionOption> getAllOptions() {
		logger.debug("Entering getAllOptions()");
		List<QuestionOption> list=daoInterface.getAllOptions();
		logger.debug("Exiting getAllOptions()");
		return list;
	}

	@Override
	public List<QuestionOption> getOptionByQs(Integer id) {
		logger.debug("Entering getOptionByQs(id)");
		List<QuestionOption> list=daoInterface.getQptionByQsId(id);
		logger.debug("Exiting getOptionByQs(id)");
		return list;
	}
	
	@Override
	public void addOptionToQs(QuestionOption option) {
		logger.debug("Entering addOptionToQs(option)");
		daoInterface.addOptionToQusetion(option);
		logger.debug("Exiting addOptionToQs(option)");
		
	}

	@Override
	public QuestionOption getOptionDetails(Integer optionId) {
		
		return daoInterface.getOptionDetails(optionId);
	}
}
