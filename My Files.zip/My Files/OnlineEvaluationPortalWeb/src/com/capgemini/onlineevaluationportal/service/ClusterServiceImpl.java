package com.capgemini.onlineevaluationportal.service;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.controller.EngagementController;
import com.capgemini.onlineevaluationportal.dao.ClusterDao;
import com.capgemini.onlineevaluationportal.entity.Cluster;
import com.capgemini.onlineevaluationportal.entity.Engagement;
import com.capgemini.onlineevaluationportal.pojo.ClusterPojo;

@Service
@Transactional
public class ClusterServiceImpl implements ClusterService {

	private static Logger logger = Logger.getLogger(ClusterServiceImpl.class);
	
	@Autowired
	public ClusterDao clusterDao;
	
	@Override
	public Integer addCluster(ClusterPojo clusterpojo) {
		logger.debug("Entering addCluster(clusterpojo)");
		
		Date d=new Date();
		Cluster clusterEntity= new Cluster(clusterpojo.getClusterName(), "SSM", d, "SSM", d); 
		
		Engagement eng=new Engagement();
		eng.setEngagementId(clusterpojo.getEngagementId());
		
		clusterEntity.setEngagement(eng);
		int cid = clusterDao.addCluster(clusterEntity);
		logger.debug("Exiting addCluster(clusterpojo)");
		return cid;
	}

}
