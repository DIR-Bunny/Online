package com.capgemini.onlineevaluationportal.service;

import com.capgemini.onlineevaluationportal.entity.Group;
import com.capgemini.onlineevaluationportal.entity.User;

public interface GroupService {
	
	public Integer creategroup(Group group);

	public String deletegroup(String groupId);
	
	public Integer addUserToGroup(Group group, User user);

}
