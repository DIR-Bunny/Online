package com.capgemini.onlineevaluationportal.service;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.ExamScheduleDao;
import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.User;

@Service
@Transactional
public class ExamServiceImpl implements ExamService {

	private static Logger logger = Logger.getLogger(ExamServiceImpl.class);
	
	
	@Autowired
	public ExamScheduleDao examDao;
	
	@Override
	public Integer createExamSchedule(ExamSchedule exam) {
		logger.debug("Entering createExamSchedule(exam)");
		
		
		/*Date d = new Date();
		exam = new ExamSchedule("SSM", d, d, "Pending", (byte) 1, d, "SSM", d);
		
		QuestionPaper qp=new QuestionPaper();
		qp.setQuestionpaperId(15);
		exam.setQuestionPaper(qp);
		
		User usr=new User();
		usr.setUserId("IN_99415");
		exam.setUser(usr);
		
		int id = (Integer)examDao.createExamShedule(exam);
		return id;*/
		logger.debug("Exiting createExamSchedule(exam)");
		return 0;
	}

	@Override
	public boolean updateOverDueExams() {
		logger.debug("Entering updateOverDueExams()");
		examDao.updateOverDueExams();
		logger.debug("Exiting updateOverDueExams()");
		return false;
	}

	

}
