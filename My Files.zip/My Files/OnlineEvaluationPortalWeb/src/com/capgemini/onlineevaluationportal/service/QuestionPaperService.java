package com.capgemini.onlineevaluationportal.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.capgemini.onlineevaluationportal.entity.QuestionPaperGroup;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;

public interface QuestionPaperService {
	
	public Integer addQuestionToQuestionPaper(Integer qpId, Integer qId);
	
	public ArrayList<Integer> loadQuestionPaper(int qpId);
	
	public HashMap<Integer,Integer> loadPaper(int qpId) ;
	
	public String getQuestionPaperTitle(int qpid);
	
	public List<QuestionDetails> getAllQuestions( int qpaperId);
	
	public Integer createQuestionPaperGroup(QuestionPaperGroup qpGroup);
	
	public Integer removeQuestionPaperGroup(QuestionPaperGroup qpGroup);
	
	public void addQPtoQPGroup(int qpId, int qpGroupId);
}
