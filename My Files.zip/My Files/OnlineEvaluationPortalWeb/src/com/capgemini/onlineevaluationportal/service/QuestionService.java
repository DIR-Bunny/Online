package com.capgemini.onlineevaluationportal.service;

import java.util.List;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;

public interface QuestionService {

	public Integer addQuestion(Question question);
	
	public Integer deleteQuestion(int quesId);

	/*public Integer addOptionToQs(Integer qid, Integer oid);*/
	
	public List<QuestionDetails> getQuestionsFromQuestionPaper(int qpId);
	
	public QuestionDetails getNextQuestion(int qpId, int previousQId);
	
	public QuestionDetails getQuestionById(int qpId, int questionId);
	
}
