package com.capgemini.onlineevaluationportal.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.UserDao;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {

	private static Logger logger = Logger.getLogger(LoginServiceImpl.class);
	
	@Autowired
	public UserDao userDao;
	
	@Override
	public String authenticateUser(UserPojo user) {
		logger.debug("Entering authenticateUser(user)");
		String msg=null;
		
		User userEntity=new User(user.getUsername(), user.getPassword());
		
		User userobj = userDao.authenticateUser(userEntity);
		if(userobj != null){
			msg = userobj.getUserId();
		}
		logger.debug("Exiting authenticateUser(user)");
		return msg;
	}

	@Override
	public UserPojo getUserDetailsById(String id) 
	{
		logger.debug("Entering getUserDetailsById(id)");
		
		User user = userDao.getUserDetailsById(id);
		
		UserPojo userPojo=new UserPojo(user.getUserId(), user.getUsername(), user.getPassword(), user.getEmailid(), user.getDesignation());
		logger.debug("Exiting getUserDetailsById(id)");
		return userPojo;
	}

	@Override
	public UserPojo getUserDetailsByUsername(String username) 
	{
		logger.debug("Entering getUserDetailsByUsername(username)");
		logger.debug("Exiting getUserDetailsByUsername(username)");
		return userDao.getUserDetailsByUsername(username);
		
	}

	
}
