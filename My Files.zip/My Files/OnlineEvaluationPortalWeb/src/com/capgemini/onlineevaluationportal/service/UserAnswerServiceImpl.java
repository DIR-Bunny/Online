package com.capgemini.onlineevaluationportal.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.AssessmentDao;
import com.capgemini.onlineevaluationportal.dao.ExamScheduleDao;
import com.capgemini.onlineevaluationportal.dao.UserAnswerDao;
import com.capgemini.onlineevaluationportal.entity.Assessment;
import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.entity.UserAnswer;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;
import com.capgemini.onlineevaluationportal.pojo.UserAnswerPojo;

@Service
@Transactional
public class UserAnswerServiceImpl implements UserAnswerService{

	@Autowired
	public UserAnswerDao answerDao;
	@Autowired
	public AssessmentDao assessDao;
	@Autowired
	public ExamScheduleDao examDao; 
	@Autowired
	public QuestionServiceImpl qService;
	
	@Override
	public boolean storeUserAnswers(List<UserAnswerPojo> answers) {
		System.err.println("My ans "+answers);
		List<UserAnswer> answerEntities = new ArrayList<UserAnswer>();
		for(UserAnswerPojo ans : answers)
		{
			System.err.println("My ans2 "+ans.getAnswer());
			answerEntities.add(new UserAnswer(ans.getUserId(), ans.getAnswer(), new Question(ans.getQuestionId()), new QuestionPaper(ans.getQuestionPaperId())));
		}
		return answerDao.storeUserAnswers(answerEntities);
	}

	@Override
	public void setMarkScoredByUser(UserAnswerPojo userAnswer) {
		User user = new User();
		user.setUserId(userAnswer.getUserId());
		answerDao.setMarkScoredByUser(user, userAnswer.getQuestionPaperId());
	}

	@Override
	public double calculateTotalScoreByUserId(UserAnswerPojo userAnswer) {	
		UserAnswer answer = new UserAnswer(userAnswer.getUserId(), userAnswer.getAnswer(), (Question)new Question(userAnswer.getQuestionId()) , (QuestionPaper)new QuestionPaper(userAnswer.getQuestionPaperId()));
		return answerDao.calculateTotalScoreByUserId(answer);
	}

	@Override
	public boolean processAssessment(UserAnswerPojo userAnswer) {	
		double score = calculateTotalScoreByUserId(userAnswer);
		//System.out.println("score :"+score);
		Assessment assessment = new Assessment(score, (QuestionPaper)new QuestionPaper(userAnswer.getQuestionPaperId()),(User)new User(userAnswer.getUserId()));
		int assessid = assessDao.processAssessment(assessment);
		return true;
	}
	
	@Override
	public boolean updateExamSchedule(UserAnswerPojo userAnswer, String updatedExamStatus) {
		ExamSchedule exam = new ExamSchedule(updatedExamStatus, new Date(), (QuestionPaper)new QuestionPaper(userAnswer.getQuestionPaperId()), (User)new User(userAnswer.getUserId()));
		examDao.updateExamSchedule(exam);
		return true;
	}
	
	@Override
	public boolean processExamSubmission(List<UserAnswerPojo> userAnswers) {	
		QuestionDetails question; 
		int countDescriptive = 0;
		System.out.println("processExamSubmission "+ userAnswers);
		storeUserAnswers(userAnswers);
		setMarkScoredByUser(userAnswers.get(0));
		//if atleast one qtype is 'descriptive' then dont update assessment & examschedule 
		for(UserAnswerPojo ans : userAnswers){
			question = qService.getQuestionById(ans.getQuestionPaperId(), ans.getQuestionId());
			countDescriptive=  (question.getTypeName().equalsIgnoreCase("DESCRIPTIVE")) ? countDescriptive+1 : countDescriptive+0;
		}
		if(countDescriptive == 0 ){
			boolean assessmentStatus = processAssessment(userAnswers.get(0));
			if(assessmentStatus == true) {
				updateExamSchedule(userAnswers.get(0), "Completed");  ////Completed
			}
		} else if(countDescriptive > 0){
			updateExamSchedule(userAnswers.get(0), "Attempted");  /// Attempted
		}
		
		return true;
		
    }

	
}
