package com.capgemini.onlineevaluationportal.service;

import com.capgemini.onlineevaluationportal.entity.ExamSchedule;

public interface ExamService {
	
	public Integer createExamSchedule(ExamSchedule exam);
	
	public boolean updateOverDueExams();

}
