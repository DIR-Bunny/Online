package com.capgemini.onlineevaluationportal.service;

import java.io.Console;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.AssessmentDao;
import com.capgemini.onlineevaluationportal.dao.ExamScheduleDao;
import com.capgemini.onlineevaluationportal.dao.QuestionPaperDao;
import com.capgemini.onlineevaluationportal.dao.QuestionPaperGroupDao;
import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionPaperGroup;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.pojo.ExamSchedulePojo;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;

@Service
@Transactional
public class DashboardServiceImpl implements DashboardService {
	
	private static Logger logger = Logger.getLogger(DashboardServiceImpl.class);	
	@Autowired
	public ExamScheduleDao examDao;
	@Autowired
	public QuestionPaperDao qpDao;
	@Autowired
	public AssessmentDao assessDao; 
	@Autowired
	public LoginService loginService;
	@Autowired
	public QuestionPaperGroupDao qpGroupDao; 
		
	@Override
	public List<ExamSchedulePojo> getUserExamSchedule(UserPojo user) 
	{
		logger.debug("Entering getUserExamSchedule(user)");
		
		List<ExamSchedulePojo> examList=new ArrayList<ExamSchedulePojo>();
		QuestionPaperGroup qpGroup = new QuestionPaperGroup(); 
		String userid=user.getUserId();		
		String examStatus=null;
		String targetDate=null,completedDate=null;
		Date cDate=null;
		double score=0;
		SimpleDateFormat sdf=new SimpleDateFormat("dd MMMM yyyy");
		List<ExamSchedule> exams = examDao.getUserExamSchedule(userid);
		for(ExamSchedule e : exams){
			
			qpGroup = qpGroupDao.getQuestionPaperGroup(e.getGid());			
			examStatus = e.getStatus(); 		
			targetDate = sdf.format(e.getDueDate());
			cDate = e.getTakenDate();
			completedDate = (cDate == null) ? "  Not taken" : sdf.format(cDate); 
			score = assessDao.getUserScore(e.getUser().getUserId(), e.getQuestionPaper().getQuestionpaperId());
			
			//examList.add(new ExamSchedulePojo(e.getTestscheduleId(),e.getQuestionPaper().getQuestionpaperId() ,e.getQuestionPaper().getQuestionpaperTitle(),examStatus,targetDate,completedDate,score, e.getPassingPercentage(),e.getDurationMin(),e.getQuestionPaper().getQuestionpaperDescription()));
			for(QuestionPaper paper : qpGroup.getQuestionPapers()){
				examList.add(new ExamSchedulePojo(e.getTestscheduleId(), paper.getQuestionpaperId() ,paper.getQuestionpaperTitle(),examStatus,targetDate,completedDate,score, e.getPassingPercentage(),e.getDurationMin(),paper.getQuestionpaperDescription(),qpGroup.getGid(),qpGroup.getGroupTitle()));
			}			
		}
		//System.err.println("in dashboard service :"+examList);
		logger.debug("Exiting getUserExamSchedule(user)");
		return examList;
	}

	@Override
	public Integer countCompletedAssessments(List<ExamSchedulePojo> examList) {
		logger.debug("Entering countCompletedAssessments(examList)");
		
		int count = 0;
		for(ExamSchedulePojo e : examList){
			if(e.getExamStatus().equalsIgnoreCase("Completed")){ 
					count++; 	
			}		
		}
		logger.debug("Exiting countCompletedAssessments(examList)");
		return count;
	}

	@Override
	public Integer countPendingAssessments(List<ExamSchedulePojo> examList) {
		logger.debug("Entering countPendingAssessments(examList)");
		int count = 0;
		for(ExamSchedulePojo e : examList){
			if(e.getExamStatus().equalsIgnoreCase("Pending")){ 
					count++; 	
			}		
		}
		logger.debug("Exiting countPendingAssessments(examList)");
		return count;
	}

	
	@Override
	public List<ExamSchedulePojo> getUserExamScheduleBySearch(String serachParam) 
	{
		List<ExamSchedulePojo> examList=new ArrayList<ExamSchedulePojo>();
		String examStatus=null;
		String targetDate=null,completedDate=null;
		Date cDate=null;
		double score=0;
		SimpleDateFormat sdf=new SimpleDateFormat("dd MMMM yyyy");
		List<ExamSchedule> exams = examDao.getUserExamScheduleBySearch(serachParam);
		System.out.println("Inside service Dashboard  "+exams );
		for(ExamSchedule e : exams)
		{
			examStatus = e.getStatus(); 		
			targetDate = sdf.format(e.getDueDate());
			cDate = e.getTakenDate();
			completedDate = (cDate == null) ? "  Not taken" : sdf.format(cDate); 
			score = assessDao.getUserScore(e.getUser().getUserId(), e.getQuestionPaper().getQuestionpaperId());
			examList.add(new ExamSchedulePojo(e.getTestscheduleId(),e.getQuestionPaper().getQuestionpaperId() ,e.getQuestionPaper().getQuestionpaperTitle(),examStatus,targetDate,completedDate,score, e.getPassingPercentage(), e.getDurationMin()));	
		}
		
		return examList;
	}
	
}
