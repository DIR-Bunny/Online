package com.capgemini.onlineevaluationportal.service;

import java.util.List;


import com.capgemini.onlineevaluationportal.entity.QuestionOption;


public interface QuestionOptionService {
	
	public int addOption(QuestionOption questionOption);
	public void deleteOption(Integer id);
	public List<QuestionOption> getAllOptions();
	public List<QuestionOption> getOptionByQs(Integer id);
	public void addOptionToQs(QuestionOption option);

	public QuestionOption getOptionDetails(Integer optionId);
}
