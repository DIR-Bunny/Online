package com.capgemini.onlineevaluationportal.service;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.ProjectDao;
import com.capgemini.onlineevaluationportal.entity.Cluster;
import com.capgemini.onlineevaluationportal.entity.Project;
import com.capgemini.onlineevaluationportal.pojo.ProjectPojo;

@Service
@Transactional
public class ProjectServiceImpl implements ProjectService {
	
	
	private static Logger logger = Logger.getLogger(ProjectServiceImpl.class);

	@Autowired
	public ProjectDao projectDao;

	@Override
	public Integer addProject(ProjectPojo projectPojo) {
		logger.debug("Entering addProject(projectPojo)");
		
		Date d=new Date();
		Project projectEntity = new Project("SSM",d, projectPojo.getProjectName(), "SSM", d);
		
		Cluster c=new Cluster();
		c.setClusterId(projectPojo.getClusterId());
		projectEntity.setCluster(c);
		
		int id=projectDao.addProject(projectEntity);
		logger.debug("Exiting addProject(projectPojo)");
		return id;
	}
	
	

}
