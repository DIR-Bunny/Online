package com.capgemini.onlineevaluationportal.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.OptionDao;
import com.capgemini.onlineevaluationportal.dao.QuestionDao;
import com.capgemini.onlineevaluationportal.dao.QuestionPaperDao;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;
import com.capgemini.onlineevaluationportal.pojo.QuestionOptionPojo;

@Service
@Transactional
public class QuestionServiceImpl implements QuestionService{
	
	private static Logger logger = Logger.getLogger(QuestionServiceImpl.class);

	@Autowired
	public QuestionDao qDao;
	
	@Autowired
	public QuestionPaperDao qpDao;
	
	@Autowired
	public OptionDao optionDao;
	
	@Override
	public Integer addQuestion(Question question) {
		
		return qDao.addQuestion(question);
	}

	@Override
	public Integer deleteQuestion(int quesId) {
		logger.debug("Entering deleteQuestion(quesId)");
		logger.debug("Exiting deleteQuestion(quesId)");
		
		return qDao.deleteQuestion(quesId);
	}
	@Override
	public List<QuestionDetails> getQuestionsFromQuestionPaper(int qpId) {
		logger.debug("Entering getQuestionsFromQuestionPaper(qpId)");
		
		List<QuestionOption> options = new ArrayList<QuestionOption>();
		List<QuestionOptionPojo> optionsPojo = new ArrayList<QuestionOptionPojo>();
		List<QuestionAnswer> qanswers = new ArrayList<QuestionAnswer>();
		QuestionDetails pojo=null;
		List<QuestionDetails> qdetailsList = new ArrayList<QuestionDetails>();
		List<Question> questionList = qDao.getQuestionsFromQuestionPaper(qpId);
		String qptitle = qpDao.getQuestionPaperTitle(qpId);
		
		for(Question question : questionList){
			
			options=(List<QuestionOption>) optionDao.getQptionByQsId(question.getQuestionId());
			pojo = new QuestionDetails(qpId,qptitle ,question.getQuestionId(), question.getQuestionDescription(), question.getMark(), 
					options, qanswers, question.getQuestionType().getTypeId(), question.getQuestionType().getTypeName(), 
					question.getQuestionlevel().getQuestionLevelId(), question.getQuestionlevel().getQuestionLevel());
			qdetailsList.add(pojo);
		}
		logger.debug("Exiting getQuestionsFromQuestionPaper(qpId)");
		return qdetailsList;
	}

	@Override
	public QuestionDetails getNextQuestion(int qpId, int previousQId) {
		logger.debug("Entering getNextQuestion(qpId,previousQId)");

	
		List<QuestionOption> options = new ArrayList<QuestionOption>();
		List<QuestionAnswer> qanswers = new ArrayList<QuestionAnswer>();
		QuestionDetails nextQuesDetails = new QuestionDetails();
		Question question = qDao.getNextQuestion(qpId, previousQId);
		options=(List<QuestionOption>) optionDao.getQptionByQsId(question.getQuestionId());
		
		String qptitle = qpDao.getQuestionPaperTitle(qpId);
		nextQuesDetails=new QuestionDetails(qpId,qptitle, question.getQuestionId(), question.getQuestionDescription(), question.getMark(), options, qanswers, question.getQuestionType().getTypeId(), question.getQuestionType().getTypeName(), question.getQuestionlevel().getQuestionLevelId(), question.getQuestionlevel().getQuestionLevel());
		//System.out.println(nextQuesDetails);
		logger.debug("Exiting getNextQuestion(qpId,previousQId)");
		return nextQuesDetails;
	}

	@Override
	public QuestionDetails getQuestionById(int qpId, int questionId) {
		logger.debug("Entering getQuestionById(qpId,questionId)");
		
		ArrayList<QuestionOption> options = new ArrayList<QuestionOption>();
		List<QuestionAnswer> qanswers = new ArrayList<QuestionAnswer>();
				
		Question question = qDao.getQuestionById(questionId);
		options=(ArrayList<QuestionOption>) optionDao.getQptionByQsId(question.getQuestionId());
		String qptitle = qpDao.getQuestionPaperTitle(qpId);
		QuestionDetails quesDetails = new QuestionDetails(qpId,qptitle, question.getQuestionId(), question.getQuestionDescription(), question.getMark(), options, qanswers, question.getQuestionType().getTypeId(), question.getQuestionType().getTypeName(), question.getQuestionlevel().getQuestionLevelId(), question.getQuestionlevel().getQuestionLevel());
	
		logger.debug("Exiting getQuestionById(qpId,questionId)");
		return quesDetails;
	}

}
