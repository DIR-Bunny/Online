package com.capgemini.onlineevaluationportal.service;

import java.io.InputStream;


public interface UploadService
{
	//public void SaveUsers(InputStream inputStream, String excelFileName) throws Exception;
	public void SaveQuestions(InputStream inputStream, String excelFileName) throws Exception;
}
