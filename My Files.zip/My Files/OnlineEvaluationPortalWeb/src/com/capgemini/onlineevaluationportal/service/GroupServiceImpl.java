package com.capgemini.onlineevaluationportal.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.GroupDao;
import com.capgemini.onlineevaluationportal.entity.Group;
import com.capgemini.onlineevaluationportal.entity.User;

@Service
@Transactional
public class GroupServiceImpl implements GroupService {

	private static Logger logger = Logger.getLogger(GroupServiceImpl.class);
	
	@Autowired
	private GroupDao gDao;
	
	@Override
	public Integer creategroup(Group group) {
		logger.debug("Entering creategroup(group)");
		gDao.creategroup(group);
		logger.debug("Exiting creategroup(group)");
		return 0;
	}

	@Override
	public String deletegroup(String groupId) {
		logger.debug("Entering deletegroup(groupId)");
		gDao.deletegroup(groupId);
		logger.debug("Exiting deletegroup(groupId)");
		return null;
	}

	@Override
	public Integer addUserToGroup(Group group, User user) {
		logger.debug("Entering addUserToGroup(group,user)");
		gDao.addUserToGroup(group, user);
		logger.debug("Exiting addUserToGroup(group,user)");
		return 0;
	}

}
