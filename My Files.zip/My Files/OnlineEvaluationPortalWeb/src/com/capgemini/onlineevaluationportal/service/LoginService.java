package com.capgemini.onlineevaluationportal.service;

import com.capgemini.onlineevaluationportal.pojo.UserPojo;

public interface LoginService {

	public String authenticateUser(UserPojo user);
	
	public UserPojo getUserDetailsById(String id);
	
	public UserPojo getUserDetailsByUsername(String username);
	
}
