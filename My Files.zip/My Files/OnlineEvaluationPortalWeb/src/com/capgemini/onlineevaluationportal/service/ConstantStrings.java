package com.capgemini.onlineevaluationportal.service;

public interface ConstantStrings {
	
	public String QUESTION_LIST = "questionList";
	
	public String TOTAL_QUESTIONS_COUNT = "total_questions_count";
	
	public String QUESTION_NUMBER = "question_number";
	
	public String SESSION_USER = "session_user";

	public String COUNT_TOTAL_ASSESSMENT = "countTotalAssessment";
	
	public String COUNT_COMPLETED = "countCompleted";
	
	public String COUNT_PENDING = "countPending";
	
	public String INVALID_USER = "Invalid username or password";
	
	public String  CURRENT_QUESTION = "currentQuestion";
	
	public String QUESTION_PAPER_TITLE = "questionpaperTitle";
	
	public String CURRENT_EXAM = "current_exam";
	
}
