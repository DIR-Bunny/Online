package com.capgemini.onlineevaluationportal.service;

import java.util.List;

import com.capgemini.onlineevaluationportal.pojo.ExamSchedulePojo;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;

public interface DashboardService {

	public List<ExamSchedulePojo> getUserExamSchedule(UserPojo user);
	
	public Integer countCompletedAssessments(List<ExamSchedulePojo> examList);
	
	public Integer countPendingAssessments(List<ExamSchedulePojo> examList);
	
	public List<ExamSchedulePojo> getUserExamScheduleBySearch(String serachParam);
}
