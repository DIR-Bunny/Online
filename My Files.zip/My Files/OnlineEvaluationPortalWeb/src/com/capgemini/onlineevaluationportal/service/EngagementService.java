package com.capgemini.onlineevaluationportal.service;

import com.capgemini.onlineevaluationportal.entity.Engagement;

public interface EngagementService {

	public int addEngagement(Engagement engagement);
}
