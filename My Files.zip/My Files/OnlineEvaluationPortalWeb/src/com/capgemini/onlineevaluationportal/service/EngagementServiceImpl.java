package com.capgemini.onlineevaluationportal.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.onlineevaluationportal.dao.EngagementDao;
import com.capgemini.onlineevaluationportal.entity.Engagement;

@Service
@Transactional
public class EngagementServiceImpl implements EngagementService {

	private static Logger logger = Logger.getLogger(EngagementServiceImpl.class);
	
	@Autowired
	private EngagementDao engagementDao;
	@Override
	public int addEngagement(Engagement engagement) {
		
		logger.debug("Entering addEngagement(engagement)");
		
		engagementDao.addEngagement(engagement);
		logger.debug("Exiting addEngagement(engagement)");
		return 0;
	}

}
