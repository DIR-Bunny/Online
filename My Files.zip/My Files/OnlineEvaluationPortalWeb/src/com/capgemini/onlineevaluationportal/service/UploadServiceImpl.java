package com.capgemini.onlineevaluationportal.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.onlineevaluationportal.dao.UploadDao;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;
import com.capgemini.onlineevaluationportal.pojo.CustomGenericException;
import com.capgemini.onlineevaluationportal.pojo.UploadQuestionPojo;

@Service
public class UploadServiceImpl implements UploadService
{
	

	@Autowired
	private UploadDao uploadDao;
	
	
	/*@Override
	public void SaveUsers(InputStream inputStream, String excelFileName) throws Exception
	{
		List<User> userList = new ArrayList<User>();
		
		///Get workbook
		Workbook workbook = uploadDao.getWorkbook(inputStream, excelFileName);
		
		/// get spread sheet 
		
		Sheet worksheet = workbook.getSheetAt(0);
		
		
		Iterator<Row> rowIterator =  worksheet.iterator();
		 
		 while (rowIterator.hasNext())
		{
			Row nextRow  = rowIterator.next();
			
			System.out.print("Row : "+nextRow.getRowNum()+" ");
			
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			User user =  new User();
			
			while (cellIterator.hasNext())
			{
	            Cell nextCell = cellIterator.next();
	            int columnIndex = nextCell.getColumnIndex();
	            
	            
	            switch (columnIndex)
	            {
		            case 1:
		                System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
		                user.setUserId(String.valueOf(uploadDao.getCellValue(nextCell)));
		                break;
		            case 2:
		            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
		            	user.setUsername((String) uploadDao.getCellValue(nextCell));
		                break;
		            case 3:
		            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
		            	user.setPassword((String) uploadDao.getCellValue(nextCell));
		                break;
		            case 4:
		            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
		            	user.setEmailid((String) uploadDao.getCellValue(nextCell));
		            	break;
		            case 5:
		            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
		            	user.setDesignation((String) uploadDao.getCellValue(nextCell));
		            	break;
	            }
	            
	        }
			System.out.println("");
			if (nextRow.getRowNum() > 0)
			{
				System.out.println(user.getUserId()+user.getUsername()+user.getEmailid()+user.getPassword());
				
				userList.add(user);
			}
			
		}
		uploadDao.SaveUsers(userList);

	}*/
	
	
	@Override
	public void SaveQuestions(InputStream inputStream, String excelFileName) throws CustomGenericException
	{
		List<UploadQuestionPojo> QuestionList = new ArrayList<UploadQuestionPojo>();
		
		///Get workbook
		try 
		{
			Workbook workbook = uploadDao.getWorkbook(inputStream, excelFileName);
			
			/// get spread sheet 
			Sheet worksheet = workbook.getSheetAt(0);
			
			
			Iterator<Row> rowIterator =  worksheet.iterator();
			 
			 while (rowIterator.hasNext())
			{
				 
				Row nextRow  = rowIterator.next();
				if(nextRow.getRowNum() == 0)
					continue;
				else
				{
					System.out.print("Row : "+nextRow.getRowNum()+" ");
					
					Iterator<Cell> cellIterator = nextRow.cellIterator();
					
					UploadQuestionPojo obj =  new UploadQuestionPojo();
					Question question = null;
					QuestionType type = null;
					Questionlevel level = null;
					QuestionOption option = null;
					QuestionAnswer answer = null;
					List<QuestionOption> optionsList = new ArrayList<>();
					List<QuestionAnswer> answersList = new ArrayList<>();
					
					
					while (cellIterator.hasNext())
					{
						
			            Cell nextCell = cellIterator.next();
			            int columnIndex = nextCell.getColumnIndex();
			            //question = new Question();
			            switch (columnIndex)
			            {
			            
				            case 0:
				                System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				                //user.setUserId(String.valueOf(uploadDao.getCellValue(nextCell)));
				                question = new Question();
				                type = new QuestionType();
				                type.setTypeName(String.valueOf(uploadDao.getCellValue(nextCell)));
				                //question.setQuestionType(type);
				                question.setQuestionType(type);
				                obj.setType(type);
				                break;
				            case 1:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setUsername((String) uploadDao.getCellValue(nextCell));
				            	level = new Questionlevel();
				            	level.setQuestionLevel(String.valueOf(uploadDao.getCellValue(nextCell)));
				                question.setQuestionlevel(level);
				            	obj.setLevel(level);
				                break;
				            case 2:
				            	System.err.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setPassword((String) uploadDao.getCellValue(nextCell));
				            	question.setQuestionDescription((String) uploadDao.getCellValue(nextCell));
				            	System.out.println("Question Description is "+ question.getQuestionDescription());
				            	/*question.setQuestionlevel(level);
				            	question.setQuestionType(type);*/
				            	obj.setQuestion(question);
				                break;
				            case 3:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setEmailid((String) uploadDao.getCellValue(nextCell));
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
				            		option = new QuestionOption();
				            		option.setOptionText((String) uploadDao.getCellValue(nextCell));
				            		optionsList.add(option);
				            		question.setQuestionOptions(optionsList);
				            		obj.setQuestion(question);
				            	}	
				            	break;
				            case 4:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setEmailid((String) uploadDao.getCellValue(nextCell));
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
				            		option = new QuestionOption();
				            		option.setOptionText((String) uploadDao.getCellValue(nextCell));
				            		optionsList.add(option);
				            		question.setQuestionOptions(optionsList);
				            		obj.setQuestion(question);
				            	}	
				            	break;
				            case 5:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setEmailid((String) uploadDao.getCellValue(nextCell));
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
				            		option = new QuestionOption();
				            		option.setOptionText((String) uploadDao.getCellValue(nextCell));
				            		optionsList.add(option);
				            		question.setQuestionOptions(optionsList);
				            		obj.setQuestion(question);
				            	}	
				            	break;
				            case 6:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setEmailid((String) uploadDao.getCellValue(nextCell));
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
				            		option = new QuestionOption();
				            		option.setOptionText((String) uploadDao.getCellValue(nextCell));
				            		optionsList.add(option);
				            		question.setQuestionOptions(optionsList);
				            		obj.setQuestion(question);
				            	}	
				            	break;
				            case 7:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setEmailid((String) uploadDao.getCellValue(nextCell));
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
				            		option = new QuestionOption();
				            		option.setOptionText((String) uploadDao.getCellValue(nextCell));
				            		optionsList.add(option);
				            		question.setQuestionOptions(optionsList);
				            		obj.setQuestion(question);
				            	}	
				            	break;
				            case 8:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	//user.setEmailid((String) uploadDao.getCellValue(nextCell));
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
				            		option = new QuestionOption();
				            		option.setOptionText((String) uploadDao.getCellValue(nextCell));
				            		optionsList.add(option);
				            		question.setQuestionOptions(optionsList);
				            		obj.setQuestion(question);
				            	}	
				            	break;
				            case 9:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	answer = new QuestionAnswer();
				            	answer.setCorrectAnswer((String) uploadDao.getCellValue(nextCell));
				            	answersList.add(answer);
				            	//question.setQuestionAnswers(answersList);
			            		obj.setCorrectAns(answersList);
				            	break;
				            case 10:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
					            	answer = new QuestionAnswer();
					            	answer.setCorrectAnswer((String) uploadDao.getCellValue(nextCell));
					            	answersList.add(answer);
					            	//question.setQuestionAnswers(answersList);
				            		obj.setCorrectAns(answersList);
				            	}
				            	break;
				            case 11:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
					            	answer = new QuestionAnswer();
					            	answer.setCorrectAnswer((String) uploadDao.getCellValue(nextCell));
					            	answersList.add(answer);
					            	//question.setQuestionAnswers(answersList);
				            		obj.setCorrectAns(answersList);
				            	}
				            	break;
				            case 12:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
					            	answer = new QuestionAnswer();
					            	answer.setCorrectAnswer((String) uploadDao.getCellValue(nextCell));
					            	answersList.add(answer);
					            	//question.setQuestionAnswers(answersList);
				            		obj.setCorrectAns(answersList);
				            	}
				            	break;
				            case 13:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	if((String) uploadDao.getCellValue(nextCell) != null)
				            	{
					            	answer = new QuestionAnswer();
					            	answer.setCorrectAnswer((String) uploadDao.getCellValue(nextCell));
					            	answersList.add(answer);
					            	//question.setQuestionAnswers(answersList);
				            		obj.setCorrectAns(answersList);
				            	}
				            	break;
				            case 14:
				            	System.out.print(columnIndex+" "+uploadDao.getCellValue(nextCell)+" ");
				            	int mark = ((Double)uploadDao.getCellValue(nextCell)).intValue();
				            	question.setMark(mark);
				            	obj.setQuestion(question);
				            	break;
			            }
			            
			        }
					System.out.println("");
					if (nextRow.getRowNum() > 0)
					{
						//obj.setQuestion(question);
						System.err.println(obj);
						
						QuestionList.add(obj);
					}
					
				}
				
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Error already occured 2");
			throw new CustomGenericException("123", "Something went wrong with processing your Excel file!! Please check Excel or try again Later");
		}
		uploadDao.SaveQuestions(QuestionList);
		
	}


}
