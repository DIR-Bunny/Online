package com.capgemini.onlineevaluationportal.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.onlineevaluationportal.dao.UserDaoImpl;
import com.capgemini.onlineevaluationportal.entity.UserRole;

@Transactional
@Service("myUserDetailsService")
public class myUserDetailsService implements UserDetailsService
{
	
	private static Logger logger = Logger.getLogger(myUserDetailsService.class);
	
	@Autowired
	@Qualifier("UserDaoImpl")
    private UserDaoImpl dao;
	
     
	public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException 
	{
		logger.debug("Entering loadUserByUsername(username)");

		System.out.println("inside");
		System.out.println("Logged in "+" "+username);
		com.capgemini.onlineevaluationportal.entity.User user = dao.findByUserName(username);
		
		for (UserRole role : user.getUserRoles()) {
			System.out.println("user role "+role.get_role());
		}
		List<GrantedAuthority> authorities = buildUserAuthority(user.getUserRoles());
		logger.debug("Exiting loadUserByUsername(username)");
		
		return (UserDetails) buildUserForAuthentication(user, authorities);

	}

	private org.springframework.security.core.userdetails.User  buildUserForAuthentication(com.capgemini.onlineevaluationportal.entity.User user,
			List<GrantedAuthority> authorities) {
		logger.debug("Entering buildUserForAuthentication(user,authorities)");
		logger.debug("Exiting buildUserForAuthentication(user,authorities)");
			return new org.springframework.security.core.userdetails.User(user.getUsername(),
					user.getPassword(), user.isEnabled(),
                    true, true, true, authorities);
		}

	private List<GrantedAuthority> buildUserAuthority(Set<UserRole> userRoles) {
		logger.debug("Entering buildUserAuthority(userRoles)");

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

		// Build user's authorities
		for (UserRole userRoles1 : userRoles) 
		{
			setAuths.add(new SimpleGrantedAuthority(userRoles1.get_role()));
		}

		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);

		logger.debug("Exiting buildUserAuthority(userRoles)");
		
		return Result;
	}


}
