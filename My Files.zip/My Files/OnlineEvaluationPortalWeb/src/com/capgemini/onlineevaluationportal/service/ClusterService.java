package com.capgemini.onlineevaluationportal.service;

import com.capgemini.onlineevaluationportal.pojo.ClusterPojo;

public interface ClusterService {

	public Integer addCluster(ClusterPojo cluster);
}
