package com.capgemini.onlineevaluationportal.service;

import java.util.List;

import com.capgemini.onlineevaluationportal.pojo.UserAnswerPojo;

public interface UserAnswerService {

	public boolean storeUserAnswers(List<UserAnswerPojo> answers);
	
	public void setMarkScoredByUser(UserAnswerPojo user);
	
	public double calculateTotalScoreByUserId(UserAnswerPojo userAnswer);
	
	public boolean processAssessment(UserAnswerPojo userAnswer);
	
	public boolean updateExamSchedule(UserAnswerPojo userAnswer, String updatedExamStatus);
	
	public boolean processExamSubmission(List<UserAnswerPojo> userAnswers);
}
