package com.capgemini.onlineevaluationportal.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.capgemini.onlineevaluationportal.pojo.ExamSchedulePojo;
import com.capgemini.onlineevaluationportal.pojo.ProgressBarPojo;
import com.capgemini.onlineevaluationportal.pojo.QuestionAjaxPojo;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;
import com.capgemini.onlineevaluationportal.pojo.UserAnswerPojo;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;
import com.capgemini.onlineevaluationportal.service.ConstantStrings;
import com.capgemini.onlineevaluationportal.service.DashboardService;
import com.capgemini.onlineevaluationportal.service.LoginService;
import com.capgemini.onlineevaluationportal.service.UserAnswerService;

@Controller
@RequestMapping("/ajax")
public class RestController 
{
	
	private static Logger logger = Logger.getLogger(RestController.class);
	@Autowired
	private LoginService loginService;
	@Autowired
	public UserAnswerService userAnswerService;
	
	@Autowired
	public DashboardService dashboardService;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) 
	{
		logger.debug("Entering initBinder(binder)");
	    binder.registerCustomEditor(String[].class, new StringArrayPropertyEditor(null));
	    logger.debug("Exiting initBinder(binder)");
	}
	
	@RequestMapping(value = "/Demo", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public void Demo()
	
	{

		logger.debug("Entering Demo()");
		System.out.println("ahe ki");
		logger.debug("Exiting Demo()");
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/take-exam-ajax", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public QuestionAjaxPojo getQuestion(@RequestParam(value="questionId") int quesId ,
			@RequestParam(value="submitValue", required=false) String submitValue, 
			@RequestParam(value="answers[]", required=false) String[] answers,@RequestParam(value="requiredIndex", required=false) int requiredIndex, HttpSession session,HttpServletResponse response)
	{
		int attemptedQuestions=0;
		logger.debug("Entering getQuestion(quesId,submitValue,answers,session)");
		/*String[] strArr = new String[answers.size()];
		strArr = answers.toArray(strArr);*/
		/*for (String string : answers) 
		{
			System.err.println("Ans in Controller details "+ string);
		}*/
		
		if(answers != null)
		{
			for (String string : answers) {
				System.out.println("Ans "+string);
			}
		}
		
		
		QuestionAjaxPojo obj = new QuestionAjaxPojo();
		//System.err.println("Ans in Controller  Size "+answers.length);
		
		QuestionDetails currentQuestion = null;
		List<QuestionDetails> questionList = (List<QuestionDetails>) session.getAttribute(ConstantStrings.QUESTION_LIST);
		
		int index = questionList.indexOf(new QuestionDetails(quesId));
		//System.out.println("Index "+ index);
		if(index > -1)
		{
			//System.out.println("Ans set in q "+answers.toString());
			questionList.get(index).setAnswers(answers);
		}
		if(submitValue == null){
			submitValue = "";
		}
		if(submitValue.equalsIgnoreCase("TAKE TEST") || submitValue.equalsIgnoreCase("NEXT")){
			System.out.println("I am in next ");
			int current_index = index + 1;
			currentQuestion= questionList.get(current_index);
			
			//map.addAttribute(ConstantStrings.QUESTION_NUMBER, (current_index+1));
			obj.setQuestionNumber(current_index+1);
			//map.addAttribute(currentQuestion);
			//map.addAttribute(ConstantStrings.CURRENT_QUESTION, currentQuestion);
			obj.setCurrentQuestion(currentQuestion);
		}
		else if(submitValue.equalsIgnoreCase("PREVIOUS")){
			System.out.println("I am in previous ");
			int current_index = index - 1;
			System.out.println("Index : "+index+"  Current "+current_index);
			currentQuestion= questionList.get(current_index);
			//map.addAttribute(ConstantStrings.QUESTION_NUMBER, (current_index+1));
			obj.setQuestionNumber(current_index+1);
			//map.addAttribute(currentQuestion);
			//map.addAttribute(ConstantStrings.CURRENT_QUESTION, currentQuestion);
			obj.setCurrentQuestion(currentQuestion);
		}
		else if(submitValue.equalsIgnoreCase("SAVE")){
			int current_index = index;
			currentQuestion= questionList.get(current_index);
			System.err.println("In save RC: "+currentQuestion);
			obj.setQuestionNumber(current_index+1);
			obj.setCurrentQuestion(currentQuestion);
		}
		else if(submitValue.equalsIgnoreCase("SUBMIT TEST")){
			
			/*Handel null pointer exception for no anwers in list*/
			UserPojo user = getPrincipal();
			List<UserAnswerPojo> userAnswers = new ArrayList<UserAnswerPojo>();
			for(QuestionDetails ques : questionList)
			{
				if(ques.getAnswers() == null)
				{
					userAnswers.add(new UserAnswerPojo(user.getUserId(), ques.getQuestionId(), "", ques.getQuestionpaperId())); 
				}else{
					String temp = "";
					int i =0;
					for(String ans : ques.getAnswers())
					{
						/*if(i == ques.getAnswers().size())
						 	temp += ans;	
						else
							temp += ans+",";*/
						userAnswers.add(new UserAnswerPojo(user.getUserId(), ques.getQuestionId(), ans, ques.getQuestionpaperId()));
					}
					//userAnswers.add(new UserAnswerPojo(user.getUserId(), ques.getQuestionId(), temp, ques.getQuestionpaperId()));
					System.err.println("In controller 2 "+userAnswers);
				}
			}
			
			//userAnswerService.processExamSubmission(userAnswers);
			System.out.println("Finished Test");
			/*try {
				response.sendRedirect("/OnlineEvaluationPortalWeb/user/assessment");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			return new QuestionAjaxPojo();
		}
		else if(requiredIndex >= 0){
			System.out.println("required index :"+requiredIndex);
			//int current_index = index + 1;
			currentQuestion= questionList.get(requiredIndex-1);
			
			//map.addAttribute(ConstantStrings.QUESTION_NUMBER, (current_index+1));
			obj.setQuestionNumber(requiredIndex);
			//map.addAttribute(currentQuestion);
			//map.addAttribute(ConstantStrings.CURRENT_QUESTION, currentQuestion);
			obj.setCurrentQuestion(currentQuestion);
		}
		int temp = 0;
		for (QuestionDetails questionDetails : questionList) 
		{
			if(questionDetails.getAnswers() != null)
			{
				if(questionDetails.getAnswers().length >= 1)
				{
					for (String str: questionDetails.getAnswers()) 
					{
						if((str != "") && temp < 1 )
						{
							System.out.println("ASDNNASD "+str);
							System.out.println("Attempted "+questionDetails.getQuestionId()+"   "+questionDetails.getAnswers());
							attemptedQuestions +=1;
							temp++;
						}
						
					}
					
					temp = 0;
				}
				
			}
				
		}
		obj.setAttemptedQuestionCount(attemptedQuestions);
		obj.setTotalQuestionsCount((int) session.getAttribute(ConstantStrings.TOTAL_QUESTIONS_COUNT));
		System.out.println("Fina obj "+obj);
		logger.debug("Exiting getQuestion(quesId,submitValue,answers,session)");
		return obj;
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/get-attempted-ajax", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public ProgressBarPojo getAttemptedQueNo(HttpSession session)
	{
		logger.debug("Entering getAttemptedQueNo(HttpSession session)");
		
		List<QuestionDetails> questionList = (List<QuestionDetails>) session.getAttribute(ConstantStrings.QUESTION_LIST);
		int temp = 0, attemptedQuestions = 0;
		for (QuestionDetails questionDetails : questionList) 
		{
			
			if(questionDetails.getAnswers() != null)
			{
				if(questionDetails.getAnswers().length >= 1)
				{
					for (String str: questionDetails.getAnswers()) 
					{
						if((str != "") && temp < 1 )
						{
							System.out.println("ASDNNASD "+str);
							System.out.println("Attempted "+questionDetails.getQuestionId()+"   "+questionDetails.getAnswers());
							attemptedQuestions += 1;
							temp++;
						}
						
					}
					
					temp = 0;
				}
				
			}
				
		}
		logger.debug("Leaving getAttemptedQueNo(HttpSession session)");
		return  new ProgressBarPojo((int) session.getAttribute(ConstantStrings.TOTAL_QUESTIONS_COUNT), attemptedQuestions);
	}
	
	
	
	@RequestMapping(value="/get-search-ajax", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public List<ExamSchedulePojo> getSearchAjax(HttpSession session, @RequestParam(value="SearchParam") String searchParam)
	{
		logger.debug("Entering  getSearchAjax(HttpSession session, @RequestParam(value='SearchParam') String searchParam)");
		List<ExamSchedulePojo> exams =  null;
		if(searchParam.length() >= 3)
		{
			 exams = dashboardService.getUserExamScheduleBySearch(searchParam);
			//map.addAttribute("exams", exams);
			session.setAttribute("exams", exams);
			/*map.addAttribute(ConstantStrings.COUNT_TOTAL_ASSESSMENT, exams.size());
			map.addAttribute(ConstantStrings.COUNT_COMPLETED, dashboardService.countCompletedAssessments(exams));
			map.addAttribute(ConstantStrings.COUNT_PENDING, dashboardService.countPendingAssessments(exams));*/
			System.err.println(exams);
			logger.debug("Leaving  getSearchAjax(HttpSession session, @RequestParam(value='SearchParam') String searchParam)");
			return exams;
		}
		else
		{
			UserPojo user=getPrincipal();
			logger.debug("Leaving  getSearchAjax(HttpSession session, @RequestParam(value='SearchParam') String searchParam)");
			return dashboardService.getUserExamSchedule(user);
		}
	}
	
	
	private UserPojo getPrincipal()
	 {
		logger.debug("Entering getPrincipal()");
	 	UserPojo user = null;
      String userName = null;
      Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
      
	       if (principal instanceof UserDetails) 
	        {
	            userName = ((UserDetails)principal).getUsername();
	            System.out.println("Loged in user "+userName);
	            user =  loginService.getUserDetailsByUsername(userName);
	        } else 
	        {
	            userName = principal.toString();
	            user =  loginService.getUserDetailsByUsername(userName);
	        }
	       logger.debug("Exiting getPrincipal()");
	        return user;
	  }
	  
	  
	  
	  
	  @RequestMapping(value = "/getCluster", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getClusterNames(@RequestParam(value="CHARS") String name,HttpSession session )
	{
		List<String> ClusterList = new ArrayList<>();
		ClusterList.add("a");
		ClusterList.add("b");
		ClusterList.add("c");
		ClusterList.add("d");
		return ClusterList;	
		
	}
	
	
	@RequestMapping(value = "/getProjects", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getProject(@RequestParam(value="CHARS") String name,HttpSession session )
	{
		List<String> ProjectList = new ArrayList<>();
		ProjectList.add("p");
		ProjectList.add("pa");
		ProjectList.add("pb");
		ProjectList.add("pc");
		return ProjectList;	
		
	}
	
	
	@RequestMapping(value = "/getQP", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getQP(@RequestParam(value="CHARS") String name,HttpSession session )
	{
		List<String> QPList = new ArrayList<>();
		QPList.add("QP1");
		QPList.add("QP2");
		QPList.add("QP3");
		QPList.add("QP4");
		return QPList;	
		
	}
	
	
	@RequestMapping(value = "/getAllDescriptive", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<Descriptive> getAllDescriptive(HttpSession session )
	{
		List<Descriptive> DescriptiveAnsList = new ArrayList<Descriptive>();
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP2", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP3", "UN"));
		return DescriptiveAnsList;	
		
	}
	
	@RequestMapping(value = "/getAllDescriptiveByQpId", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<DescritpiveAnswer> getAllDescriptiveByQpId(@RequestParam(value="projectName") String projectName,@RequestParam(value="QPtitle") String QPtitle,@RequestParam(value="userName") String userName,HttpSession session )
	{
		System.out.println(projectName+QPtitle+userName);
//////////////get all questions from user ans with decriptive ans
		List<DescritpiveAnswer> DescriptiveAnsList = new ArrayList<DescritpiveAnswer>();
		DescriptiveAnsList.add(new DescritpiveAnswer("q1", "Ans1", "UN", 3));
		DescriptiveAnsList.add(new DescritpiveAnswer("q2", "Ans2", "UN", 4));
		DescriptiveAnsList.add(new DescritpiveAnswer("q3", "Ans3", "UN", 5));
		DescriptiveAnsList.add(new DescritpiveAnswer("q4", "Ans4", "UN", 6));
		
		return DescriptiveAnsList;
		
	}
	
	
	@RequestMapping(value = "/getAllDescriptiveQpByProject", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<Descriptive> getAllDescriptiveQpByProject(@RequestParam(value="projectName") String projectName,HttpSession session )
	{
//////////////get all questions from user ans with decriptive ans
		List<Descriptive> DescriptiveAnsList = new ArrayList<Descriptive>();
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP1", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP2", "UN"));
		DescriptiveAnsList.add(new Descriptive("A", "QP3", "UN"));
		
		return DescriptiveAnsList;	
	}
}
