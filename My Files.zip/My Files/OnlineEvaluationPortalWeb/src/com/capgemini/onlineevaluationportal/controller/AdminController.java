package com.capgemini.onlineevaluationportal.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;
import com.capgemini.onlineevaluationportal.pojo.CustomGenericException;
import com.capgemini.onlineevaluationportal.pojo.UploadQuestionPojo;
import com.capgemini.onlineevaluationportal.service.UploadService;

@Controller
@RequestMapping("Admin")
public class AdminController 
{
	private static Logger logger = Logger.getLogger(AdminController.class);	
	
	@Autowired
	UploadService uploadService;
	
	
	
	@RequestMapping(value = "Upload", method = RequestMethod.GET)
	public ModelAndView Upload() 
	{
		logger.debug("Entering in Upload()");
		System.out.println("Upload madhe ahe");
		logger.debug("Exiting from Upload()");
		return new ModelAndView("Upload");
		
	}
	
	@SuppressWarnings("resource")
	@RequestMapping(value = "Upload",headers=("content-type= multipart/*"), method = RequestMethod.POST)
	public String Upload(@RequestParam("excelfile") MultipartFile excelfile) throws CustomGenericException
	{
		logger.debug("Entering in Upload(excelfile)");
		try
		{
			uploadService.SaveQuestions(excelfile.getInputStream(), excelfile.getOriginalFilename());
		} 
		catch (IOException e) 
		{
			System.out.println("I am in ADmin Controller Exception 1");
			throw new CustomGenericException("1234", "Something went wrong with processing your Excel file!! Please check Excel or try again Later");
		} catch (Exception e) 
		{
			System.out.println("I am in ADmin Controller Exception 2");
			throw new CustomGenericException("1234", "Something went wrong with processing your Excel file!! Please check Excel or try again Later");
		}
            
		logger.debug("Exiting from Upload(excelfile)");
		return "done";
	}
	
	
	
	@RequestMapping(value = "/Dashboard", method = RequestMethod.GET)
	public ModelAndView Dashboard() 
	{
		logger.debug("Entering in Dashboard()");
		System.out.println("Inside AdminDashboard");
		logger.debug("Exiting frmo Dashboard()");
		return new ModelAndView("AdminDashborad");
	}
	
	 @RequestMapping(value = "downloadExcel")
		public ModelAndView Download()
		{
		 logger.debug("Entering in Download()");
			UploadQuestionPojo obj = new UploadQuestionPojo();
			QuestionType type = new QuestionType();
			Questionlevel level = new Questionlevel();
			Question que = new Question();
			List<QuestionOption> queOptionList = new ArrayList<>();
			List<QuestionAnswer> correctAns = new ArrayList<>();
			
			
			type.setTypeName("QuestionType");
			level.setQuestionLevel("QuestionLevel");
			que.setQuestionDescription("Question Description");
			
			QuestionOption opt = new QuestionOption();
			opt.setOptionText("Option 1");
			queOptionList.add(opt);
			
			opt = new QuestionOption();
			opt.setOptionText("Option 2");
			queOptionList.add(opt);
			
			opt = new QuestionOption();
			opt.setOptionText("Option 3");
			queOptionList.add(opt);
			
			opt = new QuestionOption();
			opt.setOptionText("Option 4");
			queOptionList.add(opt);
			
			opt = new QuestionOption();
			opt.setOptionText("Option 5");
			queOptionList.add(opt);
			
			opt = new QuestionOption();
			opt.setOptionText("Option 6");
			queOptionList.add(opt);
			
			QuestionAnswer ans = new QuestionAnswer();
			ans.setCorrectAnswer("Option 3");
			correctAns.add(ans);
			
			ans = new QuestionAnswer();
			ans.setCorrectAnswer("Option 4");
			correctAns.add(ans);
			ans = new QuestionAnswer();
			ans.setCorrectAnswer("Option 2");
			correctAns.add(ans);
			ans = new QuestionAnswer();
			ans.setCorrectAnswer("Option 5");
			correctAns.add(ans);
			ans = new QuestionAnswer();
			ans.setCorrectAnswer("Option 1");
			correctAns.add(ans);
			
			que.setMark(10);
			
			obj.setQuestion(que);
			obj.setCorrectAns(correctAns);
			obj.setLevel(level);
			obj.setType(type);
			obj.setOptionsList(queOptionList);
			
			logger.debug("Exiting from Download()");
			return new ModelAndView("excelView", "uploadPojo", obj);
		}
	 
	 
	@RequestMapping("CheckDescriptive")
	public ModelAndView CheckDescriptive()
	{
		System.out.println("I am in Descriptive ");
		return new ModelAndView("CheckDescriptive");
	}
	
	@RequestMapping("AddQue")
	public ModelAndView AddQue()
	{
		System.out.println("I am in AddQue ");
		List<String> LevelList = new ArrayList<>();
		LevelList.add("Beginer");
		LevelList.add("Intermediate");
		LevelList.add("Expert");
		
		List<String> TypeList = new ArrayList<>();
		TypeList.add("MCQ");
		TypeList.add("DESCRIPTIVE");
		TypeList.add("MULTIPLES");
		ModelMap map = new ModelMap();
		map.addAttribute("LevelList", LevelList);
		map.addAttribute("TypeList", TypeList);
		
		return new ModelAndView("AddQuestions",map);
	}
	
	
	@RequestMapping("AD")
	public ModelAndView Admin()
	{
		System.out.println("I am in Ad ");
		List<String> engagementList = new ArrayList<>();
		engagementList.add("IKEA");
		engagementList.add("Capgemini");
		engagementList.add("A");
		engagementList.add("B");
		System.out.println("Admin");
		return new ModelAndView("AD",new ModelMap().addAttribute("Elist", engagementList));
	}
	 
	 ///////////////////////////////////Error Handler///////////////////////////////////////////////////////////
	 @ExceptionHandler(CustomGenericException.class)
		public ModelAndView handleCustomException(CustomGenericException ex) 
		{
		 logger.debug("Entering in handleCustomException( ex)");
			System.err.println("I am in handelCustomsuccess");
			ModelAndView model = new ModelAndView("MyErrorPage");
			model.addObject("exception", ex);
			logger.debug("Exiting from handleCustomException(ex)");
			return model;
		}
		
		
		
		
	
}
