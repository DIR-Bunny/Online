package com.capgemini.onlineevaluationportal.controller;



import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionPaper;
import com.capgemini.onlineevaluationportal.entity.QuestionPaperGroup;
import com.capgemini.onlineevaluationportal.service.QuestionPaperService;

@Controller
@RequestMapping("/question-paper")
public class QuestionPaperController {
	private static Logger logger = Logger.getLogger(QuestionPaperController.class);

	@Autowired
	public QuestionPaperService qpService;
	
	@RequestMapping("/add_ques_to_paper")
	public String addQuesToQuesPaper(){
		logger.debug("Entering addQuesToQuesPaper()");
		qpService.addQuestionToQuestionPaper(15,117);
		logger.debug("Exiting addQuesToQuesPaper()");
		return "done";
	}
	
	@RequestMapping("/createQPGroup")
	public String createQuestionPaperGroup(){
		logger.debug("Entering createQuestionPaperGroup()");
		qpService.createQuestionPaperGroup(new QuestionPaperGroup("Java", 3));
		logger.debug("Exiting createQuestionPaperGroup()");
		return "done";
	}
	//remove qp-group
	
	@RequestMapping("/addQPGroup")
	public String addQPtoQPGroup(){
		logger.debug("Entering addQPtoQPGroup()");
		qpService.addQPtoQPGroup(26, 2);
		logger.debug("Exiting addQPtoQPGroup()");
		return "done";
	}		
}
