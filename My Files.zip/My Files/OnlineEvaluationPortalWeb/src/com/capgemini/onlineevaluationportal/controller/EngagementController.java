package com.capgemini.onlineevaluationportal.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.onlineevaluationportal.entity.Cluster;
import com.capgemini.onlineevaluationportal.entity.Engagement;
import com.capgemini.onlineevaluationportal.pojo.ClusterPojo;
import com.capgemini.onlineevaluationportal.pojo.ProjectPojo;
import com.capgemini.onlineevaluationportal.service.ClusterService;
import com.capgemini.onlineevaluationportal.service.EngagementService;
import com.capgemini.onlineevaluationportal.service.ProjectService;

@Controller
public class EngagementController {

	private static Logger logger = Logger.getLogger(EngagementController.class);
	
	@Autowired
	public EngagementService engagementService;
	
	@Autowired
	public ClusterService clusterService;
	
	@Autowired
	public ProjectService projectService;
	
	@RequestMapping("add_engagement")
	public String addEngagement(){
		logger.debug("Entering addEngagement()");
		Date d=new Date();
		Engagement engagement=new Engagement("SSM", d, "IKEA", "SSM", d);
		engagementService.addEngagement(engagement);
		logger.debug("Exiting addEngagement()");
		return "done";
	}
	
	@RequestMapping("add_cluster")
	public String addCluster(){
		
		ClusterPojo pojo = new ClusterPojo("IRW",21);
		clusterService.addCluster(pojo);
		return "done";
	}	
	
	@RequestMapping("add_project")
	public String addProject(){
		logger.debug("Entering addProject()");
		ProjectPojo pojo = new ProjectPojo("SLF", 2);
		projectService.addProject(pojo);
		logger.debug("Exiting addProject()");
		return "done";
	}	
}
