package com.capgemini.onlineevaluationportal.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.onlineevaluationportal.entity.Group;
import com.capgemini.onlineevaluationportal.entity.User;
import com.capgemini.onlineevaluationportal.service.GroupService;


@Controller
public class GroupController {
	private static Logger logger = Logger.getLogger(GroupController.class);
	@Autowired
	private GroupService gService;
	
	@RequestMapping("create_group")
	public String showCreategroup(){
		logger.debug("Entering showCreategroup()");
		Group g=new Group();
		gService.creategroup(g);
		logger.debug("Exiting showCreategroup()");
		return "done";
	}
	
	@RequestMapping("delete_group")
	public String showDeleteGroup(){
		logger.debug("Entering showDeleteGroup()");
		String gid="G01";
		gService.deletegroup(gid);
		logger.debug("Exiting showDeleteGroup()");
		return "done";
	}
	
	@RequestMapping("user_to_group")
	
	public String showAddUserToGroup(){
		logger.debug("Entering showAddUserToGroup()");
		Group g=new Group();
		User u=new User();
		gService.addUserToGroup(g, u);
		logger.debug("Exiting showAddUserToGroup()");
		return "done";
	}
}
