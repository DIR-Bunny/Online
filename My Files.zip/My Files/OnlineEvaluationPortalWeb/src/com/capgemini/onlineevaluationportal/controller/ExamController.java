package com.capgemini.onlineevaluationportal.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.onlineevaluationportal.entity.ExamSchedule;
import com.capgemini.onlineevaluationportal.pojo.ExamSchedulePojo;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;
import com.capgemini.onlineevaluationportal.pojo.UserAnswerPojo;
import com.capgemini.onlineevaluationportal.service.ConstantStrings;
import com.capgemini.onlineevaluationportal.service.ExamService;
import com.capgemini.onlineevaluationportal.service.QuestionPaperService;

@Controller
@RequestMapping("/exam")
public class ExamController {
	private static Logger logger = Logger.getLogger(ExamController.class);
	
	@Autowired
	public ExamService examService;
	
	@Autowired
	public QuestionPaperService qpaperService;
	
	@RequestMapping("/create_exam")
	public String createExamSchedule(){
		logger.debug("Entering createExamSchedule()");
		
		int id = examService.createExamSchedule(new ExamSchedule());
		//System.out.println("exam schudule id :"+id);
		logger.debug("Exiting createExamSchedule()");
		return "done";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/load-exam/{qpaperId}")
	public ModelAndView takeTest(@PathVariable int qpaperId, Model map, HttpSession session){
		logger.debug("Entering takeTest(examId,map,session)");
		
		/*HashMap<Integer, Integer> quesIdMap = qpaperService.loadPaper(qpId);
		session.setAttribute("totalQuestions",quesIdMap.size());
		session.setAttribute("quesIdMap", quesIdMap);
		session.setAttribute("questionPaperId", qpId);
		session.setAttribute("questionpaperTitle", qpaperService.getQuestionPaperTitle(qpId));
		HashMap<String, String> userAnswerMap = new HashMap<String, String>();
		session.setAttribute("userAnswerMap", userAnswerMap); 
		
		//load list of useranspojo in session //in qcon add a pojo to list
		List<UserAnswerPojo> userAnswers = new ArrayList<UserAnswerPojo>();
		session.setAttribute("userAnswers", userAnswers);*/
		System.err.println("in exam cont");
		List<ExamSchedulePojo> exams = (List<ExamSchedulePojo>) session.getAttribute("exams");
		System.err.println("exams list :"+exams);
		ExamSchedulePojo exam = new ExamSchedulePojo();
		for(ExamSchedulePojo e : exams){
			if(qpaperId == e.getQuestionPaperId() ){
				exam = new ExamSchedulePojo(e.examScheduleId,e.getQuestionPaperId(), e.getQuestionPaperTitle(), e.getExamStatus(), e.getTargetDate(), e.getCompletedDate(), e.getScore(),e.getPassing_percentage(), e.getDuration_time(),e.getQuestionPaperDescription());
				//exam = new ExamSchedulePojo(e.examScheduleId, e.getExamStatus(), e.getTargetDate(), e.getCompletedDate(), e.getScore(),e.getPassing_percentage(), e.getDuration_time(), e.getQpGroupId(), e.getQpGroupTitle(), e.getQpapers());
				//System.err.println("exam con :"+exam);
			}	
		}
		
		map.addAttribute(ConstantStrings.QUESTION_PAPER_TITLE, qpaperService.getQuestionPaperTitle(exam.getQuestionPaperId()));
		session.setAttribute(ConstantStrings.CURRENT_EXAM, exam);
		List<QuestionDetails> qlist = qpaperService.getAllQuestions(exam.questionPaperId);
		session.setAttribute(ConstantStrings.QUESTION_LIST, qlist);
		session.setAttribute(ConstantStrings.TOTAL_QUESTIONS_COUNT, qlist.size());
		
		logger.debug("Exiting takeTest(examId,map,session)");
		return new ModelAndView("TakeTest");
	}
	
	@RequestMapping("/check-over-due")
	public String updateOverDueExams(){
		
		examService.updateOverDueExams(); 
		return "done";
	} 
}
