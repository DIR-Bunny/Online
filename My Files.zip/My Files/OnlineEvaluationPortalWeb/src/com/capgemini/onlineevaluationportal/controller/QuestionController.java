package com.capgemini.onlineevaluationportal.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringArrayPropertyEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.pojo.QuestionDetails;
import com.capgemini.onlineevaluationportal.pojo.UserAnswerPojo;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;
import com.capgemini.onlineevaluationportal.service.ConstantStrings;
import com.capgemini.onlineevaluationportal.service.LoginService;
import com.capgemini.onlineevaluationportal.service.QuestionPaperService;
import com.capgemini.onlineevaluationportal.service.QuestionService;
import com.capgemini.onlineevaluationportal.service.UserAnswerService;

@Controller
@RequestMapping("/question")
public class QuestionController {
	
	@Autowired
	private LoginService loginService;
	@Autowired
	public QuestionService qService;
	@Autowired
	public QuestionPaperService qpaperService;
	@Autowired
	public UserAnswerService userAnswerService;
	
	private static Logger logger = Logger.getLogger(QuestionController.class);
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		logger.debug("Entering initBinder(binder)");
		logger.debug("Exiting initBinder(binder)");
	    binder.registerCustomEditor(String[].class, new StringArrayPropertyEditor(null));
	}
	
	@RequestMapping("/question_page")
	public String showTemp(){
		logger.debug("Entering showTemp()");
		logger.debug("Exiting showTemp()");
		return "QuestionPage";
	}
	
	@RequestMapping("/add_question")
	public String showAddQuestion(){
		logger.debug("Entering showAddQuestion()");
		Question q = new Question();
		qService.addQuestion(q);
		logger.debug("Exiting showAddQuestion()");
		return "done";
	}
	
	@RequestMapping("/delete_question")
	public String deleteQuestion(){
		logger.debug("Entering deleteQuestion()");
		int id=4;
		qService.deleteQuestion(id);
		logger.debug("Exiting deleteQuestion()");
		return "done";
	}
		
	@SuppressWarnings("unchecked")
	@RequestMapping("/next-question")
	public String getNextQuestion(Model map, HttpSession session){
		logger.debug("Entering getNextQuestion(map,session)");
		int index = 0;
		int qpId = (int) session.getAttribute("questionPaperId");
		QuestionDetails nextQuestion = qService.getNextQuestion(qpId, 0);
		//System.out.println("Next Ques :"+nextQuestion);
		map.addAttribute("nextQuestion", nextQuestion);
		
		HashMap<Integer,Integer> quesIdMap = (HashMap<Integer, Integer>) session.getAttribute("quesIdMap");
		for(Map.Entry<Integer, Integer> entry : quesIdMap.entrySet()){
			if(entry.getValue() == nextQuestion.getQuestionId()){
				index = entry.getKey();
			}
		}
		map.addAttribute("index", index);
		logger.debug("Exiting getNextQuestion(map,session)");
		return "QuestionPage";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/question-by-id/{qId}")
	public String getQuestionById(@PathVariable int qId, HttpSession session, Model map){
		logger.debug("Entering getQuestionById(session,map)");
		int index=0;
		int qpId = (int) session.getAttribute("questionPaperId");
		QuestionDetails quesDetails = qService.getQuestionById(qpId, qId);
		//System.out.println("in q con : "+quesDetails);
		map.addAttribute("nextQuestion", quesDetails);
		HashMap<Integer,Integer> quesIdMap = (HashMap<Integer, Integer>) session.getAttribute("quesIdMap");
		
		for(Map.Entry<Integer, Integer> entry : quesIdMap.entrySet()){
			if(entry.getValue() == qId){
				index = entry.getKey();
			}
		}
		map.addAttribute("index", index);
		logger.debug("Exiting getQuestionById(session,map)");
		return "QP";
	}
		
	@SuppressWarnings("unchecked")
	@RequestMapping("/current-exam")
	public String processQuestion(@RequestParam(value="submitValue") String value, 
									@RequestParam(required=false, value="userAnswer") Integer optionId, 
										@RequestParam(value="quesId") Integer quesId, HttpSession session)
	{	
		logger.debug("Entering processQuestion(value,optionId,quesId,session)");
		int index = 0; 
		
		UserPojo user=(UserPojo) session.getAttribute("session_user");
		List<UserAnswerPojo> userAnswers = (List<UserAnswerPojo>) session.getAttribute("userAnswers");
		
	//	QuestionDetailsPojo questiondetails = qService.getNextQuestionById((Integer)session.getAttribute("questionPaperId"), quesId);
		if(optionId != null){
			if(userAnswers.contains(new UserAnswerPojo(quesId))){
			//	userAnswers.set(userAnswers.indexOf(new UserAnswerPojo(quesId)), new UserAnswerPojo(user.getUserId(), quesId, optionId));
			}else{
				//userAnswers.add(new UserAnswerPojo(user.getUserId(), quesId, optionId));	
			}	
			session.setAttribute("userAnswers", userAnswers);
		}
				
		HashMap<Integer,Integer> quesIdMap = (HashMap<Integer, Integer>) session.getAttribute("quesIdMap");
		for(Map.Entry<Integer, Integer> entry : quesIdMap.entrySet()){
			if(entry.getValue() == quesId){
				index = entry.getKey();
			}
		}
		
		if(value.equals("PREVIOUS")){
			int questionId = quesIdMap.get(index - 1);
			return "forward:/question/question-by-id/"+questionId+"";
		}else if( value.equals("NEXT") ){
			int questionId = quesIdMap.get(index + 1);
			return "forward:/question/question-by-id/"+questionId+"";
		}else if( value.equals("SUBMIT TEST") ){
			System.out.println("User ans :"+userAnswers);
			System.out.println("submit");
		}
		logger.debug("Exiting processQuestion(value,optionId,quesId,session)");
		return "done";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/take-exam/{quesId}", method= RequestMethod.POST)
	public String getQuestion(@PathVariable int quesId ,
			@RequestParam(value="submitValue", required=false) String submitValue, 
			@RequestParam(value="answers[]", required=false) String[] answers,
			@RequestParam(value="requiredIndex", required=false)Integer requiredIndex ,
			Model map, HttpSession session)
	{
		logger.debug("Entering getQuestion(quesId,submitValue,answers,requiredIndex)");
		System.err.println("Ans in Controller "+answers);
		//System.err.println("Ans in Controller  Size "+answers.size());
		QuestionDetails currentQuestion = null;
		List<QuestionDetails> questionList = (List<QuestionDetails>) session.getAttribute(ConstantStrings.QUESTION_LIST);
		int index = questionList.indexOf(new QuestionDetails(quesId));
		if(index > -1)
		{
			questionList.get(index).setAnswers(answers);
		}
		if(submitValue == null){
			submitValue = "";
		}
		if(submitValue.equalsIgnoreCase("TAKE TEST") || submitValue.equalsIgnoreCase("NEXT")){
			int current_index = index + 1;
			currentQuestion= questionList.get(current_index);
			map.addAttribute(ConstantStrings.QUESTION_NUMBER, (current_index+1));
			map.addAttribute(currentQuestion);
			map.addAttribute(ConstantStrings.CURRENT_QUESTION, currentQuestion);
		}
		else if(submitValue.equalsIgnoreCase("PREVIOUS")){
			int current_index = index - 1;
			currentQuestion= questionList.get(current_index);
			map.addAttribute(ConstantStrings.QUESTION_NUMBER, (current_index + 1));		
			map.addAttribute(currentQuestion);
			map.addAttribute(ConstantStrings.CURRENT_QUESTION, currentQuestion);
		}
		else if(submitValue.equalsIgnoreCase("SUBMIT TEST"))
		{
			
			/*Handel null pointer exception for no anwers in list*/
			UserPojo user = getPrincipal();
			List<UserAnswerPojo> userAnswers = new ArrayList<UserAnswerPojo>();
			for(QuestionDetails ques : questionList)
			{
				if(ques.getAnswers() == null)
				{
					userAnswers.add(new UserAnswerPojo(user.getUserId(), ques.getQuestionId(), "", ques.getQuestionpaperId())); 
				}else{
					String temp = "";
					int i =0;
					for(String ans : ques.getAnswers())
					{
						/*if(i == ques.getAnswers().size())
						 	temp += ans;	
						else
							temp += ans+",";*/
						userAnswers.add(new UserAnswerPojo(user.getUserId(), ques.getQuestionId(), ans, ques.getQuestionpaperId()));
					}
					//userAnswers.add(new UserAnswerPojo(user.getUserId(), ques.getQuestionId(), temp, ques.getQuestionpaperId()));
					System.err.println("In controller 2 "+userAnswers);
				}
			}
			
			userAnswerService.processExamSubmission(userAnswers);
			System.out.println("Finished Test");
			logger.debug("Exiting getQuestion(quesId,submitValue,answers,requiredIndex)");
			return "forward:/user/assessment";
		}
		else if(requiredIndex != 0)
		{
			System.out.println("required index :"+requiredIndex);
			//int current_index = index + 1;
			currentQuestion= questionList.get(requiredIndex-1);
			map.addAttribute(ConstantStrings.QUESTION_NUMBER, (requiredIndex));
			map.addAttribute(currentQuestion);
			map.addAttribute(ConstantStrings.CURRENT_QUESTION, currentQuestion);
		}
		logger.debug("Exiting getQuestion(quesId,submitValue,answers,requiredIndex)");
		return "QP";
	}
	
	private UserPojo getPrincipal()
	 {
		logger.debug("Entering getPrincipal()");
	 	UserPojo user = null;
       String userName = null;
       Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
       
	       if (principal instanceof UserDetails) 
	        {
	            userName = ((UserDetails)principal).getUsername();
	            System.out.println("Loged in user "+userName);
	            user =  loginService.getUserDetailsByUsername(userName);
	        } else 
	        {
	            userName = principal.toString();
	            user =  loginService.getUserDetailsByUsername(userName);
	        }
	   	logger.debug("Exiting getPrincipal()");
	        return user;
	  }
	
	@RequestMapping("/get-all-questions/{qpId}")
	
	public String getQuestionsInQuestionPaper(@PathVariable int qpId, Model map){
		logger.debug("Entering getQuestionsInQuestionPaper(qpId,map)");
		List<QuestionDetails> questionDetailsList = qService.getQuestionsFromQuestionPaper(qpId);
		map.addAttribute("question_list", questionDetailsList);
		logger.debug("Exiting getQuestionsInQuestionPaper(qpId,map)");
		return "allQuestions";
	}
}
