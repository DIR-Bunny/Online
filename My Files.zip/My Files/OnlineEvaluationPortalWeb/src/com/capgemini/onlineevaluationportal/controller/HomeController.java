package com.capgemini.onlineevaluationportal.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.onlineevaluationportal.dao.UserDaoImpl;
import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionAnswer;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.entity.QuestionType;
import com.capgemini.onlineevaluationportal.entity.Questionlevel;
import com.capgemini.onlineevaluationportal.pojo.UploadQuestionPojo;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;
import com.capgemini.onlineevaluationportal.service.DashboardService;
import com.capgemini.onlineevaluationportal.service.LoginService;
import com.google.api.client.repackaged.com.google.common.base.Function;

@Controller
public class HomeController 
{
	private static Logger logger = Logger.getLogger(HomeController.class);
	@Autowired
	private UserDaoImpl dao;
	
	@Autowired
	public LoginService loginService;	
	@Autowired
	public DashboardService dashboardService;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = "error", required = false) String error, @RequestParam(value = "logout", required = false) String logout, HttpServletRequest request) 
	{
		logger.debug("Entering login(error,logout,request)");
		ModelAndView model = new ModelAndView();
		if (error != null) 
		{
			model.addObject("error", getErrorMessage(request, "SPRING_SECURITY_LAST_EXCEPTION"));
		}

		if (logout != null)
		{
			model.addObject("msg", "You've been logged out successfully.");
		}
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		if (!(auth instanceof AnonymousAuthenticationToken)) 
		{
			Collection<? extends GrantedAuthority> list =  auth.getAuthorities();
			for (GrantedAuthority grantedAuthority : list) 
			{
				//System.err.println("In Home Controller authorities " +grantedAuthority.getAuthority());
				if(grantedAuthority.getAuthority().equals("ROLE_USER"))
					return new ModelAndView("forward:/user/assessment");
				else
					model.setViewName("forward:/Admin/Dashboard");
			}
		}
		else
		{
			System.err.println("login page");
			model.setViewName("Login");
			
		}
		logger.debug("Exiting login(error,logout,request)");
		return model;

	}
/*	@RequestMapping(value = "/Upload")
	public ModelAndView Upload() 
	{

		System.out.println("Upload page");
		return new ModelAndView("Upload");

	}*/
	private String getErrorMessage(HttpServletRequest request, String key) {
		logger.debug("Entering getErrorMessage(request,logout,key)");

		Exception exception = (Exception) request.getSession().getAttribute(key);

		String error = "";
		if (exception instanceof BadCredentialsException) {
			error = "Invalid username or password!";
		} else if (exception instanceof LockedException) {
			error = exception.getMessage();
		} else {
			error = "Invalid username or password!";
		}
		logger.debug("Exiting getErrorMessage(request,logout,key)");
		return error;
	}

	// for 403 access denied page
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied() {
		logger.debug("Entering accesssDenied()");

		ModelAndView model = new ModelAndView();

		// check if user is login
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken))
		{
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			System.out.println(userDetail);

			model.addObject("username", userDetail.getUsername());
			

		}

		model.setViewName("403");
		logger.debug("Exiting accesssDenied()");

		return model;
	
	}
	
	 private UserPojo getPrincipal()
	 {
		logger.debug("Entering getPrincipal()");

	 	UserPojo user = null;
        String userName = null;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
	       if (principal instanceof UserDetails) 
	        {
	            userName = ((UserDetails)principal).getUsername();
	            System.out.println("Loged in user "+userName);
	            user =  loginService.getUserDetailsByUsername(userName);
	        } else 
	        {
	            userName = principal.toString();
	            user =  loginService.getUserDetailsByUsername(userName);
	        }
	       logger.debug("Exiting getPrincipal()");
	        return user;
	  }
	 
	 //remaining all common methods
	 @RequestMapping("setting")
	 public String setting(){
		 
		 return "setting";
	 }
	 
	 @RequestMapping("contact-us")
	 public String showContactUs(){
		 
		 return "contactUs";
	 }
	 
	 @RequestMapping("FAQ")
	 public String showFAQs()
	 {
		 
		 return "FAQ";
	 }
	 	 
	
	 }
