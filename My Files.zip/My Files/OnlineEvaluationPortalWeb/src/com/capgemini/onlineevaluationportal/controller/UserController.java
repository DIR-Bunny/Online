package com.capgemini.onlineevaluationportal.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.onlineevaluationportal.pojo.ExamSchedulePojo;
import com.capgemini.onlineevaluationportal.pojo.UserPojo;
import com.capgemini.onlineevaluationportal.service.ConstantStrings;
import com.capgemini.onlineevaluationportal.service.DashboardService;
import com.capgemini.onlineevaluationportal.service.LoginService;

@Controller
@RequestMapping("/user")
public class UserController {
	private static Logger logger = Logger.getLogger(UserController.class);
	@Autowired
	public LoginService loginService;	
	@Autowired
	public DashboardService dashboardService;
	
	/*@RequestMapping("/login")
	public ModelAndView showLoginForm()
	{
		logger.debug("Entering showLoginForm()");
		logger.debug("Exiting showLoginForm()");
		return new ModelAndView("Login","command",new UserPojo());
	
	}*/
	
	/*@RequestMapping(value="/process-login", method=RequestMethod.POST)
	public ModelAndView processLoginForm(HttpSession hs, Model map, UserPojo user){
		
		String userid=loginService.authenticateUser(user);
		System.out.println(userid);
		if(userid != null){
			user=loginService.getUserDetailsById(userid);
			hs.setAttribute(ConstantStrings.SESSION_USER , user);
			return new ModelAndView("forward:/user/assessment");
		}else{
			map.addAttribute(ConstantStrings.INVALID_USER);
			return new ModelAndView("redirect:/user/user-login");
		}	
	}
	*/
	@RequestMapping("/assessment")
	public String userExamSchedules(HttpSession session, Model map){
		logger.debug("Entering userExamSchedules(session,map)");
		
		UserPojo user=getPrincipal();
		List<ExamSchedulePojo> exams = dashboardService.getUserExamSchedule(user);
		//map.addAttribute("exams", exams);
		session.setAttribute("exams", exams);
		map.addAttribute(ConstantStrings.COUNT_TOTAL_ASSESSMENT, exams.size());
		map.addAttribute(ConstantStrings.COUNT_COMPLETED, dashboardService.countCompletedAssessments(exams));
		map.addAttribute(ConstantStrings.COUNT_PENDING, dashboardService.countPendingAssessments(exams));
		logger.debug("Exiting userExamSchedules(session,map)");
		return "Assessment";
	}
	
	 private UserPojo getPrincipal()
	 {
		 logger.debug("Entering getPrincipal()");
	 	UserPojo user = null;
        String userName = null;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        
	       if (principal instanceof UserDetails) 
	        {
	            userName = ((UserDetails)principal).getUsername();
	            System.out.println("Loged in user "+userName);
	            user =  loginService.getUserDetailsByUsername(userName);
	        } else 
	        {
	            userName = principal.toString();
	            user =  loginService.getUserDetailsByUsername(userName);
	        }
	       logger.debug("Exiting getPrincipal()");
	        return user;
	  }
}
