package com.capgemini.onlineevaluationportal.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.servlet.ModelAndView;


import com.capgemini.onlineevaluationportal.entity.Question;
import com.capgemini.onlineevaluationportal.entity.QuestionOption;
import com.capgemini.onlineevaluationportal.service.QuestionOptionService;
import com.capgemini.onlineevaluationportal.service.QuestionOptionServiceImpl;


@Controller
public class QuestionOptionController {
	private static Logger logger = Logger.getLogger(QuestionOptionController.class);
	@Autowired
	private QuestionOptionService serviceInterface;

	@RequestMapping("add_option")
	public ModelAndView addOption(){
		logger.debug("Entering addOption()");
		/*Date d=new Date();
		System.out.println("in controller");
		Question question=new Question(83);
		question.setQuestionId(83);
		List<Question> questions=new ArrayList<Question>();
		questions.add(question);
		
		QuestionOption option=new QuestionOption(25, "saurabh", d, "java is not object oriented", "ikea", d, questions);
		QuestionOption option2=new QuestionOption(26, "saurabh1", d, "cpp is not object oriented", "ikea", d, questions);
		QuestionOption option3=new QuestionOption(27, "saurabh12", d, "cpp and java are object oriented", "ikea", d, questions);
		serviceInterface.addOption(option);
		serviceInterface.addOption(option2);
		serviceInterface.addOption(option3);
		List<QuestionOption> questionOption=new ArrayList<QuestionOption>();
		questionOption.add(option);
		questionOption.add(option2);
		questionOption.add(option3);
		question.setQuestionOptions(questionOption);
		
		return new ModelAndView("option1");*/
		
		
		/*QuestionOption option=new QuestionOption();
		serviceInterface.addOptionToQs(option);*/
		Date d=new Date();
		QuestionOption option=new QuestionOption("saurabh", d, "DispatcherServlet is used for AOP.", "ikea", d);
		
		serviceInterface.addOption(option);
		logger.debug("Exiting addOption()");
		return new ModelAndView("done");
		
	}
	
	@RequestMapping("delete_option")
	public ModelAndView deleteOption(){
		logger.debug("Entering deleteOption()");
		
		System.out.println("in controller");
		serviceInterface.deleteOption(1);
		logger.debug("Exiting deleteOption()");
		return new ModelAndView("option1");
		
	}
	
	@RequestMapping("all_option")
	public ModelAndView allOption(){
		logger.debug("Entering allOption()");
		
		System.out.println("in controller");
		List<QuestionOption> list=serviceInterface.getAllOptions();
		logger.debug("Exiting allOption()");
		return new ModelAndView("option1","list",list);
		
	}
	
	@RequestMapping("option_by_qs_id")
	public ModelAndView byQsId()
	
	{
		logger.debug("Entering byQsId()");
		List<QuestionOption> list=serviceInterface.getOptionByQs(2);
		logger.debug("Exiting byQsId()");
		return new ModelAndView("option1","list",list);
		
	}
	
}
