/**
 * 
 */
function QuestionAjax(submitVal,requiredIndex) 
{
		//alert("Called Happy");
		var questionId = $('#questionId').val();
//		/var submitValue = $(this).val();
		if(submitVal != null)
			var submitValue = submitVal
		else
			var submitValue = $( "input[type=button][name=submitValue]").val();
		
		
		var requiredInd = (requiredIndex !=null) ? requiredIndex : -1;
		//alert(requiredInd);
		
		//submitValue = (requiredInd >= 0 )? "": submitValue;
		
		//var requiredIndex = $( "input[type=button][name=requiredIndex]").val();
		console.log("Requred Index "+requiredIndex);
		var CheckedAns = $( "input[type=checkbox][name=answers]:checked" ).val();
		var RadioCheckedAns = $( "input[type=radio][name=answers]:checked" ).val();
		var TextAreaAns =  $('#TextAns').val();
		
		
		//var answers
		/*
		if($('input[type=radio][name=answers]').is(':checked'))
		{
			alert("Inside "+RadioCheckedAns);
			var answers = RadioCheckedAns;
		}
		else
		{
			var answers = "NA";
		}
		if($('input[type=checkbox][name=answers]').is(':checked'))
		{
			//alert("Inside");
			var answers = RadioCheckedAns;
		}
		else
		{
			var answers = "NA";
		}*/
		if(RadioCheckedAns != null)
		{
			var answers = [];
			answers.push(RadioCheckedAns);
		}
		else if (CheckedAns != null) 
		{
			var answers = [];
			$('input[type=checkbox][name=answers]:checked').each(function() 
			{
				//alert($(this).val());
				answers.push($(this).val());
		     });
		} 
		else if(TextAreaAns != null) 
		{
			//alert("Text area "+TextAreaAns);
			var answers = [];
			answers.push(TextAreaAns);
			//var answers = TextAreaAns;
		}
		else
		{
			var answers = [];
			//answers.push("NA");
		}
		
		console.log(questionId +" "+ submitValue +" "+ answers );
		
		$.getJSON($("#ctx").val()+"/ajax/take-exam-ajax",
				{questionId : questionId,submitValue : submitValue, answers : answers,requiredIndex : requiredInd},
				
				function(Data) 
				{
					
					if( Data.currentQuestion != null )
					{
						//alert("Attemoted "+ Data.attemptedQuestionCount);
						var Attempted = Data.attemptedQuestionCount;
						var TotalQue = Data.totalQuestionsCount;
						var FrmGroupDiv = document.createElement("div");
						FrmGroupDiv.setAttribute('class','form-group');
						var FrmGroupDiv = '<div class="form-group"><label style="font-weight: normal !important;">';
						var FrmGroupDiv = '<div class="form-group" ><label style="font-weight: normal !important; ">';
						var InputRadio = '<input type="radio" name="answers" value="${option.optionText}"/>&nbsp;&nbsp;${option.optionText}</label>';
					   var DivEnd = '</div>';
																	
						var heading = $('#HeadingQuestions').text('');
						heading.append("Question : "+ Data.questionNumber +" of "+ Data.totalQuestionsCount +"");
						
						var NavigationDiv = $('#NavigationDiv').text('');
						var QuestionOptionDiv = $('#QuestionOptionDiv').text('');
						QuestionOptionDiv.append('<input type="hidden" id="questionId" value="'+ Data.currentQuestion.questionId +'">');	
						QuestionOptionDiv.append("<p><b>Q "+ Data.questionNumber+".&nbsp;"+ Data.currentQuestion.questionDescription +"</b></p>");
						QuestionOptionDiv.append('<input type="hidden" id="questionId" value="'+ Data.currentQuestion.questionId +'">');	
						QuestionOptionDiv.append("<p><b style='margin-left: 25px;'>Q "+ Data.questionNumber+".&nbsp; "+ Data.currentQuestion.questionDescription +"</b></p>");
						
						var input = document.createElement("input");
						input.setAttribute('id','questionId');
						input.setAttribute('type','hidden');
						input.setAttribute('checked','checked');
						input.setAttribute('value',Data.currentQuestion.questionId);
						QuestionOptionDiv.append(input);
						//QuestionOptionDiv.append('<input type="hidden" id="questionId" value="'+ Data.currentQuestion.questionId +'">');
						
						var pTag = document.createElement("p");
						var bTag = document.createElement("b");
						//var blank = document.createElement("\u0020");
						var QuestionNumber = document.createTextNode(Data.questionNumber+" ");
						var questionDescription = document.createTextNode(Data.currentQuestion.questionDescription);
						
						bTag.append(QuestionNumber);
						bTag.append(questionDescription);
						pTag.append(bTag);
						
						QuestionOptionDiv.append(pTag);
						
						
						//QuestionOptionDiv.append("<p><b>Q "+ Data.questionNumber+".&nbsp;"+ Data.currentQuestion.questionDescription +"</b></p>");
						
						if(Data.currentQuestion.typeName == "MCQ")
						{	
							console.log("MCQ");
							QuestionOptionDiv.append(FrmGroupDiv);
							//alert(Data.currentQuestion.answers);
							for (var i = 0; i < Data.currentQuestion.optionList.length; i++) 
							{
								
								//console.log(Data.currentQuestion.optionList[i].optionText);
								if(Data.currentQuestion.answers != null)
								{
									
										//alert(Data.currentQuestion.answers[0]+"   \n"+ Data.currentQuestion.optionList[i].optionText);
										if(Data.currentQuestion.answers[0] == Data.currentQuestion.optionList[i].optionText)
										{
											//alert("Inside "+Data.currentQuestion.answers[0]+"   \n"+ Data.currentQuestion.optionList[i].optionText);
											
											/*var label = document.createElement("label");
											label.setAttribute('class','fa fa-eye');
											label.setAttribute('class','fa fa-eye');
											var style = document.createElement("STYLE");
										    var StyleAtt1 = document.createTextNode("body {font: 20px verdana;}");
										    x.appendChild(t);
										    document.head.appendChild(x);*/
											/*var br =document.createElement("br");
											var input = document.createElement("input");
											input.setAttribute('name','answers');
											input.setAttribute('type','radio');
											input.setAttribute('checked','checked');
											input.setAttribute('value',Data.currentQuestion.optionList[i].optionText);
											var optionText = document.createTextNode("   "+Data.currentQuestion.optionList[i].optionText);
											
											
											QuestionOptionDiv.append('<label style="font-weight: normal !important;">');
											
											QuestionOptionDiv.append(input);
											QuestionOptionDiv.append(optionText);
											QuestionOptionDiv.append('</label>');
											QuestionOptionDiv.append(br);*/
											QuestionOptionDiv.append('<label style="font-weight: normal !important;"><input checked type="radio" name="answers" value="'+ Data.currentQuestion.optionList[i].optionText +'"/>&nbsp;&nbsp;'+ Data.currentQuestion.optionList[i].optionText +'</label><br/>');
											QuestionOptionDiv.append('<label style="font-weight: normal !important;"><input checked type="radio" name="answers" value="'+ Data.currentQuestion.optionList[i].optionText +'"/>&nbsp;&nbsp;'+ Data.currentQuestion.optionList[i].optionText +'</label><br/>');
											QuestionOptionDiv.append('<label style="margin-left: 20px; font-weight: normal !important;"><input checked type="radio" name="answers" value="'+ Data.currentQuestion.optionList[i].optionText +'"/>&nbsp;&nbsp;'+ Data.currentQuestion.optionList[i].optionText +'</label><br/>');

										}
										else
											QuestionOptionDiv.append('<label style="margin-left: 20px; font-weight: normal !important;"><input type="radio" name="answers" value="'+ Data.currentQuestion.optionList[i].optionText +'"/>&nbsp;&nbsp;'+ Data.currentQuestion.optionList[i].optionText +'</label><br/>');
									
								}
								else
								{
									QuestionOptionDiv.append('<label style="margin-left: 20px; font-weight: normal !important;"><input type="radio" name="answers" value="'+ Data.currentQuestion.optionList[i].optionText +'"/>&nbsp;&nbsp;'+ Data.currentQuestion.optionList[i].optionText +'</label><br/>');
								}
								
							}
							
							//QuestionOptionDiv.append(DivEnd);
						}
						else if (Data.currentQuestion.typeName == "MULTIPLES") 
						{
							console.log("MULTIPLES");
							var actual = [];
							var Selected = [];
							var temp = [];
							QuestionOptionDiv.append(FrmGroupDiv);
							for (var i = 0; i < Data.currentQuestion.optionList.length; i++) 
							{
								if(Data.currentQuestion.answers != null)
								{
									for (var j = 0; j < Data.currentQuestion.answers.length; j++) 
									{
										if(Data.currentQuestion.answers[j] == Data.currentQuestion.optionList[i].optionText)
										{
											//alert("Selected ans : "+ j +" "+i);
											Selected.push(i);
										}
									}	
								}
								actual.push(i);
							}
							
							$.each(actual , function(i,e) 
							{
							    if ($.inArray(e  , Selected ) == -1) 
							    	temp.push(e);
							});
//							/var j = 0;
							for (var i = 0, j = 0; i < actual.length; i++) 
							{
								var item = actual[i];
								
								if(item == Selected[j])
								{
									QuestionOptionDiv.append('<label style="margin-left:20px; font-weight: normal !important;"><input checked type="checkbox" name="answers" value="'+Data.currentQuestion.optionList[Selected[j]].optionText+'"/>&nbsp;&nbsp;'+Data.currentQuestion.optionList[Selected[j]].optionText+'</label><br/>');
									j++;
								}
								else
								{
									QuestionOptionDiv.append('<label style="margin-left:20px; font-weight: normal !important;"><input type="checkbox" name="answers" value="'+Data.currentQuestion.optionList[item].optionText+'"/>&nbsp;&nbsp;'+Data.currentQuestion.optionList[item].optionText+'</label><br/>');
								}		
							}
							//QuestionOptionDiv.append(DivEnd);
						}
						else if (Data.currentQuestion.typeName == "DESCRIPTIVE") 
						{
							console.log("DESCRIPTIVE");
							QuestionOptionDiv.append(FrmGroupDiv);
							var textarea = document.createElement("textarea");
							textarea.setAttribute('name','answers');
							textarea.setAttribute('id','TextAns');
							textarea.setAttribute('class','form-control classy-editor well');
							textarea.setAttribute('rows','6');
							QuestionOptionDiv.append(textarea);
							//alert(textarea);
							
							//QuestionOptionDiv.append('<textarea id="TextAns" name="answers" class="form-control classy-editor" rows="6"/>');
							if(Data.currentQuestion.answers != null)
							{
								$("textarea#TextAns").addClass("collapse");
								//alert(Data.currentQuestion.answers[0]);
								QuestionOptionDiv.append("<div style='height:160px;' class='well table-responsive TextAnsDiv'>"+Data.currentQuestion.answers[0]+"</div>");
								$("textarea#TextAns").html(Data.currentQuestion.answers[0]);
//								/$('#TextAns').text(Data.currentQuestion.answers[0]);
							}
							//QuestionOptionDiv.append(DivEnd);
						}
						
						//nav button div
						/*var navButtonDiv = '<div class="row" style="background: white; margin-bottom: 10px; color: black; padding: 20px;">';
						var navButtonDivEnd = '</div>';*/
						
						
						
						if(Data.questionNumber > 1)
						{
							console.log("Previous button");
							NavigationDiv.append('<input type="button" value="PREVIOUS" name="submitValue" class="btn btn-warning PrevButton">'); 	
							NavigationDiv.append(' &nbsp;');
						}
						if((Data.questionNumber != Data.totalQuestionsCount) && ( Data.questionNumber <= 1 ) )
						{
							console.log("Fiest Next Button");
							NavigationDiv.append(' <div class="row" id="FirstNextButton">'+
									'<div class="col-sm-5"></div>'+
									'<input type="button" value="NEXT" name="submitValue" data-target="#myModal" class="btn btn-success NextButton" style="width: 100px;" ></div>');
						}
						else if(Data.questionNumber != Data.totalQuestionsCount)
						{
							console.log("Next button");
							console.log(Data.questionNumber);
							NavigationDiv.append('<input type="button" value="NEXT" name="submitValue" data-target="#myModal" class="btn btn-success NextButton" style="width: 100px;" ">');						
						}
						if(Data.questionNumber == Data.totalQuestionsCount)
						{
							console.log("Submit test");
							NavigationDiv.append('<input type="button" value="SUBMIT TEST" name="submitValue" class="btn btn-success submitTest">');
						}
						
						//alert("Status "+ Data);
						//////////////////////////////////////////Progress bar
						var percentage = parseInt((Attempted / TotalQue)*100);
						 $('.progress-bar').css('width', percentage+'%');
						 $('.progress-bar').text(percentage+'%');
						//45% Complete
					
					}
					else
					{
						//console.log("I am here");
						$('#myModal').modal('show'); 
					}
				}
				
			);
	}

$("document").ready(function()
{
	$.getJSON($("#ctx").val()+"ajax/get-attempted-ajax",
	function(Data) 
	{
		///alert("Total "+Data.totalQuestions+"  attemptes "+Data.attemptedQues);
		var percentage =   parseInt((Data.attemptedQues / Data.totalQuestions)*100);
		 $('.progress-bar').css('width', percentage+'%');
		 $('.progress-bar').text(percentage+'%');
	});
	
	var tNeeded = parseInt( $("#examTime").val());
	console.log("Time needed "+ tNeeded);
	var add = tNeeded;
	var dt = new Date();
	
	var hr = parseInt(dt.getHours());
	var sec = parseInt(dt.getSeconds());
	var minutes = parseInt(dt.getMinutes());
	hr = hr % 12;
	hr = hr ? hr : 12; // the hour '0' should be '12'
	var time =  hr + ":" + minutes+ ":" + sec;
	
	//alert(time);
	
	while(add > 0)
	{
		if(add >= 60)
		{
			//alert("ge");
			hr = (hr + 1);
			
			add = add - 60;	
		}
		if(add < 60)
		{
			//alert("le");
			minutes =  minutes + add;
			temp = add;
			add = add - temp;
		}
	}
	var t =  hr + ":" + minutes+ ":" + sec;
	console.log("After adding needed "+ t);
	var Estimate = new Date();
	Estimate.setHours(hr);
	Estimate.setMinutes(minutes);
	Estimate.setSeconds(sec);
	
	

	//alert(Estimate);
	
	
	var x = setInterval(function() 
	{
		var now = new Date();
		 hr = now.getHours();
		sec = now.getSeconds();
		minutes = now.getMinutes();
		hr = hr % 12;
		hr = hr ? hr : 12;
		now.setHours(hr);
		now.setMinutes(minutes);
		now.setSeconds(sec);
		
		var End = Estimate.getTime() - now.getTime();
		//alert("End "+Estimate.getTime() +"  --->   "+ now.getTime()+"     "+End);
		//console.log(End);
		
		var hours = Math.floor((End % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	    var minutes = Math.floor((End % (1000 * 60 * 60)) / (1000 * 60));
	    var seconds = Math.floor((End % (1000 * 60)) / 1000);
		
	 // Output the result in an element with id="demo"
	   document.getElementById("t").innerHTML =  hours + "h "
	    + minutes + "m " + seconds + "s "; 
	    
		if (End < 0) 
		{
	        clearInterval(x);
	      /* alert("Expired");
	       $('#FormSubmit').trigger('click');*/
	    }
	},1000);
	$( document ).on( "click", "#ClearPage", function(e) 
	{
		$('input[name="answers"]').prop('checked', false);
		//alert($('.html_editor').val());
		$('#TextAns').val('');
		$(".html_editor").val('');
		$(".TextAnsDiv").text('');
		$(".editor").text('');
		navSelector();
		$.getJSON($("#ctx").val()+"ajax/get-attempted-ajax",
		function(Data) 
		{
			var percentage =   (Data.attemptedQues > 0) ?  parseInt(( (Data.attemptedQues) / Data.totalQuestions)*100) : parseInt(( (Data.attemptedQues) / Data.totalQuestions)*100);
			 $('.progress-bar').css('width', percentage+'%');
			 $('.progress-bar').text(percentage+'%');
		});
		
	});
	
	$("#SkipPage").click(function()
	{
		console.log($(this).val());
		navSelector();
		QuestionAjax('NEXT');
	});
	
	$("#SaveAnswer").click(function()
	{
		console.log($(this).val());
		navSelector();
		QuestionAjax('SAVE');
	});
	
	$(".nav-btn").click(function()
	{
		/*var CheckedAns = $( "input[type=checkbox][name=answers]:checked" ).val();
		var RadioCheckedAns = $( "input[type=radio][name=answers]:checked" ).val();
		var TextAreaAns =  $('#TextAns').val();
		
		var arr = [];
		var text = $("#HeadingQuestions").text();
		arr = text.split(" ");
		if(RadioCheckedAns != null || ( CheckedAns != null) || (TextAreaAns != null && TextAreaAns != ""))
		{
			$("#"+arr[2]).removeClass("btn-basic");
			$("#"+arr[2]).addClass("btn-success");
		}*/
		navSelector();
		//console.log($(this).val());
		
		QuestionAjax("",$(this).val());
	});
	
	
	function navSelector() 
	{
		var CheckedAns = $( "input[type=checkbox][name=answers]:checked" ).val();
		var RadioCheckedAns = $( "input[type=radio][name=answers]:checked" ).val();
		var TextAreaAns =  $('#TextAns').val();
		
		var arr = [];
		var text = $("#HeadingQuestions").text();
		arr = text.split(" ");
		if(RadioCheckedAns != null || ( CheckedAns != null) || (TextAreaAns != null && TextAreaAns != ""))
		{
			$("#"+arr[2]).removeClass("btn-basic");
			$("#"+arr[2]).addClass("btn-success");
		}
		else
		{
			$("#"+arr[2]).removeClass("btn-success");
			$("#"+arr[2]).addClass("btn-basic");
		}
	}
	
	
		
	/*$( document ).on( "click", "input[name='answers'],textarea#TextAns", function(e) 
	{
		var CheckedAns = $( "input[type=checkbox][name=answers]:checked" ).val();
		var RadioCheckedAns = $( "input[type=radio][name=answers]:checked" ).val();
		//alert( RadioCheckedAns);
		if((RadioCheckedAns != null) || CheckedAns !=null) 
		{
			$.getJSON($("#ctx").val()+"ajax/get-attempted-ajax",
			function(Data) 
			{
				//alert("Total "+Data.totalQuestions+"  attemptes "+Data.attemptedQues);
				//var percentage =   (Data.attemptedQues > 0) ?  parseInt(( (Data.attemptedQues) / Data.totalQuestions)*100) : parseInt(( (++Data.attemptedQues) / Data.totalQuestions)*100);
				var percentage =   parseInt(( (++Data.attemptedQues) / Data.totalQuestions)*100);
				 $('.progress-bar').css('width', percentage+'%');
				 $('.progress-bar').text(percentage+'%'); 
			});
		}
		//////////////////////////////////////////Progress bar
		
	});*/
	
	/*$( document ).on("change input paste keyup", "textarea#TextAns",function()
	{
	   //alert($(this).val());

		var TextAreaAns =  $(this).val();
		//alert("asd");
		$.getJSON($("#ctx").val()+"/ajax/get-attempted-ajax",
		function(Data) 
		{
			//alert("Total "+Data.totalQuestions+"  attemptes "+Data.attemptedQues);
			if( TextAreaAns != null)
			{
				var percentage =   parseInt((++Data.attemptedQues / Data.totalQuestions)*100);
				 $('.progress-bar').css('width', percentage+'%');
				 $('.progress-bar').text(percentage+'%');
			}
			 
		});
	});*/
	$( document ).on( "click", "input.NextButton", function(e) 
	{
		console.log($('#TextAns').val());
		console.log($(this).val());
		navSelector();
		QuestionAjax($(this).val());
		
	});
	
	$( document ).on( "click", "input.PrevButton", function(e) 
	{
		
		console.log($(this).val());
		navSelector();
		QuestionAjax($(this).val());
		
	});
	
	
	$( document ).on( "click", "input.submitTest", function(e) 
	{
		console.log($(this).val());
		QuestionAjax($(this).val());
		
	});
	
	$( document ).on( "click", "textarea#TextAns", function(e) 
	{
		$(this).ClassyEdit();
	});
	
	$( document ).on( "mouseenter", "div.TextAnsDiv", function(e) 
	{
		$("textarea#TextAns").removeClass("collapse");
		$(this).addClass("collapse");
		$("textarea#TextAns").trigger("click");
	});
	
	function disableF5(e) 
	{ 
		if ((e.which || e.keyCode) == 116)
		{
			$('#RefreshModal').modal('show'); 
			e.preventDefault(); 
		}
	};
	$(document).on("keydown", disableF5);
	
	/*window.onbeforeunload = function() 
	{
        return "You really want to refresh, Your response might not be saved!!!";
    }*/
	history.pushState(null, null, document.URL);
	window.addEventListener('popstate', function () 
	{
	    history.pushState(null, null, document.URL);
	});


//////////////////Toolbar function
	(function(a) {
	    debugme = function(a, e) {
	        a && console.log(a);
	        e && alert(e)
	    };
	    triggerclick = function() {
	        debugme("click triggered");
	        thiselement = window.getSelection().focusNode.parentNode;
	        a(thiselement).trigger("click")
	    };
	    a.fn.ClassyEdit = function(c) {
	        var e, h, i = ["start"], f = a(this);
	        "undefined" == typeof a.fn.ClassyEdit.counter ? a.fn.ClassyEdit.counter = 1 : a.fn.ClassyEdit.counter++;
	        for (var b = a.fn.ClassyEdit.counter, c = a.extend({
	            animation: !0,
	            buttons: "bold italic underline insertUnorderedList href".split(" ")
	        }, c), g = '<div class="classyedit table-responsive" style="height:160px;" classyeditor="' + b + '"><div class="toolbar">', j = 0; j < c.buttons.length; j++)
	            firstline = 0 == j ? " first" : "", g = g + '<div class="button' + firstline + '"><a href="#" command="' + c.buttons[j] + '"></a></div>';
	        g = g + '</div><div class="editor" contenteditable="true">' + f.val() + '</div><textarea class="html_editor">' + f.val() + "</textarea></div>";
	        f.hide();
	        f.after(g);
	        e = a("[classyeditor='" + b + "'] [contenteditable]");
	        !1 == c.animation && (a("[classyeditor='" + b + "'] .toolbar").show(), a("[classyeditor='" + b + "'] .editor").css("marginTop", "-6px"));
	        a("[classyeditor='" + b + "'] .editor").focus(function() {
	            if (c.animation == true) {
	                debugme("open toolbar: " + h);
	                clearTimeout(h);
	                a(this).parent().find(".toolbar").slideDown("fast");
	                a(this).css("marginTop", "-6px")
	            }
	        });
	        a("[classyeditor='" + b + "'] .editor").focusout(function() {
	            if (c.animation == true) {
	                var a = jQuery(this);
	                h = setTimeout(function() {
	                    a.parent().find(".toolbar").slideUp("fast");
	                    a.css("marginTop", "0px")
	                }, 100)
	            }
	        });
	        a("[classyeditor='" + b + "'] .html_editor").focus(function() 
	        {
	            a(this).parent().find(".toolbar").slideDown("fast")
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").focus(function() {
	            e = this
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").keyup(function() {
	            triggerclick()
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").click(function() {
	            cleantoolbar(b)
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").focusout(function() {
	            f.val(a(this).html());
	            a("[classyeditor='" + b + "'] .html_editor").val(a(this).html());
	            a("[classyeditor='" + b + "'] .html_editor").css("height", a(this).height())
	        });
	        a("[classyeditor='" + b + "'] .button a").click(function(a) {
	            a.preventDefault()
	        });
	        cleantoolbar = function(b) {
	            a("[classyeditor='" + b + "'] [command]").each(function() {
	                jQuery.inArray(a(this).attr("command"), i) > 0 ? a(this).parent().addClass("on") : a(this).parent().removeClass("on")
	            });
	            debugme("buttonson = " + i.join(" / ") + " (toolbar cleaned)");
	            i = ["start"]
	        };
	        buttonstate = function(b, d, c) {
	            if (d == "on") {
	                a("[classyeditor='" + c + "'] [command='" + b + "']").parent().addClass("on");
	                b != "html" && i.push(b)
	            } else if (d == "off")
	                a("[classyeditor='" + c + "'] [command='" + b + "']").parent().removeClass("on");
	            else {
	                debugme(c + " is on/off: " + a("[classyeditor='" + c + "'] [command='" + b + "']").parent().hasClass("on"));
	                return a("[classyeditor='" + c + "'] [command='" + b + "']").parent().hasClass("on")
	            }
	        };
	        a("[classyeditor='" + b + "'] [contenteditable]").delegate("b", "click", function() {
	            buttonstate("bold", "on", b)
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").delegate("u", "click", function() {
	            buttonstate("underline", "on", b)
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").delegate("i", "click", function() {
	            buttonstate("italic", "on", b)
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").delegate("ul", "click", function() {
	            buttonstate("insertUnorderedList", "on", b)
	        });
	        a("[classyeditor='" + b + "'] [contenteditable]").delegate("a", "click", function() {
	            buttonstate("href", "on", b)
	        });
	        a("[classyeditor='" + b + "'] [command]").click(function() {
	            var c = true, d = a(this).attr("command");
	            debugme(d);
	            if (e == null) {
	                alert("Click an editable area first");
	                return false
	            }
	            buttonstate(d, "", b) ? buttonstate(d, "off", b) : buttonstate(d, "on", b);
	            if (d == "html") {
	                clearTimeout(h);
	                if (buttonstate(d, "", b) == true) {
	                    a("[classyeditor='" + b + "'] [contenteditable]").hide();
	                    a("[classyeditor='" + b + "'] .html_editor").show()
	                }
	                else {
	                    a("[classyeditor='" + b + "'] [contenteditable]").html(a("[classyeditor='" + b + "'] .html_editor").val());
	                    f.val(a("[classyeditor='" + b + "'] .html_editor").val());
	                    a("[classyeditor='" + b + "'] [contenteditable]").show();
	                    a("[classyeditor='" + b + "'] .html_editor").hide()
	                }
	                return true
	            }
	            if (d == "bold" || d == "italic" || d == "underline" || d == "href")
	                try {
	                    document.execCommand("styleWithCSS", 0, false)
	                } catch (g) {
	                    try {
	                        document.execCommand("useCSS", 0, true)
	                    } catch (i) {
	                        try {
	                            document.execCommand("styleWithCSS", false, false)
	                        } catch (j) {
	                            debugme("Unable to set style formatting.")
	                        }
	                    }
	                }
	            if (d == "href") {
	                c = prompt("Type a url:", "http://");
	                if (!c)
	                    return false;
	                d = "createLink"
	            }
	            clearTimeout(h);
	            document.execCommand(d, false, c)
	        })
	    }
	})(jQuery);
	
	//$("textarea#TextAns").ClassyEdit();
	
});
	