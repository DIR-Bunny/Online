/**
 * 
 */

$(document).ready(function() 
{
	$(".close").click(function() 
	{
		$("#myAlert").alert();
	});
});


function MySearch()
{
	//alert("i am here");
	var searchParam = $(".MySearchBox").val();
	//alert(searchParam);
	$.getJSON($("#ctx").val()+"/ajax/get-search-ajax",
			{SearchParam : searchParam},
			function(Data) 
			{
				//console.log(Data);
				//console.log(Data[0].examScheduleId);
				if(Data != null)
				{
					var Table = $(".ExamScheduleTable").text('');
					
					for (var i = 0; i < Data.length; i++) 
					{
						var tr = document.createElement("tr");
//						Table.append('<tr>');
						var td = document.createElement("td");
						if((Data[i].examStatus.toUpperCase() == 'Completed'.toUpperCase()) || (Data[i].examStatus.toUpperCase() == 'Attempted'.toUpperCase()))
						{
							
							//alert(" 1st  "+Data[i].examStatus.toUpperCase());
							
								td.append('<strong style="text-decoration: underline;">'+Data[i].questionPaperTitle+'</strong>');
								td.append(Data[i].examStatus);
								td.append(Data[i].targetDate);
								td.append(Data[i].completedDate);
								td.append(Data[i].score+' %');
								td.append('<td><a href="/OnlineEvaluationPortalWeb/question/get-all-questions/'+Data[i].questionPaperId+'" class="btn btn-default viewButton"><i class="fa fa-eye" aria-hidden="true"></i></a></td>');
							tr.append(td);
						}
						if(Data[i].examStatus.toUpperCase() == 'Pending'.toUpperCase())
						{
							var aTag = document.createElement('a');
							aTag.setAttribute('href','/OnlineEvaluationPortalWeb/exam/load-exam/'+Data[i].examScheduleId+'');
							aTag.innerHTML = Data[i].questionPaperTitle;
							
							
							td.appendChild(aTag);
							tr.appendChild(td);
							
							td = document.createElement("td");
							var t = document.createTextNode(Data[i].examStatus);
							td.appendChild(t);
							tr.appendChild(td);
							
							td = document.createElement("td");
							t = document.createTextNode(Data[i].targetDate);
							td.appendChild(t);
							tr.appendChild(td);
							
							td = document.createElement("td");
							t = document.createTextNode(Data[i].completedDate);
							td.appendChild(t);
							tr.appendChild(td);
							
							td = document.createElement("td");
							t = document.createTextNode(Data[i].score+' %');
							td.appendChild(t);
							tr.appendChild(td);
							
							
							var aTag1 = document.createElement('a');
							aTag1.setAttribute('class','btn btn-default viewButton');
							
							var iTag = document.createElement('i');
							iTag.setAttribute('class','fa fa-eye');
							iTag.setAttribute('aria-hidden','true');
							aTag1.appendChild(iTag);
							td = document.createElement("td");
							
							td.appendChild(aTag1);
							tr.appendChild(td);
						}
						Table.append(tr);
					}
				}
				
			});
}

$("document").ready(function()
{
	var searchParam = $(".MySearchBox").val('');
	if(searchParam.length < 3)
	{
		//window.location.href='some url';
	}
	
	$(".MySearchBox").keyup(function()
	{
		MySearch();
	});
	
	
});