package com.ikea.automation.entity;



import java.sql.Date;

public class Extphysicalstores 
{
	private String STORE_NUMBER;
	private String COUNTRY_CODE;
	private String STORE_NAME;
	private String ADDRESS1;
	private String ADDRESS2;
	private String ADDRESS3;
	private String PHONE;
	private String FAX;
	private String STORE_TYPE;
	private Date OPENING_DATE;
	private Date CLOSING_DATE;
	private Date UPD_DATE;
	private Date REG_DATE;
	private int PUBLISHED;
	private String RETAIL_UNIT_CODE;
	private String OPTCOUNTER;
	private int LANGUAGE_ID;
	private int STOCKCHECK;
	public Extphysicalstores()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Extphysicalstores(String sTORE_NUMBER, String cOUNTRY_CODE, String sTORE_NAME, String aDDRESS1,
			String aDDRESS2, String aDDRESS3, String pHONE, String fAX, String sTORE_TYPE, Date oPENING_DATE,
			Date cLOSING_DATE, Date uPD_DATE, Date rEG_DATE, int pUBLISHED, String rETAIL_UNIT_CODE, String oPTCOUNTER,
			int lANGUAGE_ID, int sTOCKCHECK)
	{
		super();
		STORE_NUMBER = sTORE_NUMBER;
		COUNTRY_CODE = cOUNTRY_CODE;
		STORE_NAME = sTORE_NAME;
		ADDRESS1 = aDDRESS1;
		ADDRESS2 = aDDRESS2;
		ADDRESS3 = aDDRESS3;
		PHONE = pHONE;
		FAX = fAX;
		STORE_TYPE = sTORE_TYPE;
		OPENING_DATE = oPENING_DATE;
		CLOSING_DATE = cLOSING_DATE;
		UPD_DATE = uPD_DATE;
		REG_DATE = rEG_DATE;
		PUBLISHED = pUBLISHED;
		RETAIL_UNIT_CODE = rETAIL_UNIT_CODE;
		OPTCOUNTER = oPTCOUNTER;
		LANGUAGE_ID = lANGUAGE_ID;
		STOCKCHECK = sTOCKCHECK;
	}
	public String getSTORE_NUMBER()
	{
		return STORE_NUMBER;
	}
	public void setSTORE_NUMBER(String sTORE_NUMBER)
	{
		STORE_NUMBER = sTORE_NUMBER;
	}
	public String getCOUNTRY_CODE()
	{
		return COUNTRY_CODE;
	}
	public void setCOUNTRY_CODE(String cOUNTRY_CODE)
	{
		COUNTRY_CODE = cOUNTRY_CODE;
	}
	public String getSTORE_NAME()
	{
		return STORE_NAME;
	}
	public void setSTORE_NAME(String sTORE_NAME)
	{
		STORE_NAME = sTORE_NAME;
	}
	public String getADDRESS1()
	{
		return ADDRESS1;
	}
	public void setADDRESS1(String aDDRESS1)
	{
		ADDRESS1 = aDDRESS1;
	}
	public String getADDRESS2()
	{
		return ADDRESS2;
	}
	public void setADDRESS2(String aDDRESS2)
	{
		ADDRESS2 = aDDRESS2;
	}
	public String getADDRESS3()
	{
		return ADDRESS3;
	}
	public void setADDRESS3(String aDDRESS3)
	{
		ADDRESS3 = aDDRESS3;
	}
	public String getPHONE()
	{
		return PHONE;
	}
	public void setPHONE(String pHONE)
	{
		PHONE = pHONE;
	}
	public String getFAX()
	{
		return FAX;
	}
	public void setFAX(String fAX)
	{
		FAX = fAX;
	}
	public String getSTORE_TYPE()
	{
		return STORE_TYPE;
	}
	public void setSTORE_TYPE(String sTORE_TYPE)
	{
		STORE_TYPE = sTORE_TYPE;
	}
	public Date getOPENING_DATE()
	{
		return OPENING_DATE;
	}
	public void setOPENING_DATE(Date oPENING_DATE)
	{
		OPENING_DATE = oPENING_DATE;
	}
	public Date getCLOSING_DATE()
	{
		return CLOSING_DATE;
	}
	public void setCLOSING_DATE(Date cLOSING_DATE)
	{
		CLOSING_DATE = cLOSING_DATE;
	}
	public Date getUPD_DATE()
	{
		return UPD_DATE;
	}
	public void setUPD_DATE(Date uPD_DATE)
	{
		UPD_DATE = uPD_DATE;
	}
	public Date getREG_DATE()
	{
		return REG_DATE;
	}
	public void setREG_DATE(Date rEG_DATE)
	{
		REG_DATE = rEG_DATE;
	}
	public int getPUBLISHED()
	{
		return PUBLISHED;
	}
	public void setPUBLISHED(int pUBLISHED)
	{
		PUBLISHED = pUBLISHED;
	}
	public String getRETAIL_UNIT_CODE()
	{
		return RETAIL_UNIT_CODE;
	}
	public void setRETAIL_UNIT_CODE(String rETAIL_UNIT_CODE)
	{
		RETAIL_UNIT_CODE = rETAIL_UNIT_CODE;
	}
	public String getOPTCOUNTER()
	{
		return OPTCOUNTER;
	}
	public void setOPTCOUNTER(String oPTCOUNTER)
	{
		OPTCOUNTER = oPTCOUNTER;
	}
	public int getLANGUAGE_ID()
	{
		return LANGUAGE_ID;
	}
	public void setLANGUAGE_ID(int lANGUAGE_ID)
	{
		LANGUAGE_ID = lANGUAGE_ID;
	}
	public int getSTOCKCHECK()
	{
		return STOCKCHECK;
	}
	public void setSTOCKCHECK(int sTOCKCHECK)
	{
		STOCKCHECK = sTOCKCHECK;
	}
	@Override
	public String toString()
	{
		return "Extphysicalstores [STORE_NUMBER=" + STORE_NUMBER + ", COUNTRY_CODE=" + COUNTRY_CODE + ", STORE_NAME="
				+ STORE_NAME + ", ADDRESS1=" + ADDRESS1 + ", ADDRESS2=" + ADDRESS2 + ", ADDRESS3=" + ADDRESS3
				+ ", PHONE=" + PHONE + ", FAX=" + FAX + ", STORE_TYPE=" + STORE_TYPE + ", OPENING_DATE=" + OPENING_DATE
				+ ", CLOSING_DATE=" + CLOSING_DATE + ", UPD_DATE=" + UPD_DATE + ", REG_DATE=" + REG_DATE
				+ ", PUBLISHED=" + PUBLISHED + ", RETAIL_UNIT_CODE=" + RETAIL_UNIT_CODE + ", OPTCOUNTER=" + OPTCOUNTER
				+ ", LANGUAGE_ID=" + LANGUAGE_ID + ", STOCKCHECK=" + STOCKCHECK + "]";
	}
	
	
	
	
}


/*@Id
@Column(name="STORE_NUMBER")
private String STORE_NUMBER;
@Column(name="COUNTRY_CODE")
private String COUNTRY_CODE;
@Column(name="STORE_NAME")
private String STORE_NAME;
@Column(name="ADDRESS1")
private String ADDRESS1;
@Column(name="ADDRESS2")
private String ADDRESS2;
@Column(name="ADDRESS3")
private String ADDRESS3;
@Column(name="PHONE")
private String PHONE;
@Column(name="FAX")
private String FAX;
@Column(name="STORE_TYPE")
private String STORE_TYPE;
@Column(name="OPENING_DATE")
private Date OPENING_DATE;
@Column(name="CLOSING_DATE")
private Date CLOSING_DATE;
@Column(name="UPD_DATE")
private Date UPD_DATE;
@Column(name="REG_DATE")
private Date REG_DATE;
@Column(name="PUBLISHED")
private int PUBLISHED;
@Column(name="RETAIL_UNIT_CODE")
private String RETAIL_UNIT_CODE;
@Column(name="OPTCOUNTER")
private String OPTCOUNTER;*/
