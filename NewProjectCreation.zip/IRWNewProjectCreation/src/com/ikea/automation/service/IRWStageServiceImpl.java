package com.ikea.automation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.dao.IRWStageDao;
import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.Ri_price_v;

@Service
@Transactional
public class IRWStageServiceImpl implements IRWStageService
{
	@Autowired
	IRWStageDao IRWStageDao;

	@Override
	public boolean checkPriceInIRW(Ri_price_v obj)
	{
		return IRWStageDao.PriceStatusInIRW(obj);
	}

	@Override
	public List<IRW_RIX_PRICE_DET> CheckPriceUpdated(List<IRW_RIX_PRICE_DET> notUpdatedPriceList)
	{
		return IRWStageDao.CheckPriceUpdated(notUpdatedPriceList);
	}

	
}
