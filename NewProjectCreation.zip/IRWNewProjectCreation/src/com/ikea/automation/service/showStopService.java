package com.ikea.automation.service;

import java.io.InputStream;

import com.ikea.automation.pojo.ShowStop;

public interface showStopService
{
	public boolean updateShowStopUpload(InputStream inputStream, String excelFileName,ShowStop obj) throws Exception;
	public boolean updateShowStopUploadCSV(InputStream inputStream, String csvFileName,ShowStop obj) throws Exception;
	public boolean updateShowStop(ShowStop obj);
}
