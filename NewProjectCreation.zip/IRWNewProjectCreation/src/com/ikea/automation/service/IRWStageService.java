package com.ikea.automation.service;

import java.util.List;

import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.Ri_price_v;

public interface IRWStageService
{
	public boolean checkPriceInIRW(Ri_price_v obj);
	
	public List<IRW_RIX_PRICE_DET> CheckPriceUpdated(List<IRW_RIX_PRICE_DET> notUpdatedPriceList);
}
