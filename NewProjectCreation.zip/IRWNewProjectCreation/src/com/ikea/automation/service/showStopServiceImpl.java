package com.ikea.automation.service;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.dao.showStopDao;
import com.ikea.automation.pojo.ShowStop;
import com.ikea.automation.utility.CustomGenericException;

@Service
@Transactional
public class showStopServiceImpl implements showStopService
{
	@Autowired
	showStopDao ShowStopDao;
	
	@Override
	public boolean updateShowStopUpload(InputStream inputStream, String excelFileName,ShowStop obj) throws CustomGenericException
	{

		//List<String> partNumbers = new ArrayList<>();
		
		///Get workbook
		try 
		{
			Workbook workbook = ShowStopDao.getWorkbook(inputStream, excelFileName);

			/// get spread sheet 
			Sheet worksheet = workbook.getSheetAt(0);
			
			
			Iterator<Row> rowIterator =  worksheet.iterator();
			 
			 while (rowIterator.hasNext())
			{
				 
				Row nextRow  = rowIterator.next();
				if(nextRow.getRowNum() == 0)
					continue;
				else
				{
					System.out.print("Row : "+nextRow.getRowNum()+" ");
					
					Iterator<Cell> cellIterator = nextRow.cellIterator();
					
					
					
					
					
					while (cellIterator.hasNext())
					{
						//row.getCell(i).setCellType(org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING);
			            Cell nextCell = cellIterator.next();
			            nextCell.setCellType(org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING);
			            int columnIndex = nextCell.getColumnIndex();
			            //question = new Question();
			            switch (columnIndex)
			            {
			            
				            case 0:
				                System.out.print(columnIndex+" "+nextCell+" ");
				                //user.setUserId(String.valueOf(uploadDao.getCellValue(nextCell)));
				                //obj.getPartNumbers().add(String.valueOf(Math.round(nextCell.getNumericCellValue())));
				                obj.getPartNumbers().add(String.valueOf(nextCell));
				                break;
				            
			            }
			            
			        }
					System.out.println("");
					if (nextRow.getRowNum() > 0)
					{
						//obj.setQuestion(question);
						System.err.println(obj);
					}
					
				}
				
			}
			 System.out.println("i am part list "+obj.getPartNumbers());
			
		} 
		catch (Exception e) 
		{
			System.out.println("Error already occured 2");
			throw new CustomGenericException("123", "Something went wrong with processing your Excel file!! Please check Excel or try again Later");
		}
		return ShowStopDao.updateShowStopUpload(obj); 
	}

	@Override
	public boolean updateShowStopUploadCSV(InputStream inputStream, String csvFileName,ShowStop obj) throws Exception
	{
		CSVParser parser = new CSVParser(new InputStreamReader(inputStream),CSVFormat.DEFAULT);
		for (CSVRecord record : parser) 
		{
			System.out.println("I am printing csv records "+record);
			for (String partNumber : record)
			{
				if(!partNumber.isEmpty())
					obj.getPartNumbers().add(partNumber);
				
			}
		}
		System.err.println("I am printing csv records "+obj);
		return ShowStopDao.updateShowStopUpload(obj); 
	}

	@Override
	public boolean updateShowStop(ShowStop obj)
	{
		return ShowStopDao.updateShowStopUpload(obj);
	}

	
	
}
