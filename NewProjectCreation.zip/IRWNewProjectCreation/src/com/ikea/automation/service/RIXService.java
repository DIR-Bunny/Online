package com.ikea.automation.service;

import java.util.List;

import com.ikea.automation.pojo.Ri_price_v;

public interface RIXService
{
	public List<Ri_price_v> getPricesFromRIX();
}
