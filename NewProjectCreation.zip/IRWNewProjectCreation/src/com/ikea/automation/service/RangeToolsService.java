package com.ikea.automation.service;

import java.util.List;

import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.PriceMarketDetails;

public interface RangeToolsService
{
	public boolean InsertIntoIRWRIXPrice(IRW_RIX_PRICE_DET obj);
	
	public List<IRW_RIX_PRICE_DET> getAllNotReflectedPrices();
	
	public boolean UpdateIRWStatus(List<IRW_RIX_PRICE_DET> updatedList);
	
	public List<PriceMarketDetails> getAllRecordsOnMarketpercentage();
	public List<IRW_RIX_PRICE_DET> getRecordsOnMarket(String marketName);
}
