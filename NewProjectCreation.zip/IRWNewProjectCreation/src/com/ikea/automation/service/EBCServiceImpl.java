package com.ikea.automation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.dao.EBCDao;
import com.ikea.automation.pojo.ConnectedItemPojo;
import com.ikea.automation.pojo.Ri_price_v;

@Service
@Transactional
public class EBCServiceImpl implements EBCService
{
	@Autowired
	EBCDao EBCDao;

	@Override
	public List<ConnectedItemPojo> getAllConnectedItems(List<Ri_price_v> RixPriceList)
	{
		return EBCDao.getAllConnectedItems(RixPriceList);
	}

}
