package com.ikea.automation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.dao.RangeToolsDao;
import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.PriceMarketDetails;

@Service
@Transactional
public class RangeToolsServiceImpl implements RangeToolsService
{
	@Autowired
	RangeToolsDao rangeToolsDao;

	@Override
	public boolean InsertIntoIRWRIXPrice(IRW_RIX_PRICE_DET obj)
	{
		return rangeToolsDao.InsertIntoIRWRIXPrice(obj);
	}

	@Override
	public List<IRW_RIX_PRICE_DET> getAllNotReflectedPrices()
	{
		return rangeToolsDao.getAllNotReflectedPrices();
	}

	@Override
	public boolean UpdateIRWStatus(List<IRW_RIX_PRICE_DET> updatedList)
	{
		return rangeToolsDao.UpdateIRWStatus(updatedList);
	}

	@Override
	public List<PriceMarketDetails> getAllRecordsOnMarketpercentage()
	{
		return rangeToolsDao.getAllRecordsOnMarketpercentage();
	}

	@Override
	public List<IRW_RIX_PRICE_DET> getRecordsOnMarket(String marketName)
	{
		return rangeToolsDao.getRecordsOnMarket(marketName);
	}
	
}
