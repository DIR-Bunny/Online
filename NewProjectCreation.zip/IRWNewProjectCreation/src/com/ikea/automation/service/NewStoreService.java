package com.ikea.automation.service;

import java.util.List;

import com.ikea.automation.entity.Extphysicalstores;
import com.ikea.automation.pojo.Language;

public interface NewStoreService 
{
	public List<Extphysicalstores> selectAllStores();
	
	public List<String> getCountryCodes();
	
	public List<String> getStoreTypes();
	
	public List<String> getStoreNumbers(String storeNumber);
	
	public int saveNewStore(Extphysicalstores obj);
	
	public int[] CreateNewJob(Extphysicalstores obj);
	
	public List<Language> getLanguagesOnCountry(String countryCode);
	public String getMarketName(int LANGUAGE_ID);
	
	public boolean updateStockCheck(Extphysicalstores obj);
}
