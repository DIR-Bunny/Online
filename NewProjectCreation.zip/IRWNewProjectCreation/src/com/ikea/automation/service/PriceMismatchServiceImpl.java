package com.ikea.automation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.pojo.ConnectedItemPojo;
import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.Ri_price_v;

@Service
@Transactional
public class PriceMismatchServiceImpl implements PriceMismatchService
{

	@Autowired
	IRWStageService IRWStageService;
	
	@Autowired 
	RangeToolsService rangeToolsService;
	
	@Autowired
	EBCService ebcService;
	
	
	@Override
	public boolean checkMismatch(List<Ri_price_v> priceList)
	{
		boolean priceInIRWStatus = false;
		List<ConnectedItemPojo> connectedItemsList = ebcService.getAllConnectedItems(priceList);
		for (Ri_price_v obj : priceList)
		{
			if(connectedItemsList.stream().anyMatch(p -> (p.getITEM_NO().equals(obj.getITEM_NO())   && p.getITEM_TYPE().equals(obj.getITEM_TYPE()))))
			{
				IRW_RIX_PRICE_DET IRPT = new IRW_RIX_PRICE_DET();
				IRPT.setMARKETNAME(obj.getCLASS_UNIT_CODE());
				IRPT.setITEM_NO(obj.getITEM_NO());
				IRPT.setITEM_TYPE(obj.getITEM_TYPE());
				IRPT.setPRICE_TYPE(obj.getPRICE_TYPE());
				IRPT.setFROM_DTIME(obj.getFROM_DTIME());
				IRPT.setEND_DTIME(obj.getTO_DTIME());
				IRPT.setPRICE_INCL_TAX(obj.getPRICE_INCL_TAX());
				IRPT.setREASON_CODE(obj.getREASON_CODE());
				IRPT.setRIX_STATUS("YES");
				IRPT.setRIX_UPDATED_DATE(obj.getUPD_DTIME());
				
				
				////get single obj of RIX price and check with IRW
				priceInIRWStatus = IRWStageService.checkPriceInIRW(obj);
				System.out.println("For "+ obj.getITEM_NO() +" Price in IRW status : "+priceInIRWStatus);
				IRPT.setIRW_STATUS((priceInIRWStatus) ? "YES" : "NO");
				
				//////save All data in RangeTools DB IRW_RIX_PRICE_DET Table
				rangeToolsService.InsertIntoIRWRIXPrice(IRPT);
			}
			
		}
		
		//// if yes save Rix price to Range tools and IRWstatus as yes insert date of IRW insert as well in Range tools
		//// if no save Rix price to Range tools and IRWstatus as No
		return false;
	}

	@Override
	public boolean updateIRPT()
	{
		List<IRW_RIX_PRICE_DET> updatedList = IRWStageService.CheckPriceUpdated(rangeToolsService.getAllNotReflectedPrices());
		
		if(!updatedList.isEmpty())
		{
			return (rangeToolsService.UpdateIRWStatus(updatedList)) ?  true : false;
		}
		return false;
	}
	
}
