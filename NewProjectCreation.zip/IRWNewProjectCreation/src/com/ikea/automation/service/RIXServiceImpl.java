package com.ikea.automation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.dao.RIXDao;
import com.ikea.automation.pojo.Ri_price_v;

@Service
@Transactional
public class RIXServiceImpl implements RIXService
{

	@Autowired
	RIXDao RIXDao;
	
	@Override
	public List<Ri_price_v> getPricesFromRIX()
	{
		return RIXDao.getPricesFromRIX();
	}

}
