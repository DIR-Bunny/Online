package com.ikea.automation.service;

import java.util.List;

import com.ikea.automation.pojo.ConnectedItemPojo;
import com.ikea.automation.pojo.Ri_price_v;

public interface EBCService
{
	List<ConnectedItemPojo> getAllConnectedItems(List<Ri_price_v> RixPriceList);
}
