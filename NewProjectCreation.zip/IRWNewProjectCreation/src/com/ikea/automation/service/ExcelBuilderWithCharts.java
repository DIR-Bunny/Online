package com.ikea.automation.service;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFClientAnchor;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFPicture;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Workbook;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.TextAnchor;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.PriceMarketDetails;

public class ExcelBuilderWithCharts extends AbstractExcelView
{

	
	
	@SuppressWarnings("unchecked")
	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest arg2,HttpServletResponse arg3) throws Exception
	{
		 HashMap <String, Object> hm =   (HashMap<String, Object>) model.get("HashMap");
		System.out.println("Inside excel builder Charts ");
        // create a new Excel sheet
        HSSFSheet sheet = workbook.createSheet("Data");
        sheet.setDefaultColumnWidth(30);
         
        // create style for header cells
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontName("Arial");
        style.setFillForegroundColor(HSSFColor.GREEN.index);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        style.setFont(font);
         
        ///////for no status 
        CellStyle style1 = workbook.createCellStyle();
        style1.setFillForegroundColor(HSSFColor.RED.index);
        style1.setFillPattern(CellStyle.SOLID_FOREGROUND);
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        style1.setFont(font);
        // create header row
        HSSFRow header = sheet.createRow(0);
        
        header.createCell(0).setCellValue("MARKETNAME");
        header.createCell(1).setCellValue("ITEM_NO");
        header.createCell(2).setCellValue("PRICE_INCL_TAX");
        header.createCell(3).setCellValue("RIX_STATUS");
        header.createCell(4).setCellValue("IRW_STATUS");
        for(int j = 0; j<=4; j++)
        	header.getCell(j).setCellStyle(style);
         
        List<IRW_RIX_PRICE_DET> allRecordsList = (List<IRW_RIX_PRICE_DET>) hm.get("allRecordsList");
       // List<IRW_RIX_PRICE_DET> allRecordsList = rangeToolsSevice.getRecordsOnMarket("ALL");
        // create data rows
        int rowCount = 1;
        
       for (IRW_RIX_PRICE_DET obj : allRecordsList)
		{
    	   HSSFRow aRow = sheet.createRow(rowCount++);
    	   aRow.createCell(0).setCellValue(obj.getMARKETNAME());
           aRow.createCell(1).setCellValue(obj.getITEM_NO());
           aRow.createCell(2).setCellValue(obj.getPRICE_INCL_TAX());
           aRow.createCell(3).setCellValue(obj.getRIX_STATUS());
           aRow.createCell(4).setCellValue(obj.getIRW_STATUS());
           if(obj.getIRW_STATUS().equalsIgnoreCase("NO"))
           {
        	   for(int j = 0; j<=4; j++)
               	aRow.getCell(j).setCellStyle(style1);
        	   
           }  
		}
		
        
        HSSFSheet Chart = workbook.createSheet("Chart");
       
        List<PriceMarketDetails> recordsPerMarket =  (List<PriceMarketDetails>) hm.get("recordsPerMarket");
        
        //List<PriceMarketDetails> recordsPerMarket = rangeToolsSevice.getAllRecordsOnMarketpercentage();
       
        final DefaultCategoryDataset dataset = new DefaultCategoryDataset( ); 
        
        for (PriceMarketDetails obj : recordsPerMarket)
		{
        	 dataset.addValue(obj.getRIXPrice(), "RIX", obj.getMarketName());
        	 dataset.addValue(obj.getIRWPrice(), "IRW", obj.getMarketName());
		}
        
        JFreeChart BarChartObject=ChartFactory.createBarChart("Percentage per market","Markets","Percentage",dataset,PlotOrientation.VERTICAL,true,true,false);  
        int width=1000;
        int height=480;     
        
        
        CategoryItemRenderer renderer = ((CategoryPlot)BarChartObject.getPlot()).getRenderer();

        renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        renderer.setBaseItemLabelsVisible(true);
        ItemLabelPosition position = new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, 
                TextAnchor.TOP_CENTER);
        renderer.setBasePositiveItemLabelPosition(position);
     // get a reference to the plot for further customisation...
        final CategoryPlot plot = BarChartObject.getCategoryPlot();
        plot.setNoDataMessage("NO DATA!");
        ByteArrayOutputStream chart_out = new ByteArrayOutputStream();       
        ChartUtilities.writeChartAsPNG(chart_out,BarChartObject,width,height);
        int my_picture_id = workbook.addPicture(chart_out.toByteArray(), Workbook.PICTURE_TYPE_PNG);
        chart_out.close();
        
        HSSFPatriarch drawing = Chart.createDrawingPatriarch();
        
        ClientAnchor my_anchor = new HSSFClientAnchor();
        
        my_anchor.setCol1(4);
        my_anchor.setRow1(5);
        
        
        HSSFPicture  my_picture = drawing.createPicture(my_anchor, my_picture_id);
        my_picture.resize();
       
	}

}