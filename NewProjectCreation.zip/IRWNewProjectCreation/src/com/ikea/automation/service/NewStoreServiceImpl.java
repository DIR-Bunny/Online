package com.ikea.automation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ikea.automation.dao.NewStoreDao;
import com.ikea.automation.entity.Extphysicalstores;
import com.ikea.automation.pojo.Language;

@Service
@Transactional
public class NewStoreServiceImpl implements NewStoreService 
{

	@Autowired
	NewStoreDao newStoreDao;
	
	@Override
	public List<Extphysicalstores> selectAllStores()
	{
		return newStoreDao.selectAllStores();
	}

	@Override
	public List<String> getCountryCodes()
	{
		return newStoreDao.getCountryCodes();
	}

	@Override
	public List<String> getStoreTypes()
	{
		return newStoreDao.getStoreTypes();
	}

	@Override
	public List<String> getStoreNumbers(String storeNumber)
	{
		return newStoreDao.getStoreNumbers(storeNumber);
	}

	@Override
	public int saveNewStore(Extphysicalstores obj)
	{
		return newStoreDao.saveNewStore(obj);
	}

	@Override
	public int[] CreateNewJob(Extphysicalstores obj)
	{
		return newStoreDao.CreateNewJob(obj);
	}

	@Override
	public List<Language> getLanguagesOnCountry(String countryCode)
	{
		return newStoreDao.getLanguagesOnCountry(countryCode);
	}

	@Override
	public String getMarketName(int LANGUAGE_ID)
	{
		return newStoreDao.getMarketName(LANGUAGE_ID);
	}

	@Override
	public boolean updateStockCheck(Extphysicalstores obj)
	{
		System.out.println("i am in updateStockCheck service");
		return newStoreDao.updateStockCheck(obj);
	}
	
}
