package com.ikea.automation.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import org.springframework.beans.factory.annotation.Autowired;

import com.ikea.automation.entity.Extphysicalstores;
import com.ikea.automation.service.NewStoreServiceImpl;


public class IRWSMTPProperties {
	
	@Autowired
	public NewStoreServiceImpl newStoreService;

	public static final String fromEmail = "shivam.narayan@ikea.com"; //requires valid gmail id
	public static final String password = "deMale48"; // correct password for gmail id
	//public static final String toEmail = "usharani.kalla@ikea.com,nisha.nani@ikea.com,shivam.narayan@ikea.com,ragni.raj@capgemini.com"; // can be any email id
	public static final String toEmail = "shivam.narayan@ikea.com"; // can be any email id
	
	private IRWSMTPProperties() {
		
	}
	
	private static Session getMailInstance() 
	{
		System.out.println("TLSEmail Start");
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp-gw.ikeadt.com"); //SMTP Host
		//props.put("mail.smtp.port", "587"); //TLS Port
		props.put("mail.smtp.auth", "true"); //enable authentication
		props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
		
                //create Authenticator object to pass in Session.getInstance argument
		Authenticator auth = new Authenticator() {
			//override the getPasswordAuthentication method
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail, password);
			}
		};
		Session session = Session.getInstance(props, auth);
		
		//EmailUtilWithAttachment.sendEmail(session, toEmail,"RIX IRW Price descripencies", "RIX IRW Price descripencies.....");
		return session;

	}
	
	public static void sendStoreCreationEmail(Extphysicalstores obj) {
		Session session = getMailInstance();
		DateFormat df = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
		String dateStr = df.format(new Date());
		String msg1 = "Hi,\nPlease find the below information.\nCRQ CRQ000000241675 has been completed  for the TASK TAS000000496506 on"+dateStr+".\n"+
				"� STORE_NAME   : "+obj.getSTORE_NAME()+"\n"+
				"� STORE_NUMBER : "+obj.getSTORE_NUMBER()+"\n"+
				"� COUNTRY_CODE : "+obj.getCOUNTRY_CODE()+"\n"+
				"@Teamsite Please complete the teamsite deployment from your end so that we will close the task successfully.";

		EmailUtility.sendStoreCreationEmail(session, IRWSMTPProperties.toEmail, "Store Created",msg1);
	}
	
	
}
