package com.ikea.automation.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GenricConnection
{
	
	
	public static Connection open(String DBURL,String USERNAME ,String PASSWORD) throws Exception
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		System.out.println("***************************opening connection for "+DBURL+"********************************************");
		return  (Connection) DriverManager.getConnection(DBURL,USERNAME ,PASSWORD);
	}
	
	
	public static void closeConnection(Connection conn)
	{
		System.out.println("*******************************************CLOSING CONN************************************************");
		try
		{
			if(conn != null)
				conn.close();
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}
