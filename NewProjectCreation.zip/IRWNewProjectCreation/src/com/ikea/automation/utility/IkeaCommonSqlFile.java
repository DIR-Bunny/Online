package com.ikea.automation.utility;

public class IkeaCommonSqlFile 
{
	
	public static final String CHECK_IKEASTOREINDB = "Select * from extphysicalstores where store_number=";
	public static final String CREATE_IKEANEWSTOREINDB = "Insert into extphysicalstores (STORE_NUMBER, COUNTRY_CODE,STORE_NAME, STORE_TYPE, OPENING_DATE, UPD_DATE,REG_DATE, PUBLISHED) values (";
	public static final String CREATE_NEWJOBINSCHCONFIG = "Insert into schconfig (SCCJOBREFNUM,SCCHOST,MEMBER_ID,STOREENT_ID,SCCRECDELAY,SCCRECATT,SCCPATHINFO,SCCQUERY,SCCSTART,SCCINTERVAL,SCCPRIORITY,SCCSEQUENCE,SCCACTIVE,SCCAPPTYPE,INTERFACENAME,OPTCOUNTER) values ((select Max(sccjobrefnum)+1 FROM schconfig),'ptirw731.ikeadt.com',-1000,0,0,0,'IkeamsLogisticsReplication',";
    public static final String ACTIVATE_NEWJOBINSCHACTIVE = "Insert into schactive (SCSINSTREFNUM,SCSJOBNBR,SCSACTLSTART,SCSATTLEFT,SCSEND,SCSINSTRECOV,SCSPREFSTART,SCSQUEUE,SCSRESULT,SCSSEQUENCE,SCSSTATE,SCSPRIORITY,OPTCOUNTER) values ((select Max(scsinstrefnum)+1 FROM schactive),(select max(sccjobrefnum) FROM schconfig),null,0,null,null,to_timestamp(";
    public static final String PUBLISHED_IKEANEWSTORE = "update extlocalstores set published=";
    public static final String PRICEMISMATCH_SQL =  "SELECT T.DATE_STR, T.MARKETNAME,SUM(RIX_STATUS_VALUE) AS RIX_VALUE,SUM(IRW_STATUS_VALUE) AS IRW_VALUE,COUNT(*)AS TOTAL, ROUND(SUM(RIX_STATUS_VALUE)/COUNT(*) * 100,0) AS RIX_PERC,ROUND( SUM(IRW_STATUS_VALUE)/COUNT(*) * 100,0 )AS IRW_PERC "+
    		"FROM(SELECT CASE WHEN RIX_STATUS = 'YES' THEN 1 ELSE 0 END AS RIX_STATUS_VALUE, CASE WHEN IRW_STATUS = 'YES' THEN 1 ELSE 0 END AS IRW_STATUS_VALUE,IRPD.*,TO_CHAR(IRPD.INSERTED_DATE, 'dd-mm-yyyy') AS DATE_STR FROM IRW_RIX_PRICE_DET IRPD) T "+
    		"GROUP BY T.DATE_STR, T.MARKETNAME";
    public static final String PRICEDETAILSALLMARKET_SQL = "SELECT marketname,item_no,rix_status,irw_status,RIX_UPDATED_DATE,IRW_UPDATED_DATE FROM IRW_RIX_PRICE_DET";
    
}