package com.ikea.automation.utility;

public interface IRWConnection
{
	/*PTE 711 Connection*/
	//public String DBURL = "jdbc:oracle:thin:@//PTSEELM-AX2188.ikeadt.com:1521/PT1268.IKEADT.COM";
	public String DBURL = "jdbc:oracle:thin:@//PTSEELM-AX2188.ikeadt.com:1521/PT1266.IKEADT.COM";
	public String USERNAME = "PTEWCLIVE711";
	public String PASSWORD = "PTEWCLIVE711";
	
	
	/*RIX Connetion*/
	public String RIXDBURL = "jdbc:oracle:thin:@//ITCRS202.IKEA.COM:1521/ITRIX.IKEA.COM";
	public String RIXUSERNAME = "IRW_RIX_USER_OFFLINE";
	public String RIXPASSWORD = "IRW_RIX_USER_OFFLINE";
	
	
	/*PTE RangeTools Connection*/
	public String RangeToolsDBURL = "jdbc:oracle:thin:@//ptseelm-lx2336.ikeadt.com:1521/PT1271.IKEADT.COM";
	public String RangeToolsUSERNAME = "PTEIRWRANGETOOLS";
	public String RangeToolsPASSWORD = "PTEIRWRANGETOOLS_123";
	
	
	/*IRWStage Connection*/
	public String IRWStageDBURL = "jdbc:oracle:thin:@//ITSEELM-AX2263.ikea.com:1521/WCDBSTAG12C.IKEA.COM";
	public String IRWStageUSERNAME = "R_PWCSTAG";
	public String IRWStagePASSWORD = "readstagwcs7";
	
	
	/*EBC Connection*/
	public String EBCDBURL = "jdbc:oracle:thin:@//ITSEELM-LX21019.ikea.com:1521/ITIRWDBQUEUE12C.IKEA.COM";
	public String EBCUSERNAME = "m_ebcirwrange01";
	public String EBCPASSWORD = "m_ebcirwrange01";
}
