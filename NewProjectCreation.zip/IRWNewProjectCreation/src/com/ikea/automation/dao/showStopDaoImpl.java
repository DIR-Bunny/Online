package com.ikea.automation.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ikea.automation.pojo.ShowStop;
import com.ikea.automation.utility.CustomGenericException;
import com.ikea.automation.utility.IRWConnection;

@Repository
public class showStopDaoImpl implements showStopDao
{
	private static Logger logger = Logger.getLogger(showStopDaoImpl.class);	
	
	@Autowired
	NewStoreDao dao;
	
	private Connection conn;
	private PreparedStatement pstmt,pstmt1;
	private ResultSet resultSet;
	
	static
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}
	
	@PostConstruct
	public void open() throws Exception
	{
		logger.debug("************************************Entering in open()************************************");
		
		conn = DriverManager.getConnection(IRWConnection.DBURL,IRWConnection.USERNAME ,IRWConnection.PASSWORD);
		logger.debug("************************************Exiting from open()************************************");
		
	}
	
	@PreDestroy
	public void close()
	{
		logger.debug("************************************Entering in close()************************************");
		
		try
		{
			conn.close();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("************************************Exiting from close() ******************************************");
		
		
	}

	
	
	@Override
	public boolean updateShowStopUpload(ShowStop obj)
	{
		logger.debug("************************************Entering in updateShowStopUpload()************************************");
		
		int catEntryId = 0;
		boolean returnStatus = true;
		int storeId = dao.getStoreIdOnCountryCode(obj.getCOUNTRY_CODEST());
		
		String SHOWSTOP_STATUS_ID = (obj.getShowStop().toLowerCase().contains("show")) ? "SHOWSTOP_STATUS_ID" : "BUYSTOP_STATUS_ID";
		//List<Integer> updateStatusList = new ArrayList<>();
		
		String getCatEntryId = "select CATENTRY_ID from CATENTRY where PARTNUMBER= ? ";
		String UpdateShowStopQuery="update extcatentstatus set "+SHOWSTOP_STATUS_ID+"= -3   where CATENTRY_ID= ? and STOREENT_ID = "+storeId+"";
		
		
		try
		{
			if(!obj.getPartNumbers().isEmpty())
			{
				conn.setAutoCommit(false);
				
				for (String partNumber : obj.getPartNumbers())
				{
					pstmt = conn.prepareStatement(getCatEntryId);
					pstmt.setString(1, partNumber.replaceAll(" ", ""));
					resultSet = pstmt.executeQuery();
					System.out.println("Select catentry query : "+ getCatEntryId);
					while(resultSet.next())
					{
						catEntryId = resultSet.getInt("CATENTRY_ID");
					}
					
					System.out.println("catentry Id : "+catEntryId);
					
					if(catEntryId > 0)
					{
						
						pstmt1 = conn.prepareStatement(UpdateShowStopQuery);
						pstmt1.setInt(1, catEntryId);
					
						int updateStatus = pstmt1.executeUpdate();
						//updateStatusList.add(updateStatus);
						returnStatus =  (updateStatus <= 0) ? false : true;
						System.out.println("Status of UpdateShowStopQuery "+updateStatus);
						
					}
					else
						{
							returnStatus = false;
							
						}
				}
				
			}
			else
			{
				
			}
			if(returnStatus)
				conn.commit();
			else
				conn.rollback();
		}
		catch(SQLException ex)
		{
			//sqlcon.rollback();
			ex.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				if(pstmt1!= null)
					pstmt1.close();
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("I am "+returnStatus);
		logger.debug("************************************Exiting from updateShowStopUpload() ******************************************");
		
		return returnStatus;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	////////////////////////////////////////Excel Functions///////////////////////////////////
	@Override
	public Workbook getWorkbook(InputStream inputStream, String excelFileName) throws CustomGenericException
	{
		logger.debug("************************************Entering in getWorkbook()************************************");
		
		 Workbook workbook = null;
		 
		    try {
				if (excelFileName.endsWith("xlsx")) 
				{
				    workbook = new XSSFWorkbook(inputStream);
				} 
				else if (excelFileName.endsWith("xls")) 
				{
				    workbook = new HSSFWorkbook(inputStream);
				} 
				else 
				{
					
					System.out.println("not an excel file");
					//throw new CustomGenericException("0000","The specified file is not Excel file");
				}
			} 
		    catch (IOException e) 
		    {
		    	 throw new CustomGenericException("0000","The specified file is not Excel file");
			}
		    logger.debug("************************************Exiting from getWorkbook() ******************************************");
			
		    return workbook;
	}

	@SuppressWarnings("deprecation")
	@Override
	public Object getCellValue(Cell cell)
	{
		logger.debug("************************************Entering in getCellValue()************************************");
		
		CellType c =   cell.getCellTypeEnum();
		//System.out.println(c.getCode());
	    switch (cell.getCellType()) 
	    {
	    case Cell.CELL_TYPE_STRING:
	        return cell.getStringCellValue();
	 
	    case Cell.CELL_TYPE_BOOLEAN:
	        return cell.getBooleanCellValue();
	 
	    case Cell.CELL_TYPE_NUMERIC:
	        return cell.getNumericCellValue();
	    }
	    logger.debug("************************************Exiting from getCellValue() ******************************************");
		
	    return null;
	}

	
	
}
