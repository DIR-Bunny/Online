package com.ikea.automation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ikea.automation.entity.Extphysicalstores;
import com.ikea.automation.pojo.Ri_price_v;
import com.ikea.automation.utility.GenricConnection;
import com.ikea.automation.utility.IRWConnection;

@Repository
public class RIXDaoImpl implements RIXDao
{
	private static Logger logger = Logger.getLogger(RIXDaoImpl.class);	
	
	private Connection conn;
	private PreparedStatement pstmt,pstmt1;
	private ResultSet resultSet;
	
	/*static
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}
	
	@PostConstruct
	public void open() throws Exception
	{
		System.out.println("**************************************************opening connection for RangeTools******************************");
		conn =  DriverManager.getConnection(IRWConnection.RIXDBURL, IRWConnection.RIXUSERNAME, IRWConnection.RIXPASSWORD);
		
	}
	
	@PreDestroy
	public void close()
	{
		try
		{
			System.out.println("**************************************************Closing connection for Range Tools******************************");
			conn.close();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	@Override
	public List<Ri_price_v> getPricesFromRIX()
	{
		logger.debug("************************************Entering in getPricesFromRIX()************************************");
		
		List<Ri_price_v> PriceList = new ArrayList<Ri_price_v>();
		Ri_price_v obj=null;
		
		Date d = new Date(System.currentTimeMillis() - 3600*2000);
		DateFormat df = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");
		String pastTime = df.format(d);
		System.out.println("2hrs back time : "+pastTime);
		String currentTime = new SimpleDateFormat("dd-MMM-yy hh:mm:ss").format(new Date());
		System.out.println("Current TimeStaptime  "+currentTime);
		System.out.println(new Date(currentTime));
		try
		{
			
			conn = GenricConnection.open(IRWConnection.RIXDBURL, IRWConnection.RIXUSERNAME, IRWConnection.RIXPASSWORD);
			pstmt = conn.prepareStatement("SELECT * FROM ri_price_v WHERE UPD_DTIME >= SYSDATE-2/24 and price_type='RegularSalesUnitPrice' and class_unit_code in "
					+ "('SA','SG','EG','AE','KW','TW','HK','QA','SE','CA','FR','DE','CH','GB','AT','NL','IT','US','DK','FI','NO','ID','AU','LT','BH')");   //   "select * from ri_price_v where upd_dtime between to_date('"+pastTime+"','dd-mon-yy HH:MI:SS') and to_date('"+currentTime+"','dd-mon-yy HH:MI:SS')  and price_type='RegularSalesUnitPrice'");  //select * from ri_price_v where upd_dtime >=to_timestamp(06/15/2017 03:33:50) and upd_dtime <=to_timestamp(06/15/2017 05:33:50)");
			resultSet =   pstmt.executeQuery();
			while(resultSet.next())
			{	 
				obj = new Ri_price_v();
				obj.setCLASS_TYPE(resultSet.getString("CLASS_TYPE"));
				obj.setCLASS_UNIT_TYPE(resultSet.getString("CLASS_UNIT_TYPE"));
				obj.setCLASS_UNIT_CODE(resultSet.getString("CLASS_UNIT_CODE"));
				obj.setITEM_NO(resultSet.getString("ITEM_NO"));
				obj.setITEM_TYPE(resultSet.getString("ITEM_TYPE"));
				obj.setPRICE_TYPE(resultSet.getString("PRICE_TYPE"));
				obj.setCURRENCY_CODE(resultSet.getString("CURRENCY_CODE"));
				obj.setFROM_DTIME(resultSet.getTimestamp("FROM_DTIME"));
				obj.setTO_DTIME(resultSet.getTimestamp("TO_DTIME"));
				obj.setPRICE_INCL_TAX(resultSet.getInt("PRICE_INCL_TAX"));
				obj.setPRICE_EXCL_TAX(resultSet.getInt("PRICE_EXCL_TAX"));
				obj.setREASON_CODE(resultSet.getString("REASON_CODE"));
				obj.setTAX_INCL_OVERRIDE(resultSet.getString("TAX_INCL_OVERRIDE"));
				obj.setDEL_DTIME(resultSet.getTimestamp("DEL_DTIME"));
				obj.setUPD_DTIME(resultSet.getTimestamp("UPD_DTIME"));
				obj.setINS_DTIME(resultSet.getTimestamp("INS_DTIME"));
				
				PriceList.add(obj);
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			GenricConnection.closeConnection(conn);
		}
		System.out.println("size of data "+PriceList.size());
		logger.debug("************************************Exiting from getPricesFromRIX() ******************************************");
		
		return PriceList;
	}
	

}
