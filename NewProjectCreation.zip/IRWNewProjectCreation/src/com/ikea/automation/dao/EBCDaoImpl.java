package com.ikea.automation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ikea.automation.pojo.ConnectedItemPojo;
import com.ikea.automation.pojo.Ri_price_v;
import com.ikea.automation.utility.GenricConnection;
import com.ikea.automation.utility.IRWConnection;

@Repository
public class EBCDaoImpl implements EBCDao 
{
	
	private static Logger logger = Logger.getLogger(EBCDaoImpl.class);	
	public static final int CHUNK_SIZE = 900;
		
	@Autowired
	NewStoreDao newStoreDao;
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet resultSet;
	
	
	/*static
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}
	
	@PostConstruct
	public void open() throws Exception
	{
		logger.debug("************************************Entering in open()************************************");
		
		System.out.println("**************************************************opening connection for EBC******************************");
		conn =  DriverManager.getConnection(IRWConnection.EBCDBURL, IRWConnection.EBCUSERNAME, IRWConnection.EBCPASSWORD);
		
		logger.debug("************************************Exiting from open() ******************************************");
		
		
	}
	
	@PreDestroy
	public void close()
	{
		logger.debug("************************************Entering in close()************************************");
		
		try
		{
			
			System.out.println("**************************************************Closing connection for EBC******************************");
			conn.close();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("************************************Exiting from close() ******************************************");
		
	}*/
	
	
	@Override
	public List<ConnectedItemPojo> getAllConnectedItems(List<Ri_price_v> RixPriceList) 
	{
		logger.debug("************************************Entering in getAllConnectedItems()************************************");
		String query = createEBCQuery(RixPriceList);
		System.out.println(query);
		List<ConnectedItemPojo> connectedItemlist = new ArrayList<>();
		ConnectedItemPojo obj = null;
		try
		{
			conn = GenricConnection.open(IRWConnection.EBCDBURL, IRWConnection.EBCUSERNAME, IRWConnection.EBCPASSWORD);
			System.out.println(query);
			pstmt = conn.prepareStatement(query);
			resultSet =   pstmt.executeQuery();
			while(resultSet.next())
			{	 
				obj = new ConnectedItemPojo();
				obj.setITEM_NO(resultSet.getString("ITEM_NO"));
				obj.setITEM_TYPE(resultSet.getString("ITEM_TYPE"));
				connectedItemlist.add(obj);
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			GenricConnection.closeConnection(conn);
		}
		System.out.println("size of data Connected Items "+connectedItemlist.size());		
		
		
		logger.debug("************************************Exiting from getAllConnectedItems()************************************");
		return connectedItemlist;
	}

	
	public String createEBCQuery(List<Ri_price_v> RixPriceList)
	{
		String query = "SELECT ITEM_NO, ITEM_TYPE from EBCIRWRANGE01.CONNECTED_ITEMS_T where ITEM_NO in (";
		List<String> connectedItems = new ArrayList<>();
		for (Ri_price_v obj : RixPriceList)
		{
			connectedItems.add(obj.getITEM_NO());
		}
		String subStr = appendItems(connectedItems);
		
		
		
		return query + subStr;
		
	}
	
	private String appendItems(List<String> items) {
		String subStr = "";
		List<String> subList = null;
		int max = items.size();
		int loops = 0;
		if (max / CHUNK_SIZE > 0) {
			loops = max / CHUNK_SIZE;
			
			int iIdx = 0;
			int fIdx = CHUNK_SIZE;
			
			for (int x = 0; x < loops; x++) {
				subList = (List<String>) items.subList(iIdx, fIdx);
				
				for (String s : subList) {
					subStr += "'" + s + "',";
				}

				subStr = subStr.substring(0, subStr.length() - 1);
				subStr += ") OR ITEM_NO in (";

				//System.out.println("----------");
				iIdx = fIdx;
				fIdx = fIdx + CHUNK_SIZE;
			}
			if (max % CHUNK_SIZE != 0) {
				subList = (List<String>) items.subList(iIdx, max);
				for (String s : subList) {
					subStr += "'" + s + "',";
				}

				subStr = subStr.substring(0, subStr.length() - 1);
				subStr += ")";

			}
			
		} else {
			
			for (String s : items) {
				subStr += "'" + s + "',";
			}

			subStr = subStr.substring(0, subStr.length() - 1);
			subStr += ")";
			
		}
		
		return subStr;
	}
}
