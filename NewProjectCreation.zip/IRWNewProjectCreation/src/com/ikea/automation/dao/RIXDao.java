package com.ikea.automation.dao;

import java.util.List;

import com.ikea.automation.pojo.Ri_price_v;

public interface RIXDao
{
	List<Ri_price_v> getPricesFromRIX();
}
