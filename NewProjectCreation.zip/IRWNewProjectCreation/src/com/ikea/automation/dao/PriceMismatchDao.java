package com.ikea.automation.dao;

public class PriceMismatchDao
{

}
