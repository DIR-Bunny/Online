package com.ikea.automation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ikea.automation.entity.Extphysicalstores;
import com.ikea.automation.pojo.Language;
import com.ikea.automation.utility.IRWConnection;

@Repository
public class NewStoreDaoImpl implements NewStoreDao
{	
	private static Logger logger = Logger.getLogger(NewStoreDaoImpl.class);	
	
	private Connection conn;
	private PreparedStatement pstmt,pstmt1;
	private ResultSet resultSet;
	
	static
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}
	
	@PostConstruct
	public void open() throws Exception
	{
		logger.debug("************************************Entering in open()************************************");
		
		System.out.println("**************************************************opening connection for NewStore******************************");
		conn = DriverManager.getConnection(IRWConnection.DBURL,IRWConnection.USERNAME ,IRWConnection.PASSWORD);
		logger.debug("************************************Exiting from open() ******************************************");
		
	}
	
	@PreDestroy
	public void close()
	{
		logger.debug("************************************Entering in close()************************************");
		
		try
		{
			System.out.println("**************************************************Closing connection for NewStore******************************");
			conn.close();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("************************************Exiting from close() ******************************************");
		
	}
	
	@Override
	public List<Extphysicalstores> selectAllStores()
	{
		logger.debug("************************************Entering in selectAllStores()************************************");
		
		
		List<Extphysicalstores> storesDataList = new ArrayList<Extphysicalstores>();
		Extphysicalstores obj=null;
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement("select * from extphysicalstores");
			resultSet =   pstmt.executeQuery();
			while(resultSet.next())
			{
				obj = new Extphysicalstores();
				obj.setSTORE_NUMBER(resultSet.getString("STORE_NUMBER"));
				obj.setCOUNTRY_CODE(resultSet.getString("COUNTRY_CODE"));
				obj.setSTORE_NAME(resultSet.getString("STORE_NAME"));
				obj.setADDRESS1(resultSet.getString("ADDRESS1"));
				obj.setADDRESS2(resultSet.getString("ADDRESS2"));
				obj.setADDRESS3(resultSet.getString("ADDRESS3"));
				obj.setPHONE(resultSet.getString("PHONE"));
				obj.setFAX(resultSet.getString("FAX"));
				obj.setSTORE_TYPE(resultSet.getString("STORE_TYPE"));
				obj.setOPENING_DATE(resultSet.getDate("OPENING_DATE"));
				obj.setCLOSING_DATE(resultSet.getDate("CLOSING_DATE"));
				obj.setUPD_DATE(resultSet.getDate("UPD_DATE"));
				obj.setREG_DATE(resultSet.getDate("REG_DATE"));
				obj.setPUBLISHED(resultSet.getInt("PUBLISHED"));
				obj.setRETAIL_UNIT_CODE(resultSet.getString("RETAIL_UNIT_CODE"));
				obj.setOPTCOUNTER(resultSet.getString("OPTCOUNTER"));
				
				storesDataList.add(obj);
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from selectAllStores() ******************************************");
		
		return storesDataList;
	}

	@Override
	public List<String> getCountryCodes()
	{
		logger.debug("************************************Entering in getCountryCodes()************************************");
		
		List<String> CountryCodeList = new ArrayList<>();
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement("select DISTINCT(COUNTRY_CODE) from EXTPHYSICALSTORES");
			resultSet =   pstmt.executeQuery();
			System.out.println("I am getting country codes");
			while(resultSet.next())
			{
				CountryCodeList.add(resultSet.getString("COUNTRY_CODE"));
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				if(pstmt1!=null)
					pstmt1.close();
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from getCountryCodes() ******************************************");
		
		return CountryCodeList;
	}

	
	@Override
	public List<String> getStoreTypes()
	{
		logger.debug("************************************Entering in getStoreTypes()************************************");
		
		List<String> StoreTypeList = new ArrayList<>();
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement("select DISTINCT(STORE_TYPE) from EXTPHYSICALSTORES");
			resultSet =   pstmt.executeQuery();
			while(resultSet.next())
			{
				StoreTypeList.add(resultSet.getString("STORE_TYPE"));
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from getStoreTypes() ******************************************");
		
		return StoreTypeList;
	}

	@Override
	public List<String> getStoreNumbers(String storeNumber)
	{
		logger.debug("************************************Entering in getStoreNumbers()************************************");
		
		List<String> StoreNumbers = new ArrayList<>();
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement("select STORE_NUMBER from EXTPHYSICALSTORES where STORE_NUMBER like '%"+storeNumber+"%'");
			resultSet =   pstmt.executeQuery();
			while(resultSet.next())
			{
				StoreNumbers.add(resultSet.getString("STORE_NUMBER"));
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from getStoreNumbers() ******************************************");
		
		return StoreNumbers;
	}

	@Override
	public int saveNewStore(Extphysicalstores obj)
	{
		logger.debug("************************************Entering in saveNewStore()************************************");
		
		int status = 0;
		List<String> StoreNumbers = new ArrayList<>();
		String sql = "insert into EXTPHYSICALSTORES(STORE_NUMBER,COUNTRY_CODE,STORE_NAME,ADDRESS1,ADDRESS2,ADDRESS3,PHONE,FAX,STORE_TYPE,OPENING_DATE,UPD_DATE,REG_DATE,PUBLISHED) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getSTORE_NUMBER());
			pstmt.setString(2, obj.getCOUNTRY_CODE());
			pstmt.setString(3,obj.getSTORE_NAME() );
			pstmt.setString(4, ((obj.getADDRESS1() != null) ? obj.getADDRESS1() : ""));
			pstmt.setString(5, ((obj.getADDRESS2() != null) ? obj.getADDRESS2() : ""));
			pstmt.setString(6, ((obj.getADDRESS3() != null) ? obj.getADDRESS3() : ""));
			pstmt.setString(7, obj.getPHONE());
			pstmt.setString(8, obj.getFAX());
			pstmt.setString(9, obj.getSTORE_TYPE());
			pstmt.setDate(10, obj.getOPENING_DATE());
			pstmt.setDate(11, obj.getUPD_DATE());
			pstmt.setDate(12, obj.getREG_DATE());
			pstmt.setInt(13, obj.getPUBLISHED());
			status =   pstmt.executeUpdate();
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from saveNewStore() ******************************************");
		
		return status;
	}

	@Override
	public int[] CreateNewJob(Extphysicalstores obj)
	{
		logger.debug("************************************Entering in CreateNewJob()************************************");
		
		int updateJob_Status[] =null;
		/*int status = 0;
		Timestamp t = new Timestamp(System.currentTimeMillis());
		Insert into schconfig (SCCJOBREFNUM,SCCHOST,MEMBER_ID,STOREENT_ID,SCCRECDELAY,SCCRECATT,SCCPATHINFO,SCCQUERY,SCCSTART,SCCINTERVAL,SCCPRIORITY,SCCSEQUENCE,SCCACTIVE,SCCAPPTYPE,INTERFACENAME,OPTCOUNTER) values ((select Max(sccjobrefnum)+1 FROM schconfig),'ptirw731.ikeadt.com',-1000,0,0,0,'IkeamsLogisticsReplication',NULL,new Timestamp(System.currentTimeMillis()),1000,0,0,'A',NULL,NULL,NULL);
		String sql = "Insert into schconfig (SCCJOBREFNUM,SCCHOST,MEMBER_ID,STOREENT_ID,SCCRECDELAY,SCCRECATT,SCCPATHINFO,SCCQUERY,SCCSTART,SCCINTERVAL,SCCPRIORITY,SCCSEQUENCE,SCCACTIVE,SCCAPPTYPE,INTERFACENAME,OPTCOUNTER) values ((select Max(sccjobrefnum)+1 FROM schconfig),'ptirw731.ikeadt.com',-1000,0,0,0,'IkeamsLogisticsReplication',NULL,"+t+",1000,0,0,'A',NULL,NULL,NULL)";
		try
		{
			pstmt = conn.prepareStatement(sql);
			status =   pstmt.executeUpdate();
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally 
		{
			//close();
		}
		return status;*/
		DateFormat df = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
		String dateStr = df.format(obj.getUPD_DATE());
		System.out.println("Converted Date "+ dateStr);
		
		System.out.println("I am in createJob dao Date "+dateStr);
		
		int storeId = getStoreIdOnCountryCode(obj.getCOUNTRY_CODE());
		
		
		String statusDeactivate = "select SCCJOBREFNUM from schconfig where  SCCQUERY ='storeId="+storeId+"' and sccpathinfo ='IkeamsLogisticsReplication' and SCCACTIVE='A'";
		
		
		
		String updateAWOT_Sql ="Insert into SCHCONFIG (SCCJOBREFNUM,SCCHOST,MEMBER_ID,STOREENT_ID,SCCRECDELAY,SCCRECATT,SCCPATHINFO,SCCQUERY,SCCSTART,SCCINTERVAL,SCCPRIORITY,SCCSEQUENCE,SCCACTIVE,SCCAPPTYPE,INTERFACENAME) values ((select counter+1 from keys where tablename ='schconfig'),'ptirw711.ikeadt.com',-1000,"+storeId+",0,0,'IkeamsLogisticsReplication','storeId="+storeId+"',SYSDATE,0,5,0,'A','default','com.ibm.commerce.scheduler.commands.CheckForWorkCmd')";
		//String updateAWOT_Sql ="Insert into schconfig (SCCJOBREFNUM,SCCHOST,MEMBER_ID,STOREENT_ID,SCCRECDELAY,SCCRECATT,SCCPATHINFO,SCCQUERY,SCCSTART,SCCINTERVAL,SCCPRIORITY,SCCSEQUENCE,SCCACTIVE,SCCAPPTYPE,INTERFACENAME,OPTCOUNTER) values ((select Max(sccjobrefnum)+1 FROM schconfig),'ptirw731.ikeadt.com',-1000,"+obj.getSTORE_NUMBER()+",0,0,'IkeamsLogisticsReplication','storeId="+obj.getSTORE_NUMBER()+"',to_timestamp('"+dateStr+"'),0,0,0,'A',NULL,NULL,NULL)";
		
		String updateKeyRows = "update keys set counter=(select counter+1 from keys where tablename ='schconfig') where tablename ='schconfig'";
		
		String updateActiveTb_Sql ="insert into schactive (SCSINSTREFNUM,SCSJOBNBR,SCSATTLEFT,SCSPREFSTART,SCSSEQUENCE,SCSSTATE) values ((select Max(scsinstrefnum)+1 FROM schactive),(select SCCJOBREFNUM from schconfig where SCCPATHINFO='IkeamsLogisticsReplication' and STOREENT_ID="+storeId+" and SCCACTIVE='A'),0,SYSDATE,0,'W')";
		//String updateActiveTb_Sql ="Insert into schactive (SCSINSTREFNUM,SCSJOBNBR,SCSACTLSTART,SCSATTLEFT,SCSEND,SCSINSTRECOV,SCSPREFSTART,SCSQUEUE,SCSRESULT,SCSSEQUENCE,SCSSTATE,SCSPRIORITY,OPTCOUNTER) values ((select Max(scsinstrefnum)+1 FROM schactive),(select max(sccjobrefnum) FROM schconfig),null,0,null,null,to_timestamp('"+dateStr+"'),'','',0,'W',5,0)";
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement(statusDeactivate);
			resultSet = pstmt.executeQuery();
			List<String> jobNumbersList = new ArrayList<>();
			
			System.out.println("Select active jobs query : "+ statusDeactivate);
			while(resultSet.next())
			{
				jobNumbersList.add(resultSet.getString("SCCJOBREFNUM"));
			}
			
			System.out.println("Job List Numbers : "+jobNumbersList);
			
			if(jobNumbersList.size() > 0)
			{
				char[] markers = new char[jobNumbersList.size() * 2 - 1];
				for (int i = 0; i < markers.length; i++)
					markers[i] = ((i & 1) == 0 ? '?' : ',');
				int index = 1;
				String deactivateJobs = "update SCHCONFIG set sccactive='D' where SCCJOBREFNUM IN (" + new String(markers) + ")";
				
				System.out.println("Deactivate active jobs query : "+ deactivateJobs);
				
				pstmt1 = conn.prepareStatement(deactivateJobs);

				for (String value : jobNumbersList)
					pstmt1.setString(index++, value);

				System.out.println("Status of deactivation of jobs "+pstmt1.executeUpdate());
				
			}
			
			System.out.println(updateAWOT_Sql);
			System.out.println(updateActiveTb_Sql);
			conn.setAutoCommit(false);
			Statement sqlStatement = conn.createStatement();
			sqlStatement.addBatch(updateAWOT_Sql);
			sqlStatement.addBatch(updateKeyRows);
			sqlStatement.addBatch(updateActiveTb_Sql);
			updateJob_Status = sqlStatement.executeBatch();
			
			for (int status : updateJob_Status)
			{
				System.out.println(" after batch execution Status "+status);
			}
		
			
			if(updateJob_Status != null)
			{
				String insertCacheIVL = "insert into cacheivl(TEMPLATE,DATAID,INSERTTIME,OPTCOUNTER) values(NULL,'se.ikea.ms.commerce.family.commands.task.IrwReadLocalStoresCmdImpl:getCommandContext="+storeId+":getCommandContext="+obj.getLANGUAGE_ID()+"',SYSDATE,0)";
				
				pstmt1 = conn.prepareStatement(insertCacheIVL);
				
				int insertCacheIVLStatus  = pstmt1.executeUpdate();
				
				System.out.println("Insert Query CacheIVL ::"+insertCacheIVL);
				
				System.out.println("Insertion status of CacheIVL "+insertCacheIVLStatus);
				
			}
			
		conn.commit();
		}
		catch(SQLException ex)
		{
			//sqlcon.rollback();
			ex.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				if(pstmt1!=null)
					pstmt1.close();
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from CreateNewJob() ******************************************");
		
		return updateJob_Status;
	}

	public int getStoreIdOnCountryCode(String country)
	{
		logger.debug("************************************Entering in getStoreIdOnCountryCode()************************************");
		
		int storeId = 0;
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement("select STOREENT_ID from EXTSTOREENT where CLASS_UNIT_CODE = ?");
			pstmt.setString(1, country);
			resultSet =   pstmt.executeQuery();
			storeId = (resultSet.next()) ? resultSet.getInt("STOREENT_ID"):0;
			//System.out.println("I am getting StoreID from country code "+country+"  :: "+storeId);
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from getStoreIdOnCountryCode() ******************************************");
		
		return storeId;
	}
	
	@Override
	public String getMarketName(int LANGUAGE_ID)
	{
		logger.debug("************************************Entering in getMarketName()************************************");
		
		String  LOCALENAME = null;
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement("select LOCALENAME from LANGUAGE where LANGUAGE_ID= ?");
			pstmt.setInt(1, LANGUAGE_ID);
			resultSet =   pstmt.executeQuery();
			LOCALENAME = (resultSet.next()) ? resultSet.getString("LOCALENAME"):null;
			System.out.println("I am getting Market Name from LanguageId "+LANGUAGE_ID+"  :: "+LOCALENAME);
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		logger.debug("************************************Exiting from getMarketName() ******************************************");
		
		return LOCALENAME;
	}

	@Override
	public List<Language> getLanguagesOnCountry(String countryCode)
	{
		logger.debug("************************************Entering in getLanguagesOnCountry()************************************");
		
		String sql = "select * from language where COUNTRY= ? ";
		List<Language> LanguageCodeList = new ArrayList<>();
		Language lang =  null;
		try
		{
			//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,countryCode.toUpperCase());
			resultSet =   pstmt.executeQuery();
			//System.out.println("I am getting country codes");
			while(resultSet.next())
			{
				lang = new Language();
				lang.setLANGUAGE_ID(resultSet.getInt("LANGUAGE_ID"));
				lang.setLANGUAGE(resultSet.getString("LANGUAGE"));
				lang.setCOUNTRY(resultSet.getString("COUNTRY"));
				
				LanguageCodeList.add(lang);
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//close();
			//GenricConnection.closeConnection(conn);
		}
		System.out.println("Language Code List "+LanguageCodeList);
		logger.debug("************************************Exiting from getLanguagesOnCountry() ******************************************");
		
		return LanguageCodeList;
	}

	@Override
	public boolean updateStockCheck(Extphysicalstores obj)
	{
		logger.debug("************************************Entering in updateStockCheck()************************************");
		
		boolean status = false;
		String sql = "update EXTLOCALSTORES set stockcheck = ? where storenumber = ?";
		if(obj.getSTOCKCHECK()!=0)
		{
			try
			{
				//conn = GenricConnection.open(IRWConnection.DBURL, IRWConnection.USERNAME, IRWConnection.PASSWORD);
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, obj.getSTOCKCHECK());
				pstmt.setString(2, obj.getSTORE_NUMBER());
				System.out.println(sql);
				status = (pstmt.executeUpdate() > 0 ) ? true : false;
				System.out.println("Stock Check Status "+status);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			} catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally 
			{
				try
				{
					if(pstmt!=null)
						pstmt.close();
					
					if(resultSet!=null)
						resultSet.close();
				} catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//close();
				//GenricConnection.closeConnection(conn);
			}
		}
		else
		{
			
		}
		logger.debug("************************************Exiting from updateStockCheck() ******************************************");
		
		return status;
	}
	
	
	
	
	
}
