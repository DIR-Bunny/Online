package com.ikea.automation.dao;

import java.io.InputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;

import com.ikea.automation.pojo.ShowStop;

public interface showStopDao
{
	public Workbook getWorkbook(InputStream inputStream, String excelFileName) throws Exception ;
	
	public Object getCellValue(Cell cell);
	
	//public void SaveUsers(List<User> userList);
	public boolean updateShowStopUpload(ShowStop obj);
}
