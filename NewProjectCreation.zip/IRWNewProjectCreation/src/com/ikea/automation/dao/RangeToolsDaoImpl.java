package com.ikea.automation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.PriceMarketDetails;
import com.ikea.automation.pojo.Ri_price_v;
import com.ikea.automation.utility.GenricConnection;
import com.ikea.automation.utility.IRWConnection;

@Repository
public class RangeToolsDaoImpl implements RangeToolsDao
{
	private static Logger logger = Logger.getLogger(RangeToolsDaoImpl.class);	
	
	private Connection conn;
	private PreparedStatement pstmt,pstmt1;
	private ResultSet resultSet;
	
	static
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}
	
	@PostConstruct
	public void open() throws Exception
	{
		logger.debug("************************************Entering in open()************************************");
		
		System.out.println("**************************************************opening connection for RangeTools******************************");
		conn =  DriverManager.getConnection(IRWConnection.RangeToolsDBURL, IRWConnection.RangeToolsUSERNAME, IRWConnection.RangeToolsPASSWORD);
		logger.debug("************************************Exiting from open() ******************************************");
		
		
	}
	
	@PreDestroy
	public void close()
	{
		logger.debug("************************************Entering in close()************************************");
		
		try
		{
			System.out.println("**************************************************Closing connection for Range Tools******************************");
			conn.close();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("************************************Exiting from close() ******************************************");
		
	}
	
	@Override
	public boolean InsertIntoIRWRIXPrice(IRW_RIX_PRICE_DET obj)
	{
		logger.debug("************************************Entering in InsertIntoIRWRIXPrice()************************************");
		
		int Status = 0;
			System.err.println("In InsertIntoIRWRIXPrice  : "+obj);
			/*IRW_RIX_PRICE_DET Robj = new IRW_RIX_PRICE_DET();
			Robj.setMARKETNAME(obj.getCLASS_UNIT_CODE());
			Robj.setITEM_NO(obj.getITEM_NO());
			Robj.setITEM_TYPE(obj.getITEM_TYPE());
			Robj.setPRICE_TYPE(obj.getPRICE_TYPE());
			Robj.setFROM_DTIME(obj.getFROM_DTIME());
			Robj.setEND_DTIME(obj.getTO_DTIME());
			Robj.setPRICE_INCL_TAX(obj.getPRICE_EXCL_TAX());
			Robj.setREASON_CODE(obj.getREASON_CODE());
			Robj.setRIX_STATUS("YES");
			Robj.setRIX_UPDATED_DATE(obj.getUPD_DTIME());*/
			
			try
			{
				String insertToIRPT ="INSERT INTO IRW_RIX_PRICE_DET(MARKETNAME,ITEM_NO,ITEM_TYPE ,PRICE_TYPE,FROM_DTIME,END_DTIME,PRICE_INCL_TAX,REASON_CODE,RIX_STATUS,IRW_STATUS,RIX_UPDATED_DATE,INSERTED_DATE) VALUES( ?, ?, ?, ?,?, ?, ?, ?, ?, ?,?, sysdate)";
				//conn = GenricConnection.open(IRWConnection.RangeToolsDBURL, IRWConnection.RangeToolsUSERNAME, IRWConnection.RangeToolsPASSWORD);
				pstmt = conn.prepareStatement(insertToIRPT);
				pstmt.setString(1,obj.getMARKETNAME());
				pstmt.setString(2,obj.getITEM_NO());
				pstmt.setString(3,obj.getITEM_TYPE());
				pstmt.setString(4, obj.getPRICE_TYPE());
				pstmt.setDate(5, new java.sql.Date(obj.getFROM_DTIME().getTime()));
				pstmt.setDate(6, new java.sql.Date(obj.getEND_DTIME().getTime()));
				if(Integer.valueOf(String.valueOf(obj.getPRICE_INCL_TAX()).split("\\.")[1]) > 0)
					pstmt.setDouble(7,obj.getPRICE_INCL_TAX() );
				else
					pstmt.setInt(7, (int)obj.getPRICE_INCL_TAX());
				pstmt.setString(8,obj.getREASON_CODE() );
				pstmt.setString(9, obj.getRIX_STATUS());
				pstmt.setString(10,obj.getIRW_STATUS() );
				pstmt.setDate(11, new java.sql.Date(obj.getRIX_UPDATED_DATE().getTime()));
				
				
				Status =   pstmt.executeUpdate();
				
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			finally 
			{
				try
				{
					if(pstmt!=null)
						pstmt.close();
					
					if(resultSet!=null)
						resultSet.close();
				} catch (SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//GenricConnection.closeConnection(conn);
			}
			logger.debug("************************************Exiting from InsertIntoIRWRIXPrice() ******************************************");
			
			return (Status > 0) ?true :false;
			
	}

	@Override
	public List<IRW_RIX_PRICE_DET> getAllNotReflectedPrices()
	{
		logger.debug("************************************Entering in getAllNotReflectedPrices()************************************");
		
		List<IRW_RIX_PRICE_DET> NotMathcingPriceList = new ArrayList<>();
		
		try
		{
			String SelectFromIRPT ="select MARKETNAME,ITEM_TYPE,ITEM_NO,PRICE_INCL_TAX from IRW_RIX_PRICE_DET where IRW_status ='NO'";
			//conn = GenricConnection.open(IRWConnection.RangeToolsDBURL, IRWConnection.RangeToolsUSERNAME, IRWConnection.RangeToolsPASSWORD);
			pstmt = conn.prepareStatement(SelectFromIRPT);
			
			resultSet =   pstmt.executeQuery();
			while(resultSet.next())
			{
				IRW_RIX_PRICE_DET obj = new IRW_RIX_PRICE_DET();
				obj.setMARKETNAME(resultSet.getString("MARKETNAME"));
				obj.setITEM_TYPE(resultSet.getString("ITEM_TYPE"));
				obj.setITEM_NO(resultSet.getString("ITEM_NO"));
				obj.setPRICE_INCL_TAX(resultSet.getInt("PRICE_INCL_TAX"));
				NotMathcingPriceList.add(obj);
			}
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//GenricConnection.closeConnection(conn);
		}
		System.err.println("All Not Matching price"+NotMathcingPriceList);	
		
		logger.debug("************************************Exiting from getAllNotReflectedPrices() ******************************************");
		
		return NotMathcingPriceList;
	}

	@Override
	public boolean UpdateIRWStatus(List<IRW_RIX_PRICE_DET> updatedList)
	{
		logger.debug("************************************Entering in UpdateIRWStatus()************************************");
		
		System.out.println("Update IRPT "+updatedList.size());
		int status = 0;
		try
		{
			
			//conn = GenricConnection.open(IRWConnection.RangeToolsDBURL, IRWConnection.RangeToolsUSERNAME, IRWConnection.RangeToolsPASSWORD);
			for (IRW_RIX_PRICE_DET IRPT : updatedList)
			{
				String UpdateIRPT ="UPDATE IRW_RIX_PRICE_DET set IRW_STATUS='YES' where MARKETNAME ='"+IRPT.getMARKETNAME()+"' and ITEM_NO= '"+IRPT.getITEM_NO()+"' and PRICE_INCL_TAX = "+IRPT.getPRICE_INCL_TAX()+"";
				//conn.setAutoCommit(false);
				System.out.println("Update Query  ::  "+UpdateIRPT);
				pstmt = conn.prepareStatement(UpdateIRPT);
				/*pstmt.setString(1, IRPT.getMARKETNAME());
				pstmt.setString(2, IRPT.getITEM_NO());
				pstmt.setInt(3, IRPT.getPRICE_INCL_TAX());*/
				
				int temp  =   pstmt.executeUpdate();
				System.err.println("Update Status for "+IRPT.getITEM_NO()+" is :: "+temp);
				status += (temp>0) ? 1:0;
			}
			
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//GenricConnection.closeConnection(conn);
		}
		System.out.println("Status : "+status+" Size : "+updatedList.size());
		logger.debug("************************************Exiting from UpdateIRWStatus() ******************************************");
		
		return (status == updatedList.size()) ? true : false;
	}

	@Override
	public List<PriceMarketDetails> getAllRecordsOnMarketpercentage()
	{
		logger.debug("************************************Entering in getAllRecordsOnMarketpercentage()************************************");
		
		String getREcordsPercentage = "SELECT T.DATE_STR, T.MARKETNAME,SUM(RIX_STATUS_VALUE) AS RIX_VALUE,SUM(IRW_STATUS_VALUE) AS IRW_VALUE,COUNT(*)AS TOTAL, ROUND(SUM(RIX_STATUS_VALUE)/COUNT(*) * 100,0) AS RIX_PERC,ROUND( SUM(IRW_STATUS_VALUE)/COUNT(*) * 100,0 )AS IRW_PERC "+ 
										"FROM(SELECT CASE WHEN RIX_STATUS = 'YES' THEN 1 ELSE 0 END AS RIX_STATUS_VALUE, CASE WHEN IRW_STATUS = 'YES' THEN 1 ELSE 0 END AS IRW_STATUS_VALUE,IRPD.*,TO_CHAR(IRPD.INSERTED_DATE, 'dd-mm-yyyy') AS DATE_STR FROM IRW_RIX_PRICE_DET IRPD) T "+
											"where T.INSERTED_DATE like sysdate GROUP BY T.DATE_STR, T.MARKETNAME";

		List<PriceMarketDetails> AllPercentageList = new ArrayList<>();
		
		try
		{
			//conn = GenricConnection.open(IRWConnection.RangeToolsDBURL, IRWConnection.RangeToolsUSERNAME, IRWConnection.RangeToolsPASSWORD);
			pstmt = conn.prepareStatement(getREcordsPercentage);
			
			resultSet =   pstmt.executeQuery();
			pstmt.clearParameters();
			while(resultSet.next())
			{
				PriceMarketDetails obj = new PriceMarketDetails();
				obj.setMarketName(resultSet.getString("MARKETNAME"));
				obj.setRIXPrice(resultSet.getInt("RIX_PERC"));
				obj.setIRWPrice(resultSet.getInt("IRW_PERC"));
				AllPercentageList.add(obj);
			}
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//GenricConnection.closeConnection(conn);
		}
		System.err.println("All Records with percentage  "+AllPercentageList);	
		logger.debug("************************************Exiting from getAllRecordsOnMarketpercentage() ******************************************");
		
		return AllPercentageList;
	}

	@Override
	public List<IRW_RIX_PRICE_DET> getRecordsOnMarket(String marketName)
	{
		logger.debug("************************************Entering in getRecordsOnMarket()************************************");
		
		String getRecordsOnMarket = "select MARKETNAME,ITEM_NO,PRICE_INCL_TAX,RIX_STATUS,IRW_STATUS from IRW_RIX_PRICE_DET where INSERTED_DATE like sysdate"; /*WHERE MARKETNAME=?";*/
		
		if(!marketName.equalsIgnoreCase("ALL")) 
			getRecordsOnMarket+=" and MARKETNAME=?";
		
		List<IRW_RIX_PRICE_DET> RecordsOnMarket = new ArrayList<>();
		System.err.println(getRecordsOnMarket);
		try
		{
			//conn = GenricConnection.open(IRWConnection.RangeToolsDBURL, IRWConnection.RangeToolsUSERNAME, IRWConnection.RangeToolsPASSWORD);
			pstmt = conn.prepareStatement(getRecordsOnMarket);
			if(!marketName.equalsIgnoreCase("ALL")) 
				pstmt.setString(1, marketName);
			resultSet =   pstmt.executeQuery();
			pstmt.clearParameters();
			while(resultSet.next())
			{
				IRW_RIX_PRICE_DET obj = new IRW_RIX_PRICE_DET();
				obj.setMARKETNAME(resultSet.getString("MARKETNAME"));
				obj.setITEM_NO(resultSet.getString("ITEM_NO"));
				obj.setPRICE_INCL_TAX(resultSet.getInt("PRICE_INCL_TAX"));
				obj.setRIX_STATUS(resultSet.getString("RIX_STATUS"));
				obj.setIRW_STATUS(resultSet.getString("IRW_STATUS"));
				RecordsOnMarket.add(obj);
			}
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//GenricConnection.closeConnection(conn);
		}
		System.err.println("All Records on Mrket "+marketName+" are :: "+RecordsOnMarket);	
		logger.debug("************************************Exiting from getRecordsOnMarket() ******************************************");
		
		return RecordsOnMarket;
	
	}
	
	
	
	
}
