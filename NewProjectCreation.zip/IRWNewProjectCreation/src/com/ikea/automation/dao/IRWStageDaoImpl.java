package com.ikea.automation.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.persistence.criteria.CriteriaBuilder.In;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.Ri_price_v;
import com.ikea.automation.utility.GenricConnection;
import com.ikea.automation.utility.IRWConnection;

@Repository
public class IRWStageDaoImpl implements IRWStageDao
{
	private static Logger logger = Logger.getLogger(IRWStageDaoImpl.class);	
	
	
	@Autowired
	NewStoreDao newStoreDao;
	
	private Connection conn;
	private PreparedStatement pstmt,pstmt1,pstmt2;
	private ResultSet resultSet;
	
	
	static
	{
		try
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
	}
	
	@PostConstruct
	public void open() throws Exception
	{
		logger.debug("************************************Entering in open()************************************");
		
		System.out.println("**************************************************opening connection for IRW Stage******************************");
		conn =  DriverManager.getConnection(IRWConnection.IRWStageDBURL, IRWConnection.IRWStageUSERNAME, IRWConnection.IRWStagePASSWORD);
		
		logger.debug("************************************Exiting from open() ******************************************");
		
		
	}
	
	@PreDestroy
	public void close()
	{
		logger.debug("************************************Entering in close()************************************");
		
		try
		{
			
			System.out.println("**************************************************Closing connection for IRW Stage******************************");
			conn.close();
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("************************************Exiting from close() ******************************************");
		
	}
	
	
	
	@Override
	public boolean PriceStatusInIRW(Ri_price_v obj)
	{
		logger.debug("************************************Entering in PriceStatusInIRW()************************************");
		
		boolean returnStatus = false;
		int CatentryId=0,OfferPrice=0;
		List<Integer> OfferId = new ArrayList<>();
		int storeId = newStoreDao.getStoreIdOnCountryCode(obj.getCLASS_UNIT_CODE());
		String getCatentrySQL ="select CATENTRY_ID from CATENTRY where PARTNUMBER=?";
		String getOfferPriceSQL = "select PRICE from OFFERPRICE where OFFER_ID=?";
		
		/*DateFormat df = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
		String STARTDATE = df.format(obj.getFROM_DTIME());
		String ENDDATE = df.format(obj.getTO_DTIME());
		String CurrentDate = new SimpleDateFormat("dd-MMM-yy").format(new Date());
		
		System.out.println("Start Date  : "+STARTDATE+" END time : "+ENDDATE);*/
		
	/*	String currentTime = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a").format(new Date());
		System.out.println("Current TimeStaptime  "+currentTime);
		System.out.println(new Date(currentTime));*/
		try
		{
			//conn = GenricConnection.open(IRWConnection.IRWStageDBURL, IRWConnection.IRWStageUSERNAME, IRWConnection.IRWStagePASSWORD);
			pstmt = conn.prepareStatement(getCatentrySQL);
			String partNumber = (obj.getITEM_TYPE().toUpperCase().equals("SPR")) ?  "S"+obj.getITEM_NO() : obj.getITEM_NO();
			System.out.println("Part Number :: "+partNumber+" Item Type :: "+obj.getITEM_TYPE()+"Market Name :: "+obj.getCLASS_UNIT_CODE());
			pstmt.setString(1, partNumber);
			resultSet =   pstmt.executeQuery();
			//System.out.println("Inside update "+obj.getITEM_NO()+"  "+obj.getCLASS_UNIT_CODE()+"  "+obj.getPRICE_INCL_TAX());
			while(resultSet.next())
			{
				CatentryId = resultSet.getInt("CATENTRY_ID");
			}
			if(CatentryId != 0)
			{
				String getOfferIdSQL = "select * from offer where CATENTRY_ID="+CatentryId+" and TRADEPOSCN_ID="+storeId+" and published=1"; // and LASTUPDATE like '%14-JUN-17%'";  // and STARTDATE= to_date( '"+STARTDATE+"' ,'dd-mon-yy HH:MI:SS a') and ENDDATE= to_date( '"+ENDDATE+"' ,'dd-mon-yy HH:MI: aSS')";
				
				System.err.println("Cateentry for "+obj.getITEM_NO()+" : "+CatentryId);
				pstmt1 = conn.prepareStatement(getOfferIdSQL);
				/*pstmt1.setInt(1, CatentryId);
				pstmt1.setInt(2, storeId);
				pstmt1.setString(3, CurrentDate);*/
				/*pstmt1.setDate(4,STARTDATE);
				pstmt1.setDate(5,ENDDATE);*/
				resultSet =   pstmt1.executeQuery();
				/*for (int i = 1; i <=  resultSet.getMetaData().getColumnCount(); i++ ) {
					  System.err.println("Result set offerID "+resultSet.getMetaData().getColumnName(i));
					}*/
				while(resultSet.next())
				{
					//System.err.println("Result set offerID "+resultSet.getMetaData().getColumnLabel(1));
					OfferId.add(resultSet.getInt("OFFER_ID"));
				}
				if(!OfferId.isEmpty())
				{
					for (Integer offerID : OfferId)
					{
						System.err.println("OfferID for "+obj.getITEM_NO()+" : "+offerID);
						pstmt2 = conn.prepareStatement(getOfferPriceSQL);
						pstmt2.setInt(1, offerID);
						resultSet = pstmt2.executeQuery();
						while(resultSet.next())
						{
							OfferPrice = resultSet.getInt("PRICE");
						}
						
						System.out.println("");
						if(Integer.valueOf(String.valueOf(obj.getPRICE_INCL_TAX()).split("\\.")[1]) > 0)
						{
							System.err.println("OfferPrice for "+obj.getITEM_NO()+" : "+OfferPrice+" from rix "+obj.getPRICE_INCL_TAX());
							
							if((obj.getPRICE_INCL_TAX() == OfferPrice) ?  true :false)
							{
								return true;
							}
								
						}
						else
						{
							System.err.println("OfferPrice for "+obj.getITEM_NO()+" : "+OfferPrice+" from rix "+(int)obj.getPRICE_INCL_TAX());
							
							if(((int)obj.getPRICE_INCL_TAX() == OfferPrice) ?  true :false)
							{
								return true;
							}
						}
						
					}
					
				}
				else
				{
					return false;
				}
				System.out.println("");
			}
			else
			{
				return false;
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally 
		{
			try
			{
				if(pstmt!=null)
					pstmt.close();
				if(pstmt1!=null)
					pstmt1.close();
				if(pstmt2!=null)
					pstmt2.close();
				if(resultSet!=null)
					resultSet.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//GenricConnection.closeConnection(conn);
		}
		
		logger.debug("************************************Exiting from PriceStatusInIRW() ******************************************");
		
		return returnStatus;
	}

	@Override
	public List<IRW_RIX_PRICE_DET> CheckPriceUpdated(List<IRW_RIX_PRICE_DET> notUpdatedPriceList)
	{
		logger.debug("************************************Entering in CheckPriceUpdated()************************************");
		
		List<IRW_RIX_PRICE_DET> UpdatedListofPrice = new ArrayList<>();
		for (IRW_RIX_PRICE_DET obj : notUpdatedPriceList)
		{
			Ri_price_v RixObj = new Ri_price_v();
			RixObj.setCLASS_UNIT_CODE(obj.getMARKETNAME());
			RixObj.setITEM_TYPE(obj.getITEM_TYPE());
			RixObj.setITEM_NO(obj.getITEM_NO());
			RixObj.setPRICE_INCL_TAX(obj.getPRICE_INCL_TAX());
			if(PriceStatusInIRW(RixObj))
				UpdatedListofPrice.add(obj);
			
		}
		System.err.println("Updated Price List : "+UpdatedListofPrice.size());
		logger.debug("************************************Exiting from CheckPriceUpdated() ******************************************");
		
		return UpdatedListofPrice;
	}
	
	
	
	

}
