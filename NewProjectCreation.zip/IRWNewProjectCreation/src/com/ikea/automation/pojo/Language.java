package com.ikea.automation.pojo;

public class Language
{
	private int LANGUAGE_ID;
	private String LANGUAGE;
	private String COUNTRY;
	public Language()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Language(int lANGUAGE_ID, String lANGUAGE, String cOUNTRY)
	{
		super();
		LANGUAGE_ID = lANGUAGE_ID;
		LANGUAGE = lANGUAGE;
		COUNTRY = cOUNTRY;
	}
	public int getLANGUAGE_ID()
	{
		return LANGUAGE_ID;
	}
	public void setLANGUAGE_ID(int lANGUAGE_ID)
	{
		LANGUAGE_ID = lANGUAGE_ID;
	}
	public String getLANGUAGE()
	{
		return LANGUAGE;
	}
	public void setLANGUAGE(String lANGUAGE)
	{
		LANGUAGE = lANGUAGE;
	}
	public String getCOUNTRY()
	{
		return COUNTRY;
	}
	public void setCOUNTRY(String cOUNTRY)
	{
		COUNTRY = cOUNTRY;
	}
	@Override
	public String toString()
	{
		return "Language [LANGUAGE_ID=" + LANGUAGE_ID + ", LANGUAGE=" + LANGUAGE + ", COUNTRY=" + COUNTRY + "]";
	}
	
}
