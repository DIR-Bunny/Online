package com.ikea.automation.pojo;

public class ConnectedItemPojo 
{
	private String ITEM_NO;
	private String ITEM_TYPE;
	public ConnectedItemPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ConnectedItemPojo(String iTEM_NO, String iTEM_TYPE) {
		super();
		ITEM_NO = iTEM_NO;
		ITEM_TYPE = iTEM_TYPE;
	}
	public String getITEM_NO() {
		return ITEM_NO;
	}
	public void setITEM_NO(String iTEM_NO) {
		ITEM_NO = iTEM_NO;
	}
	public String getITEM_TYPE() {
		return ITEM_TYPE;
	}
	public void setITEM_TYPE(String iTEM_TYPE) {
		ITEM_TYPE = iTEM_TYPE;
	}
	@Override
	public String toString() {
		return "ConnectedItemPojo [ITEM_NO=" + ITEM_NO + ", ITEM_TYPE=" + ITEM_TYPE + "]";
	}
	
	
}
