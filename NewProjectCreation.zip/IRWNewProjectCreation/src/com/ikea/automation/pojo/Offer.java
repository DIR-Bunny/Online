package com.ikea.automation.pojo;

import java.util.Date;

public class Offer
{
	private int OFFER_ID;      
	private Date STARTDATE; 
	private int TRADEPOSCN_ID;       
	private int CATENTRY_ID;       
	private Date ENDDATE;
	private int PRECEDENCE;      
	private int PUBLISHED;  
	private Date LASTUPDATE; 
	private int MINIMUMQUANTITY;     
	private String QTYUNIT_ID;
	private int MAXIMUMQUANTITY;     
	private String FIELD1; 
	private String FIELD2;  
	private int FLAGS;   
	private int IDENTIFIER;      
	private String OID; 
	private int OPTCOUNTER;
	public Offer()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Offer(int oFFER_ID, Date sTARTDATE, int tRADEPOSCN_ID, int cATENTRY_ID, Date eNDDATE, int pRECEDENCE,
			int pUBLISHED, Date lASTUPDATE, int mINIMUMQUANTITY, String qTYUNIT_ID, int mAXIMUMQUANTITY, String fIELD1,
			String fIELD2, int fLAGS, int iDENTIFIER, String oID, int oPTCOUNTER)
	{
		super();
		OFFER_ID = oFFER_ID;
		STARTDATE = sTARTDATE;
		TRADEPOSCN_ID = tRADEPOSCN_ID;
		CATENTRY_ID = cATENTRY_ID;
		ENDDATE = eNDDATE;
		PRECEDENCE = pRECEDENCE;
		PUBLISHED = pUBLISHED;
		LASTUPDATE = lASTUPDATE;
		MINIMUMQUANTITY = mINIMUMQUANTITY;
		QTYUNIT_ID = qTYUNIT_ID;
		MAXIMUMQUANTITY = mAXIMUMQUANTITY;
		FIELD1 = fIELD1;
		FIELD2 = fIELD2;
		FLAGS = fLAGS;
		IDENTIFIER = iDENTIFIER;
		OID = oID;
		OPTCOUNTER = oPTCOUNTER;
	}
	public int getOFFER_ID()
	{
		return OFFER_ID;
	}
	public void setOFFER_ID(int oFFER_ID)
	{
		OFFER_ID = oFFER_ID;
	}
	public Date getSTARTDATE()
	{
		return STARTDATE;
	}
	public void setSTARTDATE(Date sTARTDATE)
	{
		STARTDATE = sTARTDATE;
	}
	public int getTRADEPOSCN_ID()
	{
		return TRADEPOSCN_ID;
	}
	public void setTRADEPOSCN_ID(int tRADEPOSCN_ID)
	{
		TRADEPOSCN_ID = tRADEPOSCN_ID;
	}
	public int getCATENTRY_ID()
	{
		return CATENTRY_ID;
	}
	public void setCATENTRY_ID(int cATENTRY_ID)
	{
		CATENTRY_ID = cATENTRY_ID;
	}
	public Date getENDDATE()
	{
		return ENDDATE;
	}
	public void setENDDATE(Date eNDDATE)
	{
		ENDDATE = eNDDATE;
	}
	public int getPRECEDENCE()
	{
		return PRECEDENCE;
	}
	public void setPRECEDENCE(int pRECEDENCE)
	{
		PRECEDENCE = pRECEDENCE;
	}
	public int getPUBLISHED()
	{
		return PUBLISHED;
	}
	public void setPUBLISHED(int pUBLISHED)
	{
		PUBLISHED = pUBLISHED;
	}
	public Date getLASTUPDATE()
	{
		return LASTUPDATE;
	}
	public void setLASTUPDATE(Date lASTUPDATE)
	{
		LASTUPDATE = lASTUPDATE;
	}
	public int getMINIMUMQUANTITY()
	{
		return MINIMUMQUANTITY;
	}
	public void setMINIMUMQUANTITY(int mINIMUMQUANTITY)
	{
		MINIMUMQUANTITY = mINIMUMQUANTITY;
	}
	public String getQTYUNIT_ID()
	{
		return QTYUNIT_ID;
	}
	public void setQTYUNIT_ID(String qTYUNIT_ID)
	{
		QTYUNIT_ID = qTYUNIT_ID;
	}
	public int getMAXIMUMQUANTITY()
	{
		return MAXIMUMQUANTITY;
	}
	public void setMAXIMUMQUANTITY(int mAXIMUMQUANTITY)
	{
		MAXIMUMQUANTITY = mAXIMUMQUANTITY;
	}
	public String getFIELD1()
	{
		return FIELD1;
	}
	public void setFIELD1(String fIELD1)
	{
		FIELD1 = fIELD1;
	}
	public String getFIELD2()
	{
		return FIELD2;
	}
	public void setFIELD2(String fIELD2)
	{
		FIELD2 = fIELD2;
	}
	public int getFLAGS()
	{
		return FLAGS;
	}
	public void setFLAGS(int fLAGS)
	{
		FLAGS = fLAGS;
	}
	public int getIDENTIFIER()
	{
		return IDENTIFIER;
	}
	public void setIDENTIFIER(int iDENTIFIER)
	{
		IDENTIFIER = iDENTIFIER;
	}
	public String getOID()
	{
		return OID;
	}
	public void setOID(String oID)
	{
		OID = oID;
	}
	public int getOPTCOUNTER()
	{
		return OPTCOUNTER;
	}
	public void setOPTCOUNTER(int oPTCOUNTER)
	{
		OPTCOUNTER = oPTCOUNTER;
	}
	@Override
	public String toString()
	{
		return "Offer [OFFER_ID=" + OFFER_ID + ", STARTDATE=" + STARTDATE + ", TRADEPOSCN_ID=" + TRADEPOSCN_ID
				+ ", CATENTRY_ID=" + CATENTRY_ID + ", ENDDATE=" + ENDDATE + ", PRECEDENCE=" + PRECEDENCE
				+ ", PUBLISHED=" + PUBLISHED + ", LASTUPDATE=" + LASTUPDATE + ", MINIMUMQUANTITY=" + MINIMUMQUANTITY
				+ ", QTYUNIT_ID=" + QTYUNIT_ID + ", MAXIMUMQUANTITY=" + MAXIMUMQUANTITY + ", FIELD1=" + FIELD1
				+ ", FIELD2=" + FIELD2 + ", FLAGS=" + FLAGS + ", IDENTIFIER=" + IDENTIFIER + ", OID=" + OID
				+ ", OPTCOUNTER=" + OPTCOUNTER + "]";
	}
	
	
	
	
}
