package com.ikea.automation.pojo;

import java.util.List;

public class ShowStop
{
	private String COUNTRY_CODEST;
	private String ShowStop;
	private List<String> partNumbers;
	public ShowStop()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public ShowStop(String cOUNTRY_CODEST, String showStop, List<String> partNumbers)
	{
		super();
		COUNTRY_CODEST = cOUNTRY_CODEST;
		ShowStop = showStop;
		this.partNumbers = partNumbers;
	}
	public String getCOUNTRY_CODEST()
	{
		return COUNTRY_CODEST;
	}
	public void setCOUNTRY_CODEST(String cOUNTRY_CODEST)
	{
		COUNTRY_CODEST = cOUNTRY_CODEST;
	}
	public String getShowStop()
	{
		return ShowStop;
	}
	public void setShowStop(String showStop)
	{
		ShowStop = showStop;
	}
	public List<String> getPartNumbers()
	{
		return partNumbers;
	}
	public void setPartNumbers(List<String> partNumbers)
	{
		this.partNumbers = partNumbers;
	}
	@Override
	public String toString()
	{
		return "ShowStop [COUNTRY_CODEST=" + COUNTRY_CODEST + ", ShowStop=" + ShowStop + ", partNumbers=" + partNumbers
				+ "]";
	}

	
	
}
