package com.ikea.automation.pojo;

import java.sql.Timestamp;
import java.util.Date;

public class IRW_RIX_PRICE_DET
{
	private String MARKETNAME;
	private String ITEM_NO;
	private String ITEM_TYPE;
	private String PRICE_TYPE;
	private Date FROM_DTIME;    
	private Date END_DTIME;
	private double PRICE_INCL_TAX;
	private String REASON_CODE;
	private String RIX_STATUS;
	private String IRW_STATUS;
	private Date RIX_UPDATED_DATE;    
	private Date IRW_UPDATED_DATE;    
	private Date INSERTED_DATE;
	public IRW_RIX_PRICE_DET()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public IRW_RIX_PRICE_DET(String iTEM_NO, int pRICE_INCL_TAX, String rIX_STATUS, String iRW_STATUS)
	{
		super();
		ITEM_NO = iTEM_NO;
		PRICE_INCL_TAX = pRICE_INCL_TAX;
		RIX_STATUS = rIX_STATUS;
		IRW_STATUS = iRW_STATUS;
	}


	public IRW_RIX_PRICE_DET(String mARKETNAME, String iTEM_NO, String iTEM_TYPE, String pRICE_TYPE,
			Timestamp fROM_DTIME, Timestamp eND_DTIME, int pRICE_INCL_TAX, String rEASON_CODE, String rIX_STATUS,
			String iRW_STATUS, Timestamp rIX_UPDATED_DATE, Timestamp iRW_UPDATED_DATE, Timestamp iNSERTED_DATE)
	{
		super();
		MARKETNAME = mARKETNAME;
		ITEM_NO = iTEM_NO;
		ITEM_TYPE = iTEM_TYPE;
		PRICE_TYPE = pRICE_TYPE;
		FROM_DTIME = fROM_DTIME;
		END_DTIME = eND_DTIME;
		PRICE_INCL_TAX = pRICE_INCL_TAX;
		REASON_CODE = rEASON_CODE;
		RIX_STATUS = rIX_STATUS;
		IRW_STATUS = iRW_STATUS;
		RIX_UPDATED_DATE = rIX_UPDATED_DATE;
		IRW_UPDATED_DATE = iRW_UPDATED_DATE;
		INSERTED_DATE = iNSERTED_DATE;
	}
	
	public String getMARKETNAME()
	{
		return MARKETNAME;
	}
	public void setMARKETNAME(String mARKETNAME)
	{
		MARKETNAME = mARKETNAME;
	}
	public String getITEM_NO()
	{
		return ITEM_NO;
	}
	public void setITEM_NO(String iTEM_NO)
	{
		ITEM_NO = iTEM_NO;
	}
	public String getITEM_TYPE()
	{
		return ITEM_TYPE;
	}
	public void setITEM_TYPE(String iTEM_TYPE)
	{
		ITEM_TYPE = iTEM_TYPE;
	}
	public String getPRICE_TYPE()
	{
		return PRICE_TYPE;
	}
	public void setPRICE_TYPE(String pRICE_TYPE)
	{
		PRICE_TYPE = pRICE_TYPE;
	}
	public Date getFROM_DTIME()
	{
		return FROM_DTIME;
	}
	public void setFROM_DTIME(Date fROM_DTIME)
	{
		FROM_DTIME = fROM_DTIME;
	}
	public Date getEND_DTIME()
	{
		return END_DTIME;
	}
	public void setEND_DTIME(Date eND_DTIME)
	{
		END_DTIME = eND_DTIME;
	}
	public double getPRICE_INCL_TAX()
	{
		return PRICE_INCL_TAX;
	}
	public void setPRICE_INCL_TAX(double pRICE_INCL_TAX)
	{
		PRICE_INCL_TAX = pRICE_INCL_TAX;
	}
	public String getREASON_CODE()
	{
		return REASON_CODE;
	}
	public void setREASON_CODE(String rEASON_CODE)
	{
		REASON_CODE = rEASON_CODE;
	}
	public String getRIX_STATUS()
	{
		return RIX_STATUS;
	}
	public void setRIX_STATUS(String rIX_STATUS)
	{
		RIX_STATUS = rIX_STATUS;
	}
	public String getIRW_STATUS()
	{
		return IRW_STATUS;
	}
	public void setIRW_STATUS(String iRW_STATUS)
	{
		IRW_STATUS = iRW_STATUS;
	}
	public Date getRIX_UPDATED_DATE()
	{
		return RIX_UPDATED_DATE;
	}
	public void setRIX_UPDATED_DATE(Date rIX_UPDATED_DATE)
	{
		RIX_UPDATED_DATE = rIX_UPDATED_DATE;
	}
	public Date getIRW_UPDATED_DATE()
	{
		return IRW_UPDATED_DATE;
	}
	public void setIRW_UPDATED_DATE(Date iRW_UPDATED_DATE)
	{
		IRW_UPDATED_DATE = iRW_UPDATED_DATE;
	}
	public Date getINSERTED_DATE()
	{
		return INSERTED_DATE;
	}
	public void setINSERTED_DATE(Date iNSERTED_DATE)
	{
		INSERTED_DATE = iNSERTED_DATE;
	}
	@Override
	public String toString()
	{
		return "IRW_RIX_PRICE_DET [MARKETNAME=" + MARKETNAME + ", ITEM_NO=" + ITEM_NO + ", ITEM_TYPE=" + ITEM_TYPE
				+ ", PRICE_TYPE=" + PRICE_TYPE + ", FROM_DTIME=" + FROM_DTIME + ", END_DTIME=" + END_DTIME
				+ ", PRICE_INCL_TAX=" + PRICE_INCL_TAX + ", REASON_CODE=" + REASON_CODE + ", RIX_STATUS=" + RIX_STATUS
				+ ", IRW_STATUS=" + IRW_STATUS + ", RIX_UPDATED_DATE=" + RIX_UPDATED_DATE + ", IRW_UPDATED_DATE="
				+ IRW_UPDATED_DATE + ", INSERTED_DATE=" + INSERTED_DATE + "]";
	}
	
	
	
	
	
}
