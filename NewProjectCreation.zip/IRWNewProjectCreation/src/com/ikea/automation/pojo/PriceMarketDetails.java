package com.ikea.automation.pojo;

public class PriceMarketDetails
{
	private String MarketName;
	private int RIXPrice;
	private int IRWPrice;
	public PriceMarketDetails(String marketName, int rIXPrice, int iRWPrice)
	{
		super();
		MarketName = marketName;
		RIXPrice = rIXPrice;
		IRWPrice = iRWPrice;
	}
	public PriceMarketDetails()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMarketName()
	{
		return MarketName;
	}
	public void setMarketName(String marketName)
	{
		MarketName = marketName;
	}
	public int getRIXPrice()
	{
		return RIXPrice;
	}
	public void setRIXPrice(int rIXPrice)
	{
		RIXPrice = rIXPrice;
	}
	public int getIRWPrice()
	{
		return IRWPrice;
	}
	public void setIRWPrice(int iRWPrice)
	{
		IRWPrice = iRWPrice;
	}
	@Override
	public String toString()
	{
		return "PriceMarketDetails [MarketName=" + MarketName + ", RIXPrice=" + RIXPrice + ", IRWPrice=" + IRWPrice
				+ "]";
	}
	
	
}
