package com.ikea.automation.pojo;

import java.sql.Timestamp;
import java.util.Date;

public class Ri_price_v
{

	private String CLASS_TYPE;  
	private String CLASS_UNIT_TYPE;  
	private String CLASS_UNIT_CODE;  
	private String ITEM_NO; 
	private String ITEM_TYPE;  
	private String PRICE_TYPE; 
	private String CURRENCY_CODE;  
	private Date FROM_DTIME;              
	private Date TO_DTIME;              
	private double PRICE_INCL_TAX;      
	private double PRICE_EXCL_TAX;      
	private String REASON_CODE; 
	private String TAX_INCL_OVERRIDE; 
	private Date DEL_DTIME;              
	private Date UPD_DTIME;              
	private Date INS_DTIME;
	public Ri_price_v()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Ri_price_v(String cLASS_TYPE, String cLASS_UNIT_TYPE, String cLASS_UNIT_CODE, String iTEM_NO,
			String iTEM_TYPE, String pRICE_TYPE, String cURRENCY_CODE, Timestamp fROM_DTIME, Timestamp tO_DTIME,
			int pRICE_INCL_TAX, int pRICE_EXCL_TAX, String rEASON_CODE, String tAX_INCL_OVERRIDE, Timestamp dEL_DTIME,
			Timestamp uPD_DTIME, Timestamp iNS_DTIME)
	{
		super();
		CLASS_TYPE = cLASS_TYPE;
		CLASS_UNIT_TYPE = cLASS_UNIT_TYPE;
		CLASS_UNIT_CODE = cLASS_UNIT_CODE;
		ITEM_NO = iTEM_NO;
		ITEM_TYPE = iTEM_TYPE;
		PRICE_TYPE = pRICE_TYPE;
		CURRENCY_CODE = cURRENCY_CODE;
		FROM_DTIME = fROM_DTIME;
		TO_DTIME = tO_DTIME;
		PRICE_INCL_TAX = pRICE_INCL_TAX;
		PRICE_EXCL_TAX = pRICE_EXCL_TAX;
		REASON_CODE = rEASON_CODE;
		TAX_INCL_OVERRIDE = tAX_INCL_OVERRIDE;
		DEL_DTIME = dEL_DTIME;
		UPD_DTIME = uPD_DTIME;
		INS_DTIME = iNS_DTIME;
	}
	
	public String getCLASS_TYPE()
	{
		return CLASS_TYPE;
	}
	public void setCLASS_TYPE(String cLASS_TYPE)
	{
		CLASS_TYPE = cLASS_TYPE;
	}
	public String getCLASS_UNIT_TYPE()
	{
		return CLASS_UNIT_TYPE;
	}
	public void setCLASS_UNIT_TYPE(String cLASS_UNIT_TYPE)
	{
		CLASS_UNIT_TYPE = cLASS_UNIT_TYPE;
	}
	public String getCLASS_UNIT_CODE()
	{
		return CLASS_UNIT_CODE;
	}
	public void setCLASS_UNIT_CODE(String cLASS_UNIT_CODE)
	{
		CLASS_UNIT_CODE = cLASS_UNIT_CODE;
	}
	public String getITEM_NO()
	{
		return ITEM_NO;
	}
	public void setITEM_NO(String iTEM_NO)
	{
		ITEM_NO = iTEM_NO;
	}
	public String getITEM_TYPE()
	{
		return ITEM_TYPE;
	}
	public void setITEM_TYPE(String iTEM_TYPE)
	{
		ITEM_TYPE = iTEM_TYPE;
	}
	public String getPRICE_TYPE()
	{
		return PRICE_TYPE;
	}
	public void setPRICE_TYPE(String pRICE_TYPE)
	{
		PRICE_TYPE = pRICE_TYPE;
	}
	public String getCURRENCY_CODE()
	{
		return CURRENCY_CODE;
	}
	public void setCURRENCY_CODE(String cURRENCY_CODE)
	{
		CURRENCY_CODE = cURRENCY_CODE;
	}
	public Date getFROM_DTIME()
	{
		return FROM_DTIME;
	}
	public void setFROM_DTIME(Date fROM_DTIME)
	{
		FROM_DTIME = fROM_DTIME;
	}
	public Date getTO_DTIME()
	{
		return TO_DTIME;
	}
	public void setTO_DTIME(Date tO_DTIME)
	{
		TO_DTIME = tO_DTIME;
	}
	public double getPRICE_INCL_TAX()
	{
		return PRICE_INCL_TAX;
	}
	public void setPRICE_INCL_TAX(double pRICE_INCL_TAX)
	{
		PRICE_INCL_TAX = pRICE_INCL_TAX;
	}
	public double getPRICE_EXCL_TAX()
	{
		return PRICE_EXCL_TAX;
	}
	public void setPRICE_EXCL_TAX(double pRICE_EXCL_TAX)
	{
		PRICE_EXCL_TAX = pRICE_EXCL_TAX;
	}
	public String getREASON_CODE()
	{
		return REASON_CODE;
	}
	public void setREASON_CODE(String rEASON_CODE)
	{
		REASON_CODE = rEASON_CODE;
	}
	public String getTAX_INCL_OVERRIDE()
	{
		return TAX_INCL_OVERRIDE;
	}
	public void setTAX_INCL_OVERRIDE(String tAX_INCL_OVERRIDE)
	{
		TAX_INCL_OVERRIDE = tAX_INCL_OVERRIDE;
	}
	public Date getDEL_DTIME()
	{
		return DEL_DTIME;
	}
	public void setDEL_DTIME(Date dEL_DTIME)
	{
		DEL_DTIME = dEL_DTIME;
	}
	public Date getUPD_DTIME()
	{
		return UPD_DTIME;
	}
	public void setUPD_DTIME(Date uPD_DTIME)
	{
		UPD_DTIME = uPD_DTIME;
	}
	public Date getINS_DTIME()
	{
		return INS_DTIME;
	}
	public void setINS_DTIME(Date iNS_DTIME)
	{
		INS_DTIME = iNS_DTIME;
	}
	@Override
	public String toString()
	{
		return "Ri_price_v [CLASS_TYPE=" + CLASS_TYPE + ", CLASS_UNIT_TYPE=" + CLASS_UNIT_TYPE + ", CLASS_UNIT_CODE="
				+ CLASS_UNIT_CODE + ", ITEM_NO=" + ITEM_NO + ", ITEM_TYPE=" + ITEM_TYPE + ", PRICE_TYPE=" + PRICE_TYPE
				+ ", CURRENCY_CODE=" + CURRENCY_CODE + ", FROM_DTIME=" + FROM_DTIME + ", TO_DTIME=" + TO_DTIME
				+ ", PRICE_INCL_TAX=" + PRICE_INCL_TAX + ", PRICE_EXCL_TAX=" + PRICE_EXCL_TAX + ", REASON_CODE="
				+ REASON_CODE + ", TAX_INCL_OVERRIDE=" + TAX_INCL_OVERRIDE + ", DEL_DTIME=" + DEL_DTIME + ", UPD_DTIME="
				+ UPD_DTIME + ", INS_DTIME=" + INS_DTIME + "]";
	}
	
	
	
}
