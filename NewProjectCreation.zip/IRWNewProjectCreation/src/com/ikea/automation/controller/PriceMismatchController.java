package com.ikea.automation.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ikea.automation.dao.RangeToolsDao;
import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.PriceMarketDetails;
import com.ikea.automation.pojo.Ri_price_v;
import com.ikea.automation.service.PriceMismatchService;
import com.ikea.automation.service.RIXService;
import com.ikea.automation.service.RangeToolsService;

@Controller
@RequestMapping("PriceMismatch")
public class PriceMismatchController
{
	
	private static Logger logger = Logger.getLogger(PriceMismatchController.class);	
	
	@Autowired
	RIXService rixService;
	
	@Autowired
	RangeToolsService rageToolsService;
	
	@Autowired
	PriceMismatchService priceMismatchService;
	

	@Autowired
	RangeToolsDao RangeToolsDao;
	
	List<IRW_RIX_PRICE_DET> RangePriceList = new ArrayList<>();
	
	//@Scheduled(cron=" */5 * * * * ?")
	public void demo()
	{
		System.out.println("I am running "+new Date());
	}
	
	
	@Scheduled(cron="0 0 0/2 1/1 * ?")
	public void SelectFromRixJob()
	{
		logger.debug("************************************Entering inSelectFromRixJob()************************************");
		System.out.println("I am fetching prices from RIX");
		List<Ri_price_v> pricesFromRIXList = rixService.getPricesFromRIX();
		for (Ri_price_v obj : pricesFromRIXList)
		{
			System.err.println(obj);
			/*IRW_RIX_PRICE_DET Robj = new IRW_RIX_PRICE_DET();
			Robj.setMARKETNAME(obj.getCLASS_UNIT_CODE());
			Robj.setITEM_NO(obj.getITEM_NO());
			Robj.setITEM_TYPE(obj.getITEM_TYPE());
			Robj.setPRICE_TYPE(obj.getPRICE_TYPE());
			Robj.setFROM_DTIME(obj.getFROM_DTIME());
			Robj.setEND_DTIME(obj.getTO_DTIME());
			Robj.setPRICE_INCL_TAX(obj.getPRICE_EXCL_TAX());
			Robj.setREASON_CODE(obj.getREASON_CODE());
			Robj.setRIX_STATUS("YES");
			Robj.setRIX_UPDATED_DATE(obj.getUPD_DTIME());*/
			
		}
		System.err.println((!pricesFromRIXList.isEmpty()) ? "Select From RIX Status  "+priceMismatchService.checkMismatch(pricesFromRIXList) : "No New Data in RIX");
		logger.debug("************************************Exiting from  inSelectFromRixJob()************************************");
	}
	
	@Scheduled(cron=" 0 0 0/5 1/1 * ?")
	public void UpdateIRPTJob()
	{
		logger.debug("************************************Entering UpdateIRPTJob()************************************");
		System.out.println("I am Updating IRPT Status");
		System.out.println((priceMismatchService.updateIRPT()) ? "Update IRPT Update Status :: All Status are update!!" : "Update IRPT Update Status  :: Something went wrong or No price to update!!");
		logger.debug("************************************Exiting from UpdateIRPTJob() ******************************************");
	}
	
	
	@RequestMapping("selectRix")
	public ModelAndView SelectPrices()
	{
		logger.debug("************************************Entering in SelectPrices()************************************");
		List<Ri_price_v> pricesFromRIXList = rixService.getPricesFromRIX();
		for (Ri_price_v obj : pricesFromRIXList)
		{
			System.err.println(obj);
			IRW_RIX_PRICE_DET Robj = new IRW_RIX_PRICE_DET();
			/*Robj.setMARKETNAME(obj.getCLASS_UNIT_CODE());
			Robj.setITEM_NO(obj.getITEM_NO());
			Robj.setITEM_TYPE(obj.getITEM_TYPE());
			Robj.setPRICE_TYPE(obj.getPRICE_TYPE());
			Robj.setFROM_DTIME(obj.getFROM_DTIME());
			Robj.setEND_DTIME(obj.getTO_DTIME());
			Robj.setPRICE_INCL_TAX(obj.getPRICE_EXCL_TAX());
			Robj.setREASON_CODE(obj.getREASON_CODE());
			Robj.setRIX_STATUS("YES");
			Robj.setRIX_UPDATED_DATE(obj.getUPD_DTIME());*/
			
		}
		System.err.println((!pricesFromRIXList.isEmpty()) ? "Select From RIX Status  "+priceMismatchService.checkMismatch(pricesFromRIXList) : "No New Data in RIX");
		logger.debug("************************************Exiting from SelectPrices() ******************************************");
		return null;
	}
	
	@RequestMapping("UpdateIRPT")
	public ModelAndView UpdateIRPT()
	{
		logger.debug("************************************Entering in UpdateIRPT()************************************");
		System.out.println((priceMismatchService.updateIRPT()) ? "Update IRPT Update Status :: All Status are update!!" : "Update IRPT Update Status  :: Something went wrong or No price to update!!");
		logger.debug("************************************Exiting from  UpdateIRPT()******************************************");
		return null;
		
	}
	
	
	@RequestMapping("ShowAnalysis")
	public ModelAndView ShowAnalysis()
	{
		logger.debug("************************************Entering in ShowAnalysis()************************************");
		List<PriceMarketDetails> TotalOverviewList = new ArrayList<>();
		System.out.println("Showing analysis.......");
		
		/*TotalOverviewList.add(new PriceMarketDetails("CN", 100, 98));
		TotalOverviewList.add(new PriceMarketDetails("KR", 100, 98));
		TotalOverviewList.add(new PriceMarketDetails("CZ", 100, 98));
		TotalOverviewList.add(new PriceMarketDetails("JP", 100, 98));*/
		logger.debug("************************************Exiting from  ShowAnalysis()******************************************");
		return new ModelAndView("PriceTool", "TotalOverviewList", rageToolsService.getAllRecordsOnMarketpercentage());
		
	}
	
	
	
	
	@RequestMapping(value = "downloadExcel")
	public ModelAndView Download()
	{       
		HashMap <String, Object> hm = new HashMap<String, Object>();
		hm.put("allRecordsList", RangeToolsDao.getRecordsOnMarket("ALL"));
		hm.put("recordsPerMarket", RangeToolsDao.getAllRecordsOnMarketpercentage());
		
		return new ModelAndView("excelView1","HashMap",hm);
	}
	
	
	
	
	
	
	
	////////////////////////////////////////////////ALL ajax Calls//////////////////////////////////////////////////////////
	@RequestMapping(value = "/getAllRecordsOnMarket", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public List<IRW_RIX_PRICE_DET> getAllRecordsOnMarket(@RequestParam(value="MarketName") String MarketName,HttpSession session )//@RequestParam(value="MarketName") String MarketName,
	{
		logger.debug("Entering inSelectFromRixJob()");
		/*List<IRW_RIX_PRICE_DET> RecordsOnMarket = new ArrayList<>();
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "YES"));
		RecordsOnMarket.add(new IRW_RIX_PRICE_DET("12345", 100, "YES", "NO"));*/
		
		System.out.println("getting records on Market Name ::  "+MarketName);
		
		logger.debug("************************************Exiting from  ******************************************");
		return rageToolsService.getRecordsOnMarket(MarketName);
		//return RecordsOnMarket;
	}
}
