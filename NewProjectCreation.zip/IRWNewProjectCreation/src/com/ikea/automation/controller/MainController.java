package com.ikea.automation.controller;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.ikea.automation.entity.Extphysicalstores;
import com.ikea.automation.pojo.Language;
import com.ikea.automation.service.NewStoreService;
import com.ikea.automation.utility.IRWSMTPProperties;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
@Controller
class MainController 
{
	
	private static Logger logger = Logger.getLogger(MainController.class);	
	
	@Autowired
	NewStoreService newStoreService;
	
	
	//@Scheduled(cron="*/5 * * * * ?")
	public void asd()
	{
		/*  for evry 2 hours
		 * 0 0 0/2 1/1 * ? *
		 * 
		 *   for every 5 hours
		 *   
		 *  	0 0 0/5 1/1 * ? *
		 * 
		 * */
		System.out.println("I am running "+ new Date());
	}
	
	@RequestMapping("select")
	public ModelAndView SelectStores()
	{
		logger.debug("************************************Entering in SelectStores()************************************");
		
		
		ModelAndView model = new ModelAndView();
		List<Extphysicalstores> storeList = newStoreService.selectAllStores();
		 if(storeList != null)
		 {
			 model.addObject("storeList", storeList);
			 model.setViewName("select");
		 }
		 else
		 {
			 model.setViewName("error");
		 }
		 logger.debug("************************************Exiting from SelectStores()************************************");
		 return model;
	}
	
	@RequestMapping("/NewStore")
	public ModelAndView NewStore(@RequestParam(value = "error", required = false) String error,@RequestParam(value = "msg", required = false) String msg,HttpSession session)
	{
		logger.debug("************************************Entering in NewStore()************************************");
		
		ModelAndView model = new ModelAndView();
	
		System.out.println("NewStore");
		if (error != null) 
		{
			model.addObject("error", error);
			
		}
		if(msg != null)
		{
			model.addObject("msg", msg);
			
		}
		model.setViewName("NewStore");
		logger.debug("************************************Exiting from NewStore()************************************");
		return model;
	}
	
	@RequestMapping(value="/CreateStore")
	public ModelAndView CreateStore(Extphysicalstores obj,HttpSession session)
	{
		logger.debug("************************************Entering in CreateStore(Extphysicalstores obj,HttpSession session)************************************");
		
		ModelAndView model = new ModelAndView();
		System.out.println("i am in CreateNewStore  "+ obj);
		Gson gson = new Gson();
		
		if(obj!=null)
		{
			session.setAttribute("obj", obj);
			String storeNumber = obj.getSTORE_NUMBER();
			boolean status = CheckStoreNumberExist(storeNumber,session);
			if(status)
			{
				//NewStore("Store Number is already exist",session);
				model.addObject("error", "Store Number is already exist");
				model.addObject("gsonData", gson.toJson("Error"));
				model.addObject("obj", obj);
			}
			else
			{
				if(newStoreService.saveNewStore(obj) > 0)
				{
					model.addObject("msg", "Successfully Inserted!!");
					model.addObject("gsonData", gson.toJson("Success"));
					model.addObject("obj", obj);
					obj.setUPD_DATE(new java.sql.Date(System.currentTimeMillis()));
					if(newStoreService.CreateNewJob(obj).length >0)
					{
						System.out.println("I have done it");
						boolean folderCreationStatus = runShellSCript(obj);
						
						//System.out.println(((folderCreationStatus)? "All required Folders are Created..":"Something went wrong while running Shellscript"));
						
						if(folderCreationStatus)
						{
							System.out.println("All required Folders are Created.." );
								model.addObject("MSG", "NewStore_success");
							//sendMail(obj);
						}
						else
						{
							System.err.println("Something went wrong while running Shellscript");
							model.addObject("MSG", "NewStore_Error");
							
						}
						
					}
					else
					{
						System.err.println("I am failed to create a job");
						model.addObject("MSG", "NewStore_Error");
					}
					
				}
				
				
			}
			model.setViewName("Dashboard");   
		}
		logger.debug("************************************Exiting from CreateStore(Extphysicalstores obj,HttpSession session)************************************");
		return model;
	}
	
	
	@RequestMapping("job")
	public ModelAndView job()
	{
		logger.debug("************************************Entering inSelectFromRixJob()************************************");
		
		/*Extphysicalstores obj  = new Extphysicalstores();
		obj.setSTORE_NAME("asd asd");
		obj.setUPD_DATE(new java.sql.Date(System.currentTimeMillis()));
		if(newStoreService.CreateNewJob(obj).length >0)
		{
			System.out.println("I have done it");
		}
		else
		{
			System.out.println("I am failed to create a job");
		}
		return new ModelAndView("suceess");*/
		logger.debug("************************************Exiting from  inSelectFromRixJob()************************************");
		return new ModelAndView("background");
	
	}
	
	public boolean runShellSCript(Extphysicalstores obj)
	{
		logger.debug("************************************Entering inSelectFromRixJob()************************************");
		
		boolean status = false;
		String host="ptseelm-lx4814.ikeadt.com";
	    String user="sukat";
	    String password="Nyear@17";
	    String command = "cd Script_old; sudo -s ;";
	    String market = newStoreService.getMarketName(obj.getLANGUAGE_ID());
	    String storeNumber = obj.getSTORE_NUMBER();
	    String storeName = "Store_"+storeNumber;
	    
	    if(market != null)
	    {
	    	String command2="./Create_local_Store.sh "+storeName+" "+market+" "+storeNumber+"";
		    try{
		    	
		    	java.util.Properties config = new java.util.Properties(); 
		    	config.put("StrictHostKeyChecking", "no");
		    	JSch jsch = new JSch();
		    	Session session=jsch.getSession(user, host,22);
		    	session.setPassword(password);
		    	session.setConfig(config);
		    	
		    	session.connect();
		    	System.out.println("Connected");
		    	
		    	Channel channel=session.openChannel("exec");
		    	((ChannelExec)channel).setCommand(command);
		        InputStream in=channel.getInputStream();
		        OutputStream out=channel.getOutputStream();
		        
		        channel.setInputStream(null);
		        ((ChannelExec)channel).setErrStream(System.err);
		        ((ChannelExec)channel).setPty(true);
		        channel.connect();
		        
		        
		        byte[] tmp=new byte[1024];
		        while(true){
		          while(in.available()>0){
		            int i=in.read(tmp, 0, 1024);
		            if(i<0)break;
		            String msg = new String(tmp, 0, i);
		            if(msg.contains("[sudo]"))
		            {
		            	System.err.println("I need Pass : ");
		            	out.write((password+"\n").getBytes());
		            	out.flush();
		    	        out.write((command2+"\n").getBytes());
		    	        out.flush();
		    	        
		            }
		            System.out.print(msg);
		            
		            
		          }
		          out.write(("exit ; exit;"+"\n").getBytes());
		          out.flush();
		          if(channel.isClosed()){
		        	  status = (channel.getExitStatus() == 0 ) ? true: false;
		        	  
		            System.out.println("exit-status: "+channel.getExitStatus());
		            break;
		          }
		          try{Thread.sleep(1000);}catch(Exception ee){}
		        }
		        channel.disconnect();
		        session.disconnect();
		        System.out.println("DONE");
		    }catch(Exception e){
		    	e.printStackTrace();
		    }
	    }
	    else
	    {
	    	System.out.println("NO such Market Present");
	    }
	    logger.debug("************************************Exiting from  inSelectFromRixJob()************************************");
	    return status;
	}
	
	public String sendMail(Extphysicalstores obj)
	{
		IRWSMTPProperties.sendStoreCreationEmail(obj);
		return "Done";
	}
	
	
	
	////////////////////////////////////////// AJax calls//////////////////////////////////////////////////
	
	@RequestMapping(value = "/getAllCountryCode", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getAllCountryCode(HttpSession session )
	{
		return newStoreService.getCountryCodes();
	}
	
	@RequestMapping(value = "/getAllStoreType", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  List<String> getAllStoreType(HttpSession session )
	{
		return newStoreService.getStoreTypes();
	}
	
	
	@RequestMapping(value = "/CheckStoreNumberExist", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public  boolean CheckStoreNumberExist(@RequestParam(value="StoreNumber") String StoreNumber,HttpSession session )
	{
		logger.debug("************************************Entering in CheckStoreNumberExist()************************************");
		
		List<String> storeNumberList = newStoreService.getStoreNumbers(StoreNumber);
		System.out.println("Store list "+storeNumberList.toString());
		logger.debug("************************************Exiting from  CheckStoreNumberExist()************************************");
		return (storeNumberList.isEmpty())? false : true ;
	}
	
	@RequestMapping(value = "/getLanguageId", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public List<Language> getLanguageId(@RequestParam(value="COUNTRY_CODE") String COUNTRY_CODE,HttpSession session )
	{
		return newStoreService.getLanguagesOnCountry(COUNTRY_CODE);
	}
	
	@RequestMapping(value = "/changeStockCheckStatus", headers="Accept=*/*",  produces="application/json")
	@ResponseBody
	public boolean changeStockCheckStatus(HttpSession session)
	{
		logger.debug("************************************Entering in changeStockCheckStatus(HttpSession session)************************************");
		
		Extphysicalstores obj = (Extphysicalstores) session.getAttribute("obj");
		System.out.println("I am in stockCheck "+obj);
		newStoreService.updateStockCheck(obj);
		sendMail(obj);
		logger.debug("************************************Exiting from changeStockCheckStatus(HttpSession session)************************************");
		return (obj != null) ? true : false;
	}
}
	

