package com.ikea.automation.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ikea.automation.pojo.IRW_RIX_PRICE_DET;
import com.ikea.automation.pojo.ShowStop;
import com.ikea.automation.service.showStopService;
import com.ikea.automation.utility.CustomGenericException;

@Controller
public class showStopController
{
	private static Logger logger = Logger.getLogger(showStopController.class);

	@Autowired
	showStopService showStopService;
	
	
	@RequestMapping("/ShowStop")
	public ModelAndView ShowStop(@RequestParam(value = "error", required = false) String error,@RequestParam(value = "msg", required = false) String msg,HttpSession session)
	{
		logger.debug("************************************Entering in ShowStop()************************************");
		
		ModelAndView model = new ModelAndView();
	
		System.out.println("ShowStop");
		if (error != null) 
		{
			model.addObject("error", error);
			
		}
		
		if(msg != null)
		{
			model.addObject("msg", msg);
			
		}
		model.setViewName("showStop");
		logger.debug("************************************Exiting from showStop() ******************************************");
		
		return model;
	}
	
	@RequestMapping(value="ShowStopUploadUpdate" ,headers=("content-type= multipart/*"), method = RequestMethod.POST)
	public ModelAndView ShowStopUploadUpdate(ShowStop obj,@RequestParam(value="PartArticlesNumbersFile", required=false) MultipartFile PartNumberFile, HttpSession session)
	{
		logger.debug("************************************Entering in ShowStopUploadUpdate()************************************");
		
		ModelAndView model = new ModelAndView();
		String msg = "";
		System.out.println("I am in ShowStopUploadUpdate method "+obj);
		try
		{
			if(!PartNumberFile.isEmpty() && obj.getPartNumbers().isEmpty())
			{
				if(PartNumberFile.getOriginalFilename().endsWith("csv"))
				{
					model.addObject("MSG" ,(showStopService.updateShowStopUploadCSV(PartNumberFile.getInputStream(), PartNumberFile.getOriginalFilename(),obj))? "showStop_Success" : "showStop_Failed");
				    
				}
				else
				{
					model.addObject("MSG" ,(showStopService.updateShowStopUpload(PartNumberFile.getInputStream(), PartNumberFile.getOriginalFilename(),obj))? "showStop_Success" : "showStop_Failed");
				}
				
			}
			else
			{
				String encodeString = "&ETH;&#7897;t nhi&ecirc;n, &#7903; g&#7889;c T&acirc;y B&#7855;c v&#259;ng v&#7859;ng c&oacute; ti&#7871;ng v&oacute; ng&#7921;a d&#7891;n d&#7853;p.";
			    String unEncodeString = StringEscapeUtils.unescapeHtml4(encodeString);
			    System.out.println("OUTPUT : " + unEncodeString);
				model.addObject("MSG" ,((showStopService.updateShowStop(obj)) ? "showStop_Success" : "showStop_Error"));
			}
			
		} 
		catch (IOException e) 
		{
			System.out.println("I am in ADmin Controller Exception 1");
			throw new CustomGenericException("1234", "Something went wrong with processing your Excel or CSV file!! Please check Excel or try again Later");
		} catch (Exception e) 
		{
			System.out.println("I am in ADmin Controller Exception 2");
			throw new CustomGenericException("1234", "Something went wrong with processing your Excel or CSV file!! Please check Excel or try again Later");
		}
		model.setViewName("Dashboard");   
		logger.debug("************************************Exiting from ShowStopUploadUpdate() ******************************************");
		return model;
	}
	
	/*@RequestMapping(value="ShowStopManualUpdate")
	public ModelAndView ShowStopManualUpdate(ShowStop obj,HttpSession session)
	{
		System.out.println("I am in ShowStopManualUpdate method "+obj);
		return new ModelAndView("ASD");
	}
	
	@RequestMapping(value="ShowStopUploadUpdate" ,headers=("content-type= multipart/*"), method = RequestMethod.POST)
	public ModelAndView ShowStopUploadUpdate(ShowStop obj,@RequestParam(value="PartArticlesNumbersFile", required=false) MultipartFile PartNumberFile, HttpSession session)
	{
		System.out.println("I am in ShowStopUploadUpdate method "+obj);
		return new ModelAndView("ASD");
	}*/
	
	@RequestMapping(value = "downloadExcel")
	public ModelAndView Download()
	{       
		return new ModelAndView("excelView");
	}
	
///////////////////////////////////Error Handler///////////////////////////////////////////////////////////
		@ExceptionHandler(CustomGenericException.class)
		public ModelAndView handleCustomException(CustomGenericException ex) 
		{
			logger.debug("************************************Entering in handleCustomException()************************************");
			
			System.err.println("I am in handelCustomsuccess");
			ModelAndView model = new ModelAndView("MyErrorPage");
			model.addObject("exception", ex);
			logger.debug("************************************Exiting from handleCustomException() ******************************************");
			return model;
		}
}
