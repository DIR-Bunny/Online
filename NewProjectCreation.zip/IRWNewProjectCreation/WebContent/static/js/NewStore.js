/**
 * @author:Vaibhav Sarwade
 */
function parseJSON(data) 
{
    return window.JSON && window.JSON.parse ? window.JSON.parse( data ) : (new Function("return " + data))(); 
}

/*function getContextPath() 
{
	   return window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
}
*/
function ValidateForm()
{
	var status = 0;
	 
	$('.validForm input, .validForm textarea, .validForm select').each(
		    function(index)
		    {  
		        var input = $(this);
		       
		        if((input.val() == "") )
	        	{
		        	if((typeof(input.attr('type')) == 'undefined'))
	        		{
		        		//alert("I am undefined");
	        		}
		        	
		        	
		        	if(input.hasClass( 'selectpicker' ))
	        		{
		        		var name = input.attr('name');
		        		name = name + "Error";
		        		$('span#'+name).text("Please select this field cannot be Empty");
		        		console.log("I am selectpicker status changing ");
		        		status++;
	        		}
		        	
		        	
		        	if(input.hasClass('address'))
	        		{
		        		if((typeof(input.attr('name')) != 'undefined')&&  ((input.attr('name'))=="ADDRESS1"))
	        			{
		        			console.log("I am address status changing ");
		        			status++;
	        			}
	        		}
		        	if(input.attr('type')=='text')
	        		{
		        		console.log("I am type else only empty status changing "+input.attr('name')+" "+input.attr('type'));
		        		status++;
		        		$(this).prev().text("Cannot be Empty");
	        		}
		        	input.css("background","red");
		        	input.css("color","white");
		        	
		        	//alert('Type: ' + input.attr('type') + '   Name: ' + input.attr('name') + '  Value: ' + input.val());
	        	}
		        if(input.attr('name') == "STORE_NUMBER")
        		{
		        	
		        	//($("#StoreNumberError").hasClass('collapse'))?  status:status++;
	        		(parseInt($('#StatusCheck').val()) > 0) ? status++ : status ;
	        		console.log("I am in validate store number "+ status);
        		}
	        	if(input.attr('type') == 'date')
				{
		        	
					var inputDate = new Date($(this).val());
					var todaysDate = new Date();
					if(inputDate.setHours(0,0,0,0) != todaysDate.setHours(0,0,0,0)) 
					{
						console.log("I am less date status changing ");
						$(this).prev().text("Please select Today's Date")
						status++;
					}
				}
		    }
		);
		
	console.log("status "+status);
	return (status > 3) ? false : true;
}

function CheckStoreNumber(StoreNum)
{
	 var StoreNumber = ( StoreNum != null) ? StoreNum :  $("input#STORE_NUMBER").val();
	 //var StoreNumber = $("input#STORE_NUMBER").val();
	    if( StoreNumber.length >= 3)
    	{
	    	$.getJSON($("#ctx").val()+"/CheckStoreNumberExist",
	    			{StoreNumber : StoreNumber},
	    			function(Data) 
	    			{
	    				if(Data == true)
    					{
	    					$("input#STORE_NUMBER").prev().text("Store Number already Exist");
	    					$("#StoreNumberError").removeClass('collapse');
	    					$('#StatusCheck').val(1);
	    					console.log("I am in true "+ status);
	    					var status = parseInt($('#StatusCheck').val());
			        		window.scrollTo(0, 0);
    					}
	    				else
    					{
	    					$('#StatusCheck').val(0);
	    					var status = parseInt($('#StatusCheck').val());
	    					console.log("I am in false "+ status);
			        		($("#StoreNumberError").hasClass('collapse'))? window.scrollTo(0, 0):($("#StoreNumberError").addClass('collapse'),$("input#STORE_NUMBER").prev().text(""));
    					}
	    			}
	    		);	
    	}
	   
}

function chunkify(a, n,balanced) {
    if (n < 2)
        return [a];

    var len = a.length,
            out = [],
            i = 0,
            size;

    if (len % n === 0) {
        size = Math.floor(len / n);
        while (i < len) {
            out.push(a.slice(i, i += size));
        }
    }
    else if (balanced) {
        while (i < len) {
            size = Math.ceil((len - i) / n--);
            out.push(a.slice(i, i += size));
        }
    }
    else {

        n--;
        size = Math.floor(len / n);
        if (len % size === 0)
            size--;
        while (i < size * n) {
            out.push(a.slice(i, i += size));
        }
        out.push(a.slice(size * n));

    }
    return out;
}


function ClearSelectError(input)
{
	var name = input.attr('name');
	
	name = name + "Error";
	(input.val() != "") ? $('span#'+name).text("") :$('span#'+name).text("Please select Value");
	
	console.log("I am in clearselectpickerError");
	status++;
}
$(document).ready(function() 
{
	//var gsonData = $("#gsonData");
	//alert(parseJSON(gsonData.val()));
	
	
	
	$(".Date").val(new Date());
	var address = [];
	
	
	
	$("input#STORE_NUMBER").keyup(function()
	{
		CheckStoreNumber();
	});
	$("input#STORE_NUMBER").click(function()
	{
		CheckStoreNumber();
	});
	$("input#STORE_NUMBER").focusout(function() {
		CheckStoreNumber();
	});
	
	$("textarea#ADDRESS1").keyup(function() 
	{
		address = [];
		var lines = $(this).val().split(/\n/);
		
		for (var i=0; i < lines.length; i++) {
		  // only push this line if it contains a non whitespace character.
		  if (/\S/.test(lines[i])) {
			 address.push($.trim(lines[i]));
		  }
		}
	})
	$("textarea#ADDRESS1").focusout(function() {
		
	});
	
	
	
	$('#COUNTRY_CODE').on('show.bs.select', function()
	{
		$.getJSON($("#ctx").val()+"/getAllCountryCode",
			function(Data) 
			{
				$('#COUNTRY_CODE').text('');
				
				for(var index in Data)
				{
					$('#COUNTRY_CODE').append("<option value='"+Data[index]+"'>"+Data[index]+"</option>");
				} 
				$('#COUNTRY_CODE').selectpicker('refresh');
			}
		);	
		var input = $(this);
		ClearSelectError($(this));
	});
	
	$('#LANGUAGE_ID').on('show.bs.select', function()
	{
		var COUNTRY_CODE = $('#COUNTRY_CODE').val();
		$.getJSON($("#ctx").val()+"/getLanguageId",
				{COUNTRY_CODE : COUNTRY_CODE},
				function(Data) 
				{
					$('#LANGUAGE_ID').text('');
					for (var index = 0; index < Data.length; index++) 
					{
						$('#LANGUAGE_ID').append("<option value='"+Data[index].language_ID+"'>"+Data[index].language+"</option>");
					}
					$('#LANGUAGE_ID').selectpicker('refresh');
				}
			);	
	});
	
	
	$('#STORE_TYPE').on('show.bs.select', function()
	{
		$.getJSON($("#ctx").val()+"/getAllStoreType",
			function(Data) 
			{
				$('#STORE_TYPE').text('');
				for(var index in Data)
				{
					$('#STORE_TYPE').append("<option value='"+Data[index]+"'>"+Data[index]+"</option>");
				} 
				$('#STORE_TYPE').selectpicker('refresh');
			}
		);	
		
	});
	
	$('#COUNTRY_CODE').on('changed.bs.select', function()
	{
		var input = $(this);
		ClearSelectError(input);
	});
	$('#STORE_TYPE').on('changed.bs.select', function()
	{
		var input = $(this);
		ClearSelectError(input);
	});
	$('#LANGUAGE_ID').on('changed.bs.select', function()
	{
		var input = $(this);
		ClearSelectError(input);
	});

	
	
	
	$(".close").click(function() 
	{
		$(this).parent().addClass('collapse');
	});
	
	$("input,textarea").focusout(function() {
		var value = $(this).val();
		//alert(ErrorId);
		console.log(value);
		(((typeof value == 'undefined'))||(value == ""))? $(this).prev().text("Cannot be Empty"):$(this).prev().text("");
		
		var TypeDate = $(this).attr("type");
		if((TypeDate == 'date') && ($(this).val()!= ""))
		{
			var inputDate = new Date($(this).val());
			var todaysDate = new Date();
			
			(inputDate.setHours(0,0,0,0) != todaysDate.setHours(0,0,0,0))? $(this).prev().text("Please select Today's Date"):$(this).prev().text("");
		}
		console.log($('select#COUNTRY_CODE').val());
		if(($("select#COUNTRY_CODE").val()) || ($("select#STORE_TYPE").val()))
		{
			
		}
	});
	
	
	
	$(".submitFormButton").click(function(){
		//CheckStoreNumber();
		 var s = address, a = address;
	        while (s--)
	            a.unshift(s);
	      var out = chunkify(a,3,true);
	      var temp1="";
	      var temp2="";
	      var temp3="";
		  console.log("Out length "+ out.length);
	      for (var i = 0; i < out.length; i++) 
	      {
	    	  var temp1="";
	    	  for (var j = 0; j < out[i].length; j++) 
			   {
				   temp1 = temp1+(String(out[i][j]))+" ";
			   }
	    	  
	    	  $("textarea#ADDRESS"+(i+1)).val(temp1);
	      }
		   
		   console.log("I am in submit button "+$("textarea#ADDRESS1").val()+"  "+$("textarea#ADDRESS2").val()+" "+$("textarea#ADDRESS3").val());
		   
	   if(ValidateForm())
		{
		   $("#CheckMsg").text("${msg}");
		   $("#StockCheckModal").modal('show');
		  
		}
	   else
	   {
		   window.scrollTo(0, 0);	
	   }
		
	});
	
	 $(".stockCheckStatus").click(function() {
	   console.log("Stock check status "+$(this).val());
	   $("#STOCKCHECK").val(($(this).val().toUpperCase() =="YES".toUpperCase()) ? 1:0);
	   $(".validForm").submit();	
	 });

	//////////////////////////////FOr checking Entry in DB///////////////////////////////////////////
	if(typeof gson =='undefined')
	{
	}
	else
		{
			if((gson.toUpperCase() == "Success".toUpperCase()))
				ShowCountDown();
		}
	
	function ShowCountDown() 
	{
		var dt = new Date();
		var minutes = dt.getMinutes();

		var add = 10 - (minutes %10 );	
		add = add +1;
		$("#Tremaining").text(add);
		$("#Stopwatch").modal({
	            backdrop: 'static',
	            keyboard: true, 
	            show: true
			});
		
		var clock = $('.clock').FlipClock(add * 60, {
			clockFace: 'DailyCounter',
			countdown: true,
			callbacks: {
				stop: function() 
				{
					$("#Stopwatch").modal('hide');
					$("#reflectChanges").removeClass('collapse');
					$.getJSON($("#ctx").val()+"/changeStockCheckStatus",
							function(Data) 
							{
								console.log("Stock Check Status :  "+Data);
							}
						);	
				}
			}
		});
	}
	
	/* 
	$(".CheckDBbtn").click(function() 
	{
		
		var choice = $(this).attr('name');
		(choice == 'yes') ? CheckStoreNumber($("#modalStoreNumber").val()) : $("#CheckDBModal").modal('hide');
		$("#CheckDBModal").modal('hide');
	})*/
});

