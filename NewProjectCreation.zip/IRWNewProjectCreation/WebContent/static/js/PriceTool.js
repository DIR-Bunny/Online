/**
 * @author:Vaibhav Sarwade
 */
var ListOfREcordsPerMarket = [];
function getAllRecordsOnMarketName(MarketName) 
{
	var table = $('.myTable').DataTable();
	$.getJSON($("#ctx").val()+"/PriceMismatch/getAllRecordsOnMarket",
			{MarketName : MarketName},
			function(Data) 
			{
				
				if(Data.length > 0)
				{
					table.destroy();
				        $('#myTable').empty(); // empty in case the columns change
					ListOfREcordsPerMarket = [];
					/* table = $('#myTable').DataTable( {
				            columns: Data.columns,
				            data:    Data.rows
				        } );
					 $("#MoreInfo").modal('show');*/
					for (var i = 0; i < Data.length; i++) 
					{
						var ItemNo = Data[i].item_NO;
						var price = Data[i].price_INCL_TAX;
						var rixStatus = Data[i].rix_STATUS;
						var irwStatus = Data[i].irw_STATUS;
						var Obj = {};
						Obj['ItemNo'] = ItemNo;
						Obj['price']=price ;
						Obj['rixStatus']=rixStatus ;
						Obj['irwStatus']= irwStatus;
						ListOfREcordsPerMarket.push(Obj);
						
					}
					
					populateTable(ListOfREcordsPerMarket,MarketName);
					/*for (var i = 0; i < Data.length; i++) 
					{
    					var tr = document.createElement("tr");
    					var td = document.createElement('td');
    					td.append(Data[i].item_NO);
    					tr.append(td);
    					td = document.createElement('td');
    					td.append(Data[i].price_INCL_TAX);
    					tr.append(td);
    					td = document.createElement('td');
    					td.append(Data[i].rix_STATUS);
    					(Data[i].rix_STATUS === "YES") ? td.setAttribute('class','YesStatus'):td.setAttribute('class','NoStatus');
    					tr.append(td);
    					td = document.createElement('td');
    					td.append(Data[i].irw_STATUS);
    					(Data[i].irw_STATUS === "YES") ? td.setAttribute('class','YesStatus'):td.setAttribute('class','NoStatus');
    					tr.append(td);
    					appendDiv.append(tr);
					}
					$("#CountryNameModal").text(MarketName);
					$("#MoreInfo").modal('show');*/
				}
				else
				{alert("NO data");}
			}
		);	


	   /* $('.myTable').DataTable( {
	    	"bProcessing": true,
	    	"sAjaxDataProp":"",
	    	"bServerSide": true,
	        "ajax": $("#ctx").val()+"/PriceMismatch/getAllRecordsOnMarket",
	        "columns": [
	            { "data": "item_NO" },
	            { "data": "price_INCL_TAX" },
	            { "data": "rix_STATUS" },
	            { "data": "irw_STATUS" },
	        ]
	    } );
	    $("#MoreInfo").modal('show');*/
}

function populateTable(ListOfREcordsPerMarket,MarketName) 
{
	/*$('.myTable').DataTable().clear();*/
	var appendDiv = $(".AllRecordsOnMarket").text('');
	$.each(ListOfREcordsPerMarket, function( key, value ) {
		var tr = document.createElement("tr");
		var td = document.createElement('td');
		td.append(value.ItemNo);
		tr.append(td);
		td = document.createElement('td');
		td.append(value.price);
		tr.append(td);
		td = document.createElement('td');
		td.append(value.rixStatus);
		(value.rixStatus === "YES") ? td.setAttribute('class','YesStatus'):td.setAttribute('class','NoStatus');
		tr.append(td);
		td = document.createElement('td');
		td.append(value.irwStatus);
		(value.irwStatus === "YES") ? td.setAttribute('class','YesStatus'):td.setAttribute('class','NoStatus');
		tr.append(td);
		appendDiv.append(tr);
	});
	$("#CountryNameModal").text(MarketName);
	$("#MoreInfo").modal('show');
	$('.myTable').DataTable( {
        /*"sDom": "<'row'<'span8'l><'span8'f>r>t<'row'<'span8'i><'span8'p>>"*/
        /*"sPaginationType": "bootstrap"*/
    });
	console.log("In Populate Table  "+ListOfREcordsPerMarket.length);
	
}
function buttonClicked(thisEle)
{
	var MarketName = $(thisEle).parent().parent().find(".MarketName").text();
	console.log("Market Name is :: "+MarketName);
	getAllRecordsOnMarketName(MarketName);
}
$(document).ready(function() 
{
	$('.MainTable').DataTable();/*{"columnDefs": [
	                                          { "width": "33.33%"}
	                                          ]}*/

	/*$(".IRWPrice").click(function() {
		alert("clicked");
		var MarketName = $(this).parent().parent().find(".MarketName").text();
		console.log("Market Name is :: "+MarketName);
		getAllRecordsOnMarketName(MarketName);
	});*/
	setInterval(function(){ location.reload(true); },60*60000);

	
	$(".modal-wide").on("show.bs.modal", function() {
		  var height = $(window).height() - 200;
		  $(this).find(".modal-body").css("max-height", height);
		});
});