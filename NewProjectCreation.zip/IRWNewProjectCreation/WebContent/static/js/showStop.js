/**
 * @author:Vaibhav Sarwade
 */
function ClearSelectError(input)
{
	var name = input.attr('name');
	
	name = name + "Error";
	(input.val() != "") ? $('span#'+name).text("") :$('span#'+name).text("Please select Value");
	
	console.log("I am in clearselectpickerError");
	status++;
}


function ValidateFormShowStop()
{
	var status = 0;
	 
	$('.showStopForm input, .showStopForm textarea, .showStopForm select').each(
		    function(index)
		    {  
		        var input = $(this);
		       
		        if((input.val() == "") )
	        	{
		        	if((typeof(input.attr('type')) == 'undefined'))
	        		{
		        		//alert("I am undefined");
	        		}
		        	
		        	
		        	if(input.hasClass( 'selectpicker' ))
	        		{
		        		var name = input.attr('name');
		        		name = name + "Error";
		        		$('span#'+name).text("This field cannot be Empty");
		        		console.log("I am selectpicker status changing ");
		        		status++;
	        		}
		        	
		        	if(input.hasClass('partNumbers'))
	        		{
		        		if(!$(".manualPartArticles").hasClass('collapse'))
	        			{
		        			$('#partNumbers').text("This field cannot be Empty");
			        		console.log("I am Textbox status changing ");
			        		status++;
	        			}
		        		
	        		}
		        	if(input.hasClass('file'))
	        		{
		        		//alert("File");
		        		if(!$(".uploadPartArticles").hasClass('collapse'))
        				{
		        			$('#partNumbers').text("This field cannot be Empty");
		        			console.log("I am FileUpload status changing ");
			        		status++;
        				}
		        		
		        		
	        		}
		        	
		        	
		        	input.css("background","red");
		        	input.css("color","white");
		        	
		        	//alert('Type: ' + input.attr('type') + '   Name: ' + input.attr('name') + '  Value: ' + input.val());
	        	}
		        if(input.hasClass('file'))
	        	{
		        	if(!$(".uploadPartArticles").hasClass('collapse'))
    				{
			        	var filename = $(this).val()+"";
						var extension = filename.split(".");
						(extension[1] !== "xls" && extension[1] !== 'xlsx' && extension[1] !== 'csv') ? (alert("Not Valid File"),$('#partNumbers').text("Only Excel or CSV file Valid"),
								console.log("I am FileUpload status changing outside "),input.val(''),
		        		status++) : ("");
    				}
	        	}
		        
		    }
		);
		
	console.log("status "+status);
	return (status > 0) ? false : true;
}


$(document).on('click', '.browse', function(){
	$(this).parent().parent().parent().find('.file').trigger('click');
	});
$(document).on('change', '.file', function(){
	$('.show').val($(this).val().replace(/C:\\fakepath\\/, ''));
});

$(document).ready(function() 
{
	
		$('#COUNTRY_CODEST').on('show.bs.select', function()
		{
			$.getJSON($("#ctx").val()+"/getAllCountryCode",
				function(Data) 
				{
					$('#COUNTRY_CODEST').text('');
					
					for(var index in Data)
					{
						$('#COUNTRY_CODEST').append("<option value='"+Data[index]+"'>"+Data[index]+"</option>");
					} 
					$('#COUNTRY_CODEST').selectpicker('refresh');
				}
			);	
			var input = $(this);
			ClearSelectError($(this));
		});
		
		$('#COUNTRY_CODEST').on('changed.bs.select', function()
		{
			var input = $(this);
			ClearSelectError(input);
		});
		$('#ShowStop').on('changed.bs.select', function()
		{
			var input = $(this);
			ClearSelectError(input);
		});
		$(".close").click(function() 
		{
			$(this).parent().addClass('collapse');
		});
		$("textarea").focusout(function() {
			($(this).val()=="")? $("#partNumbers").text("Cannot be Empty") : $("#partNumbers").text("");
		});
	
		$("#manualPartArticles").click(function() 
		{
			var form = $(".showStopForm");
			var el = $('.manualPartArticles');
			var el1 = $('.uploadPartArticles');
			/*if(el1.hasClass('collapse'))
			{
				
			}
			else
			{
				el1.addClass('collapse');
				form.removeAttr("enctype");
				form.removeAttr("action");				
				form.attr("action","ShowStopManualUpdate");
			}
			if(el.hasClass('collapse'))
			{
				form.removeAttr("enctype");
				form.removeAttr("action");
				form.attr("action","ShowStopManualUpdate");
				el.removeClass('collapse')
			}
			else
			{
				form.removeAttr("enctype");
				form.removeAttr("action");
				el.addClass('collapse');
			}*/
			(el1.hasClass('collapse'))? "":el1.addClass('collapse');
			(el.hasClass('collapse'))? el.removeClass('collapse'):el.addClass('collapse');
		});
		
		$("#uploadPartArticles").click(function() 
		{
			var form = $(".showStopForm");
			var el = $('.uploadPartArticles');
			var el1 = $('.manualPartArticles');
			
			/*if(el1.hasClass('collapse'))
			{
				if(el.hasClass('collapse'))
				{
					form.removeAttr("enctype");
					form.removeAttr("action");
					form.attr("action","ShowStopManualUpdate");
					el.removeClass('collapse')
				}
				else
				{
					el.addClass('collapse');
					form.removeAttr("enctype");
					form.removeAttr("action");		
					form.attr("enctype","multipart/form-data");
					form.attr("action","ShowStopUploadUpdate");
				}
			}
			else
			{
				
				el1.addClass('collapse');
				form.removeAttr("enctype");
				form.removeAttr("action");		
				form.attr("enctype","multipart/form-data");
				form.attr("action","ShowStopUploadUpdate");
				el.removeClass('collapse');
			}*/			
			(el1.hasClass('collapse'))? "":el1.addClass('collapse');
			(el1.hasClass('collapse'))?(el.hasClass('collapse'))? el.removeClass('collapse'):el.addClass('collapse') : el.addClass('collapse');
		});
		
		
		
		$(".submitShowStopButton").click(function() 
		{
			var el = $('.manualPartArticles');
			var el1 = $('.uploadPartArticles');
			//alert("I am showStopSubmit");
			(ValidateFormShowStop()) ? ((el.hasClass('collapse'))? $(".partNumbers").val('') : "",(el1.hasClass('collapse'))? $(".file").val('') : "", $(".showStopForm").submit()): "";
		});
		
		$(".file").change(function() {
			
			var filename = $(this).val()+"";
			var extension = filename.split(".");
			if(extension[1] !== "xls" && extension[1] !== 'xlsx' && extension[1] !== 'csv')
				{
					alert("Not Valid File");
					$('#partNumbers').text("Only Excel or CSV file Valid");
					$(this).val('');
				}
			/*alert(filename);*/
		});
		
		$(".show").closest("div").click(function() 
		{
			$(this).parent().parent().parent().find('.file').trigger('click');
		});
		
		
		
});