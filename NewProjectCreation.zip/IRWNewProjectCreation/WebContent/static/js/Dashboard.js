/**
 * @author:Vaibhav Sarwade
 */
function clearClassLi(Name)
{
	var name = Name;
	console.log("I am in ClearClassLi Clearing "+name);
	$("a[class='menus']").each(function() {
		($(this).attr('href')=== '#'+name)? $(this).parent().addClass('active'): $(this).parent().removeClass('active');
			
	});
	$(".tab-pane").each(function() {
		($(this).attr('id')=== name)? ($("#"+name).addClass("in"),$("#"+name).addClass("active")) :  ($(this).removeClass('in'),$(this).removeClass('active'));
	});
}
$(document).ready(function() 
{
	/*$("a[class='menus']").click(function() {
		var showStopPage = '<jsp:include page="showStop.jsp" />';
		var NewStorePage = '<jsp:include page="NewStore.jsp" />';
		
		var showPage = $(this).attr('href');
		if(showPage.includes("showStop"))
		{
			$(showPage).parent().AddClass('Active');
			$(showPage).html(showStopPage);
			$(showPage).refesh();
		}
	});*/
	var msg = $('#MSG').val()+"";
	if(msg != 'undefined')
	{
		var temp = msg.split("_");
		clearClassLi(temp[0]);
		//$("a[href='#"+temp[0]+"']").parent().addClass('active');
		//$("#"+temp[0]).addClass("in");
		//$("#"+temp[0]).addClass("active");
		var msg1 = $('#MSG').val();
		if(msg1.toLowerCase() == 'showstop_success')
		{
			$("#showStopMSGText").text('Successfully Update all ShowStops');
			$("#showStopMSG").modal('show');
		}
		else if(msg1.toLowerCase() == 'showstop_error')
		{
			$("#showStopMSGText").text('Sorry Something went wrong!!');
			$("#showStopMSG").modal('show');
		}
	}
	
});